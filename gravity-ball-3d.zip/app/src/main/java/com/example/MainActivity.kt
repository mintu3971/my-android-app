package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.data.local.GameDatabase
import com.example.data.local.GameRepository
import com.example.ui.GameViewModel
import com.example.ui.GravityBallApp
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = GameDatabase.getInstance(applicationContext)
        val repository = GameRepository(database.levelProgressDao())
        val viewModel = ViewModelProvider(
            this,
            GameViewModel.Factory(repository)
        )[GameViewModel::class.java]

        setContent {
            MyApplicationTheme {
                GravityBallApp(viewModel = viewModel)
            }
        }
    }
}
