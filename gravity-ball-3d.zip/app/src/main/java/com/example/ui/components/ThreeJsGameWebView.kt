package com.example.ui.components

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import com.example.engine.BallSkinSpec
import com.example.engine.CourseLevelSpec
import com.example.engine.LevelDefinitions
import com.example.engine.NativeSoundSynth
import com.example.engine.ObbCollider
import com.example.engine.ObstacleKind
import com.example.engine.Physics3DEngine
import com.example.engine.PlatformStyle
import com.example.engine.Quat
import com.example.engine.RotatingKind
import com.example.engine.Vec3
import com.example.ui.GameScreenState
import com.example.ui.GameUiState
import com.example.ui.GameViewModel
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan
import kotlin.random.Random

private data class Particle3D(
    var active: Boolean = false,
    val pos: Vec3 = Vec3(),
    val vel: Vec3 = Vec3(),
    var life: Float = 0f,
    var maxLife: Float = 0.45f,
    var color: Color = Color(0xFF00F0FF),
    var size: Float = 0.16f
)

private data class WaterSplashRing(
    var active: Boolean = false,
    var x: Float = 0f,
    var y: Float = -11.5f,
    var z: Float = 0f,
    var progress: Float = 0f
)

private data class PolyQuad(
    val x0: Float, val y0: Float,
    val x1: Float, val y1: Float,
    val x2: Float, val y2: Float,
    val x3: Float, val y3: Float,
    val depth: Float,
    val fillColor: Color,
    val strokeColor: Color? = null,
    val strokeWidth: Float = 2.0f
)

@Composable
fun ThreeJsGameViewport(
    uiState: GameUiState,
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentUiState by rememberUpdatedState(uiState)
    val focusRequester = remember { FocusRequester() }

    val physics = remember { Physics3DEngine() }
    val soundSynth = remember { NativeSoundSynth() }
    var loadedLevelId by remember { mutableIntStateOf(0) }
    var currentCourse by remember { mutableStateOf(LevelDefinitions.ALL_LEVELS[0]) }
    val activeSpawn = remember { Vec3(0f, 1.8f, 0f) }
    val activatedCheckpoints = remember { mutableSetOf<Int>() }

    var levelTimerSec by remember { mutableFloatStateOf(0f) }
    var fallCount by remember { mutableIntStateOf(0) }
    var elapsedClock by remember { mutableFloatStateOf(0f) }
    var cameraShake by remember { mutableFloatStateOf(0f) }
    var hitstopTimer by remember { mutableFloatStateOf(0f) }
    var flashColor by remember { mutableStateOf<Color?>(null) }
    var flashAlpha by remember { mutableFloatStateOf(0f) }
    var frameTick by remember { mutableLongStateOf(0L) }
    var splashedThisFall by remember { mutableStateOf(false) }

    val camPos = remember { Vec3(0f, 4.2f, 4.6f) }
    val camLook = remember { Vec3(0f, 1.4f, 0f) }
    val targetCamPos = remember { Vec3() }
    val targetCamLook = remember { Vec3() }
    val spinQuat = remember { Quat() }

    var keyLeft by remember { mutableStateOf(false) }
    var keyRight by remember { mutableStateOf(false) }
    var keyUp by remember { mutableStateOf(false) }
    var keyDown by remember { mutableStateOf(false) }
    var keyBoost by remember { mutableStateOf(false) }

    val particles = remember { List(84) { Particle3D() } }
    val splashRing = remember { WaterSplashRing() }

    LaunchedEffect(uiState.selectedBallId) {
        val skin = LevelDefinitions.BALL_SKINS.getOrElse(uiState.selectedBallId) {
            LevelDefinitions.BALL_SKINS[0]
        }
        physics.activeSkin = skin
    }

    fun spawnBurst(origin: Vec3, count: Int, speed: Float, color: Color, upwardBias: Float = 3.8f) {
        var spawned = 0
        for (i in particles.indices) {
            val p = particles[i]
            if (!p.active) {
                p.active = true
                p.pos.copyFrom(origin)
                val angle = (spawned.toFloat() / count) * (PI.toFloat() * 2f) + Random.nextFloat() * 0.4f
                val mag = speed * (0.5f + Random.nextFloat() * 0.6f)
                p.vel.set(
                    cos(angle) * mag,
                    upwardBias * (0.45f + Random.nextFloat() * 0.85f),
                    sin(angle) * mag
                )
                p.life = 0f
                p.maxLife = 0.42f + Random.nextFloat() * 0.32f
                p.color = color
                p.size = 0.15f + Random.nextFloat() * 0.10f
                spawned++
                if (spawned >= count) break
            }
        }
    }

    fun vibrate(ms: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                v?.vibrate(ms)
            }
        } catch (_: Exception) {
        }
    }

    fun loadLevelCourse(levelId: Int) {
        val spec = LevelDefinitions.ALL_LEVELS.getOrElse((levelId - 1).coerceIn(0, 9)) {
            LevelDefinitions.ALL_LEVELS[0]
        }
        currentCourse = spec
        loadedLevelId = spec.id
        activatedCheckpoints.clear()
        physics.loadCourseColliders(spec)
        activeSpawn.copyFrom(spec.spawn)
        physics.resetBall(activeSpawn)
        splashedThisFall = false
        splashRing.active = false
        levelTimerSec = 0f
        fallCount = 0
        camPos.set(activeSpawn.x + 1.2f, activeSpawn.y + 2.2f, activeSpawn.z + 4.2f)
        camLook.set(activeSpawn.x, activeSpawn.y - 0.2f, activeSpawn.z - 4.0f)
        spawnBurst(activeSpawn, 14, 4.0f, spec.accentColor)
    }

    DisposableEffect(Unit) {
        loadLevelCourse(uiState.selectedLevelId)
        onDispose {
            soundSynth.release()
        }
    }

    LaunchedEffect(uiState.commandNonce) {
        val cmd = uiState.pendingJsCommand ?: return@LaunchedEffect
        when {
            cmd.contains("startGame(") || cmd.contains("previewLevel(") -> {
                loadLevelCourse(uiState.selectedLevelId)
            }
            cmd.contains("respawnAtCheckpoint()") -> {
                physics.resetBall(activeSpawn)
                splashedThisFall = false
                fallCount++
                soundSynth.playHazard(uiState.isMuted)
                vibrate(60L)
                flashColor = Color(0xFF38BDF8)
                flashAlpha = 0.28f
                spawnBurst(activeSpawn, 16, 4.5f, Color(0xFF00F0FF))
                viewModel.onBridgeBallFell(fallCount)
            }
            cmd.contains("jump()") -> {
                physics.requestJump()
            }
        }
    }

    LaunchedEffect(uiState.selectedLevelId) {
        if (loadedLevelId != uiState.selectedLevelId) {
            loadLevelCourse(uiState.selectedLevelId)
        }
    }

    DisposableEffect(uiState.useTiltControls) {
        if (!uiState.useTiltControls) {
            return@DisposableEffect onDispose { }
        }
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val accel = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                val values = event?.values ?: return
                val rawX = (-values[0] / 4.2f).coerceIn(-1f, 1f)
                val rawZ = ((values[1] - 4.0f) / 4.2f).coerceIn(-1f, 1f)
                viewModel.updateJoystick(rawX, rawZ)
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (accel != null) {
            sensorManager.registerListener(listener, accel, SensorManager.SENSOR_DELAY_GAME)
        }
        onDispose {
            sensorManager?.unregisterListener(listener)
        }
    }

    // Main 60fps Loop
    LaunchedEffect(Unit) {
        var lastNanos = 0L
        var lastHudReportMs = 0L
        val camForwardHoriz = Vec3(0f, 0f, -1f)
        val camRightHoriz = Vec3(1f, 0f, 0f)

        while (true) {
            withFrameNanos { nanos ->
                val rawDt = if (lastNanos == 0L) 0.016f else ((nanos - lastNanos) / 1_000_000_000f)
                lastNanos = nanos
                val dt = rawDt.coerceIn(0.001f, 0.05f)
                elapsedClock += dt
                frameTick++

                if (flashAlpha > 0f) {
                    flashAlpha = max(0f, flashAlpha - dt * 2.2f)
                }

                if (splashRing.active) {
                    splashRing.progress += dt * 1.85f
                    if (splashRing.progress >= 1f) {
                        splashRing.active = false
                    }
                }

                if (hitstopTimer > 0f) {
                    hitstopTimer = max(0f, hitstopTimer - dt)
                    return@withFrameNanos
                }

                val state = currentUiState
                val course = currentCourse

                if (state.screenState == GameScreenState.PLAYING) {
                    levelTimerSec += dt

                    val kx = (if (keyRight) 1f else 0f) - (if (keyLeft) 1f else 0f)
                    val kz = (if (keyDown) 1f else 0f) - (if (keyUp) 1f else 0f)
                    val rawX = (state.joystickX + kx).coerceIn(-1f, 1f)
                    val rawZ = (state.joystickZ + kz).coerceIn(-1f, 1f)

                    camForwardHoriz.set(camLook.x - camPos.x, 0f, camLook.z - camPos.z)
                    if (camForwardHoriz.lengthSq() > 1e-4f) {
                        camForwardHoriz.normalize()
                    } else {
                        camForwardHoriz.set(0f, 0f, -1f)
                    }
                    camRightHoriz.set(-camForwardHoriz.z, 0f, camForwardHoriz.x)

                    val worldMoveX = camRightHoriz.x * rawX + camForwardHoriz.x * (-rawZ)
                    val worldMoveZ = camRightHoriz.z * rawX + camForwardHoriz.z * (-rawZ)

                    physics.step(
                        dt = dt,
                        worldMoveX = worldMoveX,
                        worldMoveZ = worldMoveZ,
                        boost = state.isBoosting || keyBoost,
                        elapsedTime = elapsedClock,
                        onJump = {
                            soundSynth.playJump(state.isMuted)
                            spawnBurst(physics.ballPosition, 12, 3.2f, physics.activeSkin.primaryColor)
                        },
                        onHeavyLand = { intensity ->
                            cameraShake = max(cameraShake, intensity * 0.24f)
                            spawnBurst(physics.ballPosition, 8, 2.6f, physics.activeSkin.rimColor)
                        },
                        onHazardHit = {
                            soundSynth.playHazard(state.isMuted)
                            vibrate(50L)
                            hitstopTimer = 0.04f
                            cameraShake = 0.38f
                            flashColor = Color(0xFFF59E0B)
                            flashAlpha = 0.32f
                            spawnBurst(physics.ballPosition, 18, 5.5f, Color(0xFFF59E0B))
                        }
                    )

                    // Trigger water splash when falling ball crosses the ocean surface
                    if (!splashedThisFall && physics.ballPosition.y <= course.waterY + 0.6f) {
                        splashedThisFall = true
                        splashRing.active = true
                        splashRing.x = physics.ballPosition.x
                        splashRing.y = course.waterY
                        splashRing.z = physics.ballPosition.z
                        splashRing.progress = 0f
                        soundSynth.playSplash(state.isMuted)
                        vibrate(45L)
                        spawnBurst(
                            Vec3(physics.ballPosition.x, course.waterY + 0.2f, physics.ballPosition.z),
                            28,
                            4.8f,
                            Color(0xFFE0F2FE),
                            upwardBias = 6.8f
                        )
                    }

                    // Respawn after falling into the ocean depths
                    if (physics.ballPosition.y < course.voidY) {
                        physics.resetBall(activeSpawn)
                        splashedThisFall = false
                        fallCount++
                        vibrate(55L)
                        flashColor = Color(0xFF0EA5E9)
                        flashAlpha = 0.28f
                        spawnBurst(activeSpawn, 16, 4.2f, Color(0xFF38BDF8))
                        viewModel.onBridgeBallFell(fallCount)
                    }

                    for (cp in course.checkpoints) {
                        if (!activatedCheckpoints.contains(cp.id)) {
                            val dSq = physics.ballPosition.distSqTo(cp.x, cp.y, cp.z)
                            if (dSq < 5.0f) {
                                activatedCheckpoints.add(cp.id)
                                activeSpawn.set(cp.spawnX, cp.spawnY, cp.spawnZ)
                                soundSynth.playCheckpoint(state.isMuted)
                                vibrate(45L)
                                flashColor = Color(0xFF10B981)
                                flashAlpha = 0.28f
                                spawnBurst(Vec3(cp.x, cp.y + 1f, cp.z), 22, 5.0f, Color(0xFF10B981))
                                viewModel.onBridgeCheckpointReached(cp.id, course.checkpoints.size)
                            }
                        }
                    }

                    val fDistSq = physics.ballPosition.distSqTo(
                        course.finish.x,
                        course.finish.y + 1.4f,
                        course.finish.z
                    )
                    if (fDistSq < 7.8f) {
                        soundSynth.playVictory(state.isMuted)
                        vibrate(100L)
                        spawnBurst(
                            Vec3(course.finish.x, course.finish.y + 2f, course.finish.z),
                            32,
                            6.5f,
                            Color(0xFF10B981)
                        )
                        val timeMs = (levelTimerSec * 1000f).toLong().coerceAtLeast(1000L)
                        viewModel.onBridgeLevelComplete(course.id, timeMs, fallCount)
                    }

                    val nowMs = nanos / 1_000_000L
                    if (nowMs - lastHudReportMs >= 90L) {
                        lastHudReportMs = nowMs
                        val totalDist = max(1f, abs(course.finish.z - course.spawn.z))
                        val covered = max(0f, course.spawn.z - physics.ballPosition.z)
                        val prog = ((covered / totalDist) * 100f).roundToInt().coerceIn(0, 100)
                        viewModel.onBridgeHudUpdate(
                            levelId = course.id,
                            timeMs = (levelTimerSec * 1000f).toLong(),
                            progress = prog,
                            checkpointsDone = activatedCheckpoints.size,
                            checkpointsTotal = course.checkpoints.size,
                            falls = fallCount
                        )
                    }
                } else {
                    // On Home Screen (TITLE): Ball rests and gently rolls on the stone/wood platform above the ocean
                    physics.updateKinematicsOnly(elapsedClock)
                    spinQuat.setFromAxisAngle(0.22f, 0.94f, 0.16f, dt * 1.4f)
                    physics.ballQuaternion.premultiply(spinQuat)
                    physics.ballPosition.set(
                        course.spawn.x,
                        course.spawn.y - 0.52f,
                        course.spawn.z - 2.0f
                    )
                    physics.ballGrounded = true
                }

                for (i in particles.indices) {
                    val p = particles[i]
                    if (p.active) {
                        p.life += dt
                        if (p.life >= p.maxLife) {
                            p.active = false
                        } else {
                            p.vel.y -= 14f * dt
                            p.pos.addScaled(p.vel, dt)
                        }
                    }
                }

                // Update Camera: Cinematic Ocean/Platform Vista on Home Screen vs Smooth Follow in Gameplay
                if (state.screenState == GameScreenState.TITLE) {
                    targetCamPos.set(
                        course.spawn.x + sin(elapsedClock * 0.35f) * 1.4f,
                        course.spawn.y + 1.85f,
                        course.spawn.z + 2.8f
                    )
                    targetCamLook.set(
                        course.spawn.x,
                        course.spawn.y - 0.85f,
                        course.spawn.z - 8.5f
                    )
                    val alpha = 1f - exp(-5.0f * dt)
                    camPos.x += (targetCamPos.x - camPos.x) * alpha
                    camPos.y += (targetCamPos.y - camPos.y) * alpha
                    camPos.z += (targetCamPos.z - camPos.z) * alpha
                    camLook.x += (targetCamLook.x - camLook.x) * alpha
                    camLook.y += (targetCamLook.y - camLook.y) * alpha
                    camLook.z += (targetCamLook.z - camLook.z) * alpha
                } else if (state.screenState == GameScreenState.LEVEL_COMPLETE) {
                    val orbit = elapsedClock * 0.45f
                    targetCamPos.set(
                        course.finish.x + sin(orbit) * 12f,
                        course.finish.y + 6.5f,
                        course.finish.z + cos(orbit) * 12f
                    )
                    targetCamLook.set(course.finish.x, course.finish.y + 1.5f, course.finish.z)
                    val alpha = 1f - exp(-4.0f * dt)
                    camPos.x += (targetCamPos.x - camPos.x) * alpha
                    camPos.y += (targetCamPos.y - camPos.y) * alpha
                    camPos.z += (targetCamPos.z - camPos.z) * alpha
                    camLook.x += (targetCamLook.x - camLook.x) * alpha
                    camLook.y += (targetCamLook.y - camLook.y) * alpha
                    camLook.z += (targetCamLook.z - camLook.z) * alpha
                } else {
                    val presetH = when (state.cameraPreset) {
                        1 -> 6.6f
                        2 -> 3.2f
                        else -> 4.6f
                    }
                    val presetD = when (state.cameraPreset) {
                        1 -> 9.2f
                        2 -> 5.8f
                        else -> 7.2f
                    }
                    val speedPull = min(2.0f, physics.ballVelocity.length() * 0.08f)
                    // Keep camera elevated enough when ball falls toward ocean so player sees the splash clearly
                    val camYFloor = course.waterY + 4.2f
                    targetCamPos.set(
                        physics.ballPosition.x - physics.ballVelocity.x * 0.08f,
                        max(camYFloor, physics.ballPosition.y + presetH),
                        physics.ballPosition.z + presetD + speedPull
                    )
                    targetCamLook.set(
                        physics.ballPosition.x + physics.ballVelocity.x * 0.12f,
                        max(course.waterY, physics.ballPosition.y + 0.35f),
                        physics.ballPosition.z - 4.8f
                    )
                    val alpha = 1f - exp(-10.5f * dt)
                    camPos.x += (targetCamPos.x - camPos.x) * alpha
                    camPos.y += (targetCamPos.y - camPos.y) * alpha
                    camPos.z += (targetCamPos.z - camPos.z) * alpha
                    camLook.x += (targetCamLook.x - camLook.x) * alpha
                    camLook.y += (targetCamLook.y - camLook.y) * alpha
                    camLook.z += (targetCamLook.z - camLook.z) * alpha
                }

                if (cameraShake > 0.001f) {
                    camPos.x += (Random.nextFloat() - 0.5f) * cameraShake
                    camPos.y += (Random.nextFloat() - 0.5f) * cameraShake
                    cameraShake = max(0f, cameraShake - dt * 2.4f)
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        try {
            focusRequester.requestFocus()
        } catch (_: Exception) {}
    }

    val activeSkin = LevelDefinitions.BALL_SKINS.getOrElse(uiState.selectedBallId) {
        LevelDefinitions.BALL_SKINS[0]
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(currentCourse.skyTop)
            .focusRequester(focusRequester)
            .focusable()
            .onKeyEvent { event ->
                val isDown = event.type == KeyEventType.KeyDown
                when (event.key) {
                    Key.A, Key.DirectionLeft -> { keyLeft = isDown; true }
                    Key.D, Key.DirectionRight -> { keyRight = isDown; true }
                    Key.W, Key.DirectionUp -> { keyUp = isDown; true }
                    Key.S, Key.DirectionDown -> { keyDown = isDown; true }
                    Key.ShiftLeft, Key.ShiftRight -> { keyBoost = isDown; true }
                    Key.Spacebar -> {
                        if (isDown) {
                            if (currentUiState.screenState == GameScreenState.PLAYING) {
                                physics.requestJump()
                            } else if (currentUiState.screenState == GameScreenState.TITLE) {
                                viewModel.startGame(currentUiState.selectedLevelId)
                            }
                        }
                        true
                    }
                    Key.R -> {
                        if (isDown && currentUiState.screenState == GameScreenState.PLAYING) {
                            viewModel.respawnAtCheckpoint()
                        }
                        true
                    }
                    Key.Escape, Key.P -> {
                        if (isDown) {
                            if (currentUiState.screenState == GameScreenState.PLAYING) {
                                viewModel.pauseGame()
                            } else if (currentUiState.screenState == GameScreenState.PAUSED) {
                                viewModel.resumeGame()
                            }
                        }
                        true
                    }
                    else -> false
                }
            }
            .testTag("threejs_viewport_container")
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("threejs_webview")
        ) {
            val tick = frameTick
            if (tick >= 0L) {
                render3DScene(
                    course = currentCourse,
                    physics = physics,
                    skin = activeSkin,
                    camPos = camPos,
                    camLook = camLook,
                    elapsed = elapsedClock,
                    activatedCheckpoints = activatedCheckpoints,
                    particles = particles,
                    splashRing = splashRing,
                    flashColor = flashColor,
                    flashAlpha = flashAlpha
                )
            }
        }
    }
}

private fun DrawScope.render3DScene(
    course: CourseLevelSpec,
    physics: Physics3DEngine,
    skin: BallSkinSpec,
    camPos: Vec3,
    camLook: Vec3,
    elapsed: Float,
    activatedCheckpoints: Set<Int>,
    particles: List<Particle3D>,
    splashRing: WaterSplashRing,
    flashColor: Color?,
    flashAlpha: Float
) {
    val w = size.width
    val h = size.height
    if (w <= 1f || h <= 1f) return

    // 1. Camera Orthonormal Basis & Horizon Calculation
    val fwd = Vec3(camLook.x - camPos.x, camLook.y - camPos.y, camLook.z - camPos.z).normalize()
    val worldUp = Vec3(0f, 1f, 0f)
    val right = Vec3.cross(fwd, worldUp).normalize()
    val up = Vec3.cross(right, fwd).normalize()

    val aspect = w / h
    val fovRad = (if (aspect >= 1.3f) 54f else 66f) * (PI.toFloat() / 180f)
    val focal = (h * 0.5f) / tan(fovRad * 0.5f)
    val cx = w * 0.5f
    val cy = h * 0.5f

    fun projectPoint(wx: Float, wy: Float, wz: Float): FloatArray? {
        val dx = wx - camPos.x
        val dy = wy - camPos.y
        val dz = wz - camPos.z
        val zCam = dx * fwd.x + dy * fwd.y + dz * fwd.z
        if (zCam < 0.25f || zCam > 240f) return null
        val xCam = dx * right.x + dy * right.y + dz * right.z
        val yCam = dx * up.x + dy * up.y + dz * up.z
        val sx = cx + (xCam / zCam) * focal
        val sy = cy - (yCam / zCam) * focal
        return floatArrayOf(sx, sy, zCam)
    }

    // Horizon line based on camera pitch
    val horizonProj = projectPoint(camPos.x + fwd.x * 200f, course.waterY, camPos.z + fwd.z * 200f)
    val horizonY = (horizonProj?.get(1) ?: (h * 0.56f)).coerceIn(h * 0.22f, h * 0.78f)

    // 2. Natural Sky Gradient + Warm Sun + Drifting Soft Clouds
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(course.skyTop, course.skyHorizon, course.fogColor),
            startY = 0f,
            endY = horizonY
        ),
        size = androidx.compose.ui.geometry.Size(w, horizonY)
    )

    // Radiant Sun & Atmospheric Glow
    val sunX = w * 0.72f
    val sunY = horizonY * 0.42f
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                Color(0xFFFFFBEB),
                Color(0xFFFDE68A).copy(alpha = 0.65f),
                Color(0xFFF59E0B).copy(alpha = 0.18f),
                Color.Transparent
            ),
            center = Offset(sunX, sunY),
            radius = min(w, h) * 0.34f
        ),
        radius = min(w, h) * 0.34f,
        center = Offset(sunX, sunY)
    )
    drawCircle(
        color = Color(0xFFFFFBEB),
        radius = min(w, h) * 0.048f,
        center = Offset(sunX, sunY)
    )

    // Soft Drifting Clouds in the Sky
    for (cIdx in 0 until 7) {
        val cloudBaseX = ((w * (0.12f + cIdx * 0.16f) + elapsed * (5.5f + cIdx * 1.2f)) % (w * 1.25f)) - w * 0.12f
        val cloudBaseY = horizonY * (0.18f + (cIdx % 3) * 0.16f)
        val cloudScale = 1f + (cIdx % 2) * 0.35f
        val cloudColor = Color.White.copy(alpha = 0.72f)
        drawCircle(
            color = cloudColor,
            radius = 28f * cloudScale,
            center = Offset(cloudBaseX, cloudBaseY)
        )
        drawCircle(
            color = cloudColor,
            radius = 22f * cloudScale,
            center = Offset(cloudBaseX - 24f * cloudScale, cloudBaseY + 5f * cloudScale)
        )
        drawCircle(
            color = cloudColor,
            radius = 24f * cloudScale,
            center = Offset(cloudBaseX + 24f * cloudScale, cloudBaseY + 4f * cloudScale)
        )
    }

    // 3. Vast Animated Blue Ocean Below Horizon (Reflections, Waves & Sunlight Shimmer)
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                course.waterShallowColor,
                course.waterDeepColor,
                Color(0xFF082F49),
                Color(0xFF041E30)
            ),
            startY = horizonY,
            endY = h
        ),
        topLeft = Offset(0f, horizonY),
        size = androidx.compose.ui.geometry.Size(w, max(1f, h - horizonY))
    )

    // Sunlight Shimmer Path on Ocean Water
    for (sIdx in 0 until 14) {
        val tRatio = sIdx / 14f
        val wy = horizonY + (h - horizonY) * (tRatio * tRatio)
        val shimmerHalfW = (18f + tRatio * 95f) * (0.85f + 0.15f * sin(elapsed * 3.2f + sIdx))
        val sxOffset = sin(elapsed * 2.1f + sIdx * 0.9f) * (6f + tRatio * 14f)
        drawLine(
            color = Color(0xFFFFFBEB).copy(alpha = (0.48f - tRatio * 0.32f).coerceIn(0.08f, 0.5f)),
            start = Offset(sunX + sxOffset - shimmerHalfW, wy),
            end = Offset(sunX + sxOffset + shimmerHalfW, wy),
            strokeWidth = 2.2f + tRatio * 3.5f,
            cap = StrokeCap.Round
        )
    }

    // Animated 3D Ocean Wave Crest Lines on the Water Plane (y = course.waterY)
    for (wIdx in 0 until 26) {
        val waveZ = ((camPos.z - 12f - wIdx * 7.5f + (elapsed * 3.4f) % 7.5f))
        val waveShiftX = sin(elapsed * 1.4f + wIdx * 0.7f) * 4.5f
        val halfSpan = 26f + (wIdx % 4) * 8f
        val pLeft = projectPoint(-halfSpan + waveShiftX, course.waterY, waveZ)
        val pRight = projectPoint(halfSpan + waveShiftX, course.waterY, waveZ)
        if (pLeft != null && pRight != null) {
            val depthFade = (1f - pLeft[2] / 190f).coerceIn(0.08f, 0.45f)
            drawLine(
                color = Color(0xFFBAE6FD).copy(alpha = depthFade),
                start = Offset(pLeft[0], pLeft[1]),
                end = Offset(pRight[0], pRight[1]),
                strokeWidth = (focal * 0.16f / pLeft[2]).coerceIn(1.2f, 4.2f),
                cap = StrokeCap.Round
            )
        }
    }

    // 4. Distant 3D Islands Rising from the Ocean
    val islandPath = Path()
    for (isl in LevelDefinitions.OCEAN_ISLANDS) {
        val baseCenter = projectPoint(isl.x, isl.y, isl.z) ?: continue
        val baseLeft = projectPoint(isl.x - isl.radius, isl.y, isl.z) ?: continue
        val baseRight = projectPoint(isl.x + isl.radius, isl.y, isl.z) ?: continue
        val peak = projectPoint(isl.x, isl.y + isl.height, isl.z) ?: continue
        val midLeft = projectPoint(isl.x - isl.radius * 0.58f, isl.y + isl.height * 0.55f, isl.z) ?: continue
        val midRight = projectPoint(isl.x + isl.radius * 0.52f, isl.y + isl.height * 0.48f, isl.z) ?: continue

        // Sandy shoreline ring
        val sandRx = abs(baseRight[0] - baseLeft[0]) * 0.56f
        val sandRy = max(4f, sandRx * 0.22f)
        drawOval(
            color = Color(0xFFFDE68A).copy(alpha = 0.78f),
            topLeft = Offset(baseCenter[0] - sandRx, baseCenter[1] - sandRy * 0.5f),
            size = androidx.compose.ui.geometry.Size(sandRx * 2f, sandRy)
        )

        // Island mountain silhouette
        islandPath.reset()
        islandPath.moveTo(baseLeft[0], baseLeft[1])
        islandPath.lineTo(midLeft[0], midLeft[1])
        islandPath.lineTo(peak[0], peak[1])
        islandPath.lineTo(midRight[0], midRight[1])
        islandPath.lineTo(baseRight[0], baseRight[1])
        islandPath.close()
        drawPath(
            path = islandPath,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF15803D), Color(0xFF334155)),
                startY = peak[1],
                endY = baseCenter[1]
            )
        )
    }

    // 5. Water Splash Ring Effect on Ocean Surface when Ball Splashes
    if (splashRing.active) {
        val spCenter = projectPoint(splashRing.x, splashRing.y, splashRing.z)
        if (spCenter != null) {
            val baseR = (focal * (1.2f + splashRing.progress * 3.8f) / spCenter[2]).coerceIn(6f, 160f)
            val alpha = (1f - splashRing.progress).coerceIn(0f, 1f)
            drawCircle(
                color = Color.White.copy(alpha = alpha * 0.85f),
                radius = baseR,
                center = Offset(spCenter[0], spCenter[1]),
                style = Stroke(width = 4.5f * alpha)
            )
            drawCircle(
                color = Color(0xFF7DD3FC).copy(alpha = alpha * 0.65f),
                radius = baseR * 0.65f,
                center = Offset(spCenter[0], spCenter[1]),
                style = Stroke(width = 3.0f * alpha)
            )
        }
    }

    // 6. Collect & Depth-Sort Detailed 3D Obstacle Course Geometry
    val quads = ArrayList<PolyQuad>(physics.colliders.size * 8)
    val cornerLocal = Array(8) { Vec3() }
    val cornerProj = arrayOfNulls<FloatArray>(8)
    val tempRot = Vec3()

    val faceIndices = arrayOf(
        intArrayOf(0, 1, 2, 3), // Top (+Y)
        intArrayOf(4, 5, 6, 7), // Bottom (-Y)
        intArrayOf(3, 2, 6, 7), // Front (+Z)
        intArrayOf(0, 1, 5, 4), // Back (-Z)
        intArrayOf(0, 3, 7, 4), // Left (-X)
        intArrayOf(1, 2, 6, 5)  // Right (+X)
    )

    fun emitBoxQuads(
        center: Vec3,
        hx: Float,
        hy: Float,
        hz: Float,
        quat: Quat,
        topColor: Color,
        sideColor: Color,
        strokeColor: Color?,
        strokeWidth: Float = 2.0f
    ) {
        cornerLocal[0].set(-hx, hy, -hz)
        cornerLocal[1].set(hx, hy, -hz)
        cornerLocal[2].set(hx, hy, hz)
        cornerLocal[3].set(-hx, hy, hz)
        cornerLocal[4].set(-hx, -hy, -hz)
        cornerLocal[5].set(hx, -hy, -hz)
        cornerLocal[6].set(hx, -hy, hz)
        cornerLocal[7].set(-hx, -hy, hz)

        var anyVisible = false
        for (i in 0 until 8) {
            quat.transform(cornerLocal[i], tempRot)
            val p = projectPoint(center.x + tempRot.x, center.y + tempRot.y, center.z + tempRot.z)
            cornerProj[i] = p
            if (p != null) anyVisible = true
        }
        if (!anyVisible) return

        for (f in 0 until 6) {
            if (f == 1 && center.y <= camPos.y) continue
            val idx = faceIndices[f]
            val p0 = cornerProj[idx[0]] ?: continue
            val p1 = cornerProj[idx[1]] ?: continue
            val p2 = cornerProj[idx[2]] ?: continue
            val p3 = cornerProj[idx[3]] ?: continue

            val avgDepth = (p0[2] + p1[2] + p2[2] + p3[2]) * 0.25f
            val fogFactor = (avgDepth / 185f).coerceIn(0f, 0.62f)

            val rawCol = if (f == 0) topColor else sideColor
            val shadeMult = when (f) {
                0 -> 1.06f
                2 -> 0.86f
                4, 5 -> 0.72f
                else -> 0.58f
            }

            val r = (rawCol.red * shadeMult * (1f - fogFactor) + course.fogColor.red * fogFactor).coerceIn(0f, 1f)
            val g = (rawCol.green * shadeMult * (1f - fogFactor) + course.fogColor.green * fogFactor).coerceIn(0f, 1f)
            val b = (rawCol.blue * shadeMult * (1f - fogFactor) + course.fogColor.blue * fogFactor).coerceIn(0f, 1f)

            quads.add(
                PolyQuad(
                    x0 = p0[0], y0 = p0[1],
                    x1 = p1[0], y1 = p1[1],
                    x2 = p2[0], y2 = p2[1],
                    x3 = p3[0], y3 = p3[1],
                    depth = avgDepth,
                    fillColor = Color(r, g, b, 1f),
                    strokeColor = if (f == 0) strokeColor?.copy(alpha = (1f - fogFactor).coerceIn(0.35f, 0.92f)) else null,
                    strokeWidth = strokeWidth
                )
            )
        }
    }

    val subPos = Vec3()
    val localOffset = Vec3()

    for (cIdx in 0 until physics.colliders.size) {
        val col = physics.colliders[cIdx]
        if (!col.renderMesh) continue

        val distZ = abs(col.position.z - camPos.z)
        if (distZ > 165f) continue

        val hx = col.halfExtents.x
        val hy = col.halfExtents.y
        val hz = col.halfExtents.z

        // Special Hazard Renderers: Rotating Fan & Circular Saw Cutter
        if (col.rotatingKind == RotatingKind.ROTATING_FAN) {
            // Render aerodynamic fan blade with red safety tip
            emitBoxQuads(
                center = col.position,
                hx = hx,
                hy = hy * 0.55f,
                hz = hz * 0.85f,
                quat = col.quaternion,
                topColor = Color(0xFFCBD5E1),
                sideColor = Color(0xFF475569),
                strokeColor = Color(0xFFEF4444),
                strokeWidth = 2.8f
            )
            // Central turbine rotor hub (drawn once on primary blade collider)
            if (col.isRotatingHub) {
                subPos.set(col.position.x, col.position.y + 0.15f, col.position.z)
                emitBoxQuads(
                    center = subPos,
                    hx = 0.68f,
                    hy = 0.62f,
                    hz = 0.68f,
                    quat = col.quaternion,
                    topColor = Color(0xFFEF4444),
                    sideColor = Color(0xFF1E293B),
                    strokeColor = Color(0xFFFACC15),
                    strokeWidth = 2.5f
                )
            }
            continue
        }

        if (col.rotatingKind == RotatingKind.ROTATING_CUTTER || col.obstacleKind == ObstacleKind.SAW_CUTTER) {
            // Circular Saw Cutters are rendered as multi-tooth 3D metallic discs in step 6B below;
            // also emit a dark warning slot on the bridge directly beneath the saw blade!
            subPos.set(col.basePosition.x, col.position.y - hy * 0.72f, col.position.z)
            emitBoxQuads(
                center = subPos,
                hx = if (col.obstacleKind == ObstacleKind.SAW_CUTTER) 2.3f else 0.35f,
                hy = 0.08f,
                hz = 0.32f,
                quat = col.quaternion,
                topColor = Color(0xFF7F1D1D),
                sideColor = Color(0xFF450A0A),
                strokeColor = Color(0xFFEF4444),
                strokeWidth = 2.0f
            )
            continue
        }

        when (col.platformStyle) {
            PlatformStyle.WOOD_BRIDGE -> {
                // Render suspended wooden bridge as individual 3D wooden planks with gaps + side timber beams
                val totalLen = hz * 2f
                val plankCount = max(3, (totalLen / 1.45f).roundToInt()).coerceAtMost(14)
                val stepZ = totalLen / plankCount
                val plankHalfD = (stepZ * 0.41f).coerceAtLeast(0.28f)

                // Left & Right longitudinal support beams underneath the planks
                for (side in intArrayOf(-1, 1)) {
                    localOffset.set(side * (hx * 0.82f), -hy * 0.45f, 0f)
                    col.quaternion.transform(localOffset, tempRot)
                    subPos.set(col.position.x + tempRot.x, col.position.y + tempRot.y, col.position.z + tempRot.z)
                    emitBoxQuads(
                        center = subPos,
                        hx = 0.22f,
                        hy = hy * 0.55f,
                        hz = hz,
                        quat = col.quaternion,
                        topColor = Color(0xFF5C3A1E),
                        sideColor = Color(0xFF3E2613),
                        strokeColor = null
                    )
                }

                // Individual wooden planks across the bridge
                for (pIdx in 0 until plankCount) {
                    val localZ = -hz + (pIdx + 0.5f) * stepZ
                    localOffset.set(0f, hy * 0.15f, localZ)
                    col.quaternion.transform(localOffset, tempRot)
                    subPos.set(col.position.x + tempRot.x, col.position.y + tempRot.y, col.position.z + tempRot.z)

                    val plankTone = when (pIdx % 3) {
                        0 -> Color(0xFF9A6230)
                        1 -> Color(0xFF865225)
                        else -> Color(0xFFA66D38)
                    }
                    emitBoxQuads(
                        center = subPos,
                        hx = hx,
                        hy = hy * 0.45f,
                        hz = plankHalfD,
                        quat = col.quaternion,
                        topColor = plankTone,
                        sideColor = Color(0xFF5C3818),
                        strokeColor = Color(0xFFD69E5C),
                        strokeWidth = 1.4f
                    )
                }

                // Corner wooden posts & suspended rope handrails for wooden bridges
                for (side in intArrayOf(-1, 1)) {
                    for (endZ in floatArrayOf(-hz * 0.88f, 0f, hz * 0.88f)) {
                        localOffset.set(side * (hx * 0.94f), hy + 0.55f, endZ)
                        col.quaternion.transform(localOffset, tempRot)
                        subPos.set(col.position.x + tempRot.x, col.position.y + tempRot.y, col.position.z + tempRot.z)
                        emitBoxQuads(
                            center = subPos,
                            hx = 0.14f,
                            hy = 0.65f,
                            hz = 0.14f,
                            quat = col.quaternion,
                            topColor = Color(0xFFD97706),
                            sideColor = Color(0xFF5C3818),
                            strokeColor = null
                        )
                    }
                }
            }

            PlatformStyle.STONE_PATH -> {
                // Natural bevelled stone deck + carved stone slab joints + underneath stone pillar
                emitBoxQuads(
                    center = col.position,
                    hx = hx,
                    hy = hy,
                    hz = hz,
                    quat = col.quaternion,
                    topColor = Color(0xFF94A3B8),
                    sideColor = Color(0xFF475569),
                    strokeColor = Color(0xFFCBD5E1),
                    strokeWidth = 2.2f
                )
                // Inner bevelled stone paving blocks along the path
                val blockCount = max(2, (hz * 2f / 3.6f).roundToInt()).coerceAtMost(7)
                val stepZ = (hz * 2f) / blockCount
                for (bIdx in 0 until blockCount) {
                    val localZ = -hz + (bIdx + 0.5f) * stepZ
                    localOffset.set(0f, hy + 0.04f, localZ)
                    col.quaternion.transform(localOffset, tempRot)
                    subPos.set(col.position.x + tempRot.x, col.position.y + tempRot.y, col.position.z + tempRot.z)
                    val slabColor = if (bIdx % 2 == 0) Color(0xFF8695A8) else Color(0xFF7B8A9E)
                    emitBoxQuads(
                        center = subPos,
                        hx = hx * 0.86f,
                        hy = 0.05f,
                        hz = stepZ * 0.43f,
                        quat = col.quaternion,
                        topColor = slabColor,
                        sideColor = Color(0xFF64748B),
                        strokeColor = Color(0xFF475569),
                        strokeWidth = 1.5f
                    )
                }

                // Stone support pillar extending down toward the ocean
                if (col.hasPillar && !col.id.startsWith("rail_")) {
                    val pillarH = 4.6f
                    subPos.set(col.position.x, col.position.y - hy - pillarH, col.position.z)
                    emitBoxQuads(
                        center = subPos,
                        hx = min(1.4f, hx * 0.42f),
                        hy = pillarH,
                        hz = min(1.4f, hz * 0.25f),
                        quat = col.quaternion,
                        topColor = Color(0xFF475569),
                        sideColor = Color(0xFF334155),
                        strokeColor = null
                    )
                }
            }

            PlatformStyle.FLOATING_ROCK -> {
                // Walkable rocky top + multi-tiered craggy rock under-belly
                emitBoxQuads(
                    center = col.position,
                    hx = hx,
                    hy = hy * 0.65f,
                    hz = hz,
                    quat = col.quaternion,
                    topColor = Color(0xFF788696),
                    sideColor = Color(0xFF475569),
                    strokeColor = Color(0xFF94A3B8),
                    strokeWidth = 2.0f
                )
                subPos.set(col.position.x, col.position.y - hy * 1.35f, col.position.z)
                emitBoxQuads(
                    center = subPos,
                    hx = hx * 0.72f,
                    hy = hy * 0.85f,
                    hz = hz * 0.72f,
                    quat = col.quaternion,
                    topColor = Color(0xFF475569),
                    sideColor = Color(0xFF334155),
                    strokeColor = null
                )
                subPos.set(col.position.x, col.position.y - hy * 2.55f, col.position.z)
                emitBoxQuads(
                    center = subPos,
                    hx = hx * 0.40f,
                    hy = hy * 0.75f,
                    hz = hz * 0.40f,
                    quat = col.quaternion,
                    topColor = Color(0xFF334155),
                    sideColor = Color(0xFF1E293B),
                    strokeColor = null
                )
            }

            PlatformStyle.METALLIC_TECH -> {
                emitBoxQuads(
                    center = col.position,
                    hx = hx,
                    hy = hy,
                    hz = hz,
                    quat = col.quaternion,
                    topColor = col.color,
                    sideColor = Color(0xFF1E293B),
                    strokeColor = col.trimColor,
                    strokeWidth = 2.6f
                )
            }

            PlatformStyle.CURVED_RAMP -> {
                emitBoxQuads(
                    center = col.position,
                    hx = hx,
                    hy = hy,
                    hz = hz,
                    quat = col.quaternion,
                    topColor = col.color,
                    sideColor = Color(0xFF574C3F),
                    strokeColor = col.trimColor,
                    strokeWidth = 2.2f
                )
            }
        }
    }

    quads.sortByDescending { it.depth }

    val quadPath = Path()
    for (i in 0 until quads.size) {
        val q = quads[i]
        quadPath.reset()
        quadPath.moveTo(q.x0, q.y0)
        quadPath.lineTo(q.x1, q.y1)
        quadPath.lineTo(q.x2, q.y2)
        quadPath.lineTo(q.x3, q.y3)
        quadPath.close()
        drawPath(quadPath, color = q.fillColor)
        if (q.strokeColor != null) {
            drawPath(quadPath, color = q.strokeColor, style = Stroke(width = q.strokeWidth))
        }
    }

    // 6B. Render Suspended Rope Cables on Wooden Bridges & Spinning Circular Saw Cutters
    val sawPath = Path()
    for (cIdx in 0 until physics.colliders.size) {
        val col = physics.colliders[cIdx]
        val distZ = abs(col.position.z - camPos.z)
        if (distZ > 155f) continue

        // Hanging catenary ropes along wooden bridges
        if (col.platformStyle == PlatformStyle.WOOD_BRIDGE && !col.id.startsWith("rail_")) {
            val hx = col.halfExtents.x
            val hy = col.halfExtents.y
            val hz = col.halfExtents.z
            for (side in intArrayOf(-1, 1)) {
                localOffset.set(side * (hx * 0.94f), hy + 1.05f, -hz * 0.88f)
                col.quaternion.transform(localOffset, tempRot)
                val pStart = projectPoint(col.position.x + tempRot.x, col.position.y + tempRot.y, col.position.z + tempRot.z)

                localOffset.set(side * (hx * 0.94f), hy + 0.82f, 0f)
                col.quaternion.transform(localOffset, tempRot)
                val pMid = projectPoint(col.position.x + tempRot.x, col.position.y + tempRot.y, col.position.z + tempRot.z)

                localOffset.set(side * (hx * 0.94f), hy + 1.05f, hz * 0.88f)
                col.quaternion.transform(localOffset, tempRot)
                val pEnd = projectPoint(col.position.x + tempRot.x, col.position.y + tempRot.y, col.position.z + tempRot.z)

                if (pStart != null && pMid != null && pEnd != null) {
                    drawLine(
                        color = Color(0xFFD97706),
                        start = Offset(pStart[0], pStart[1]),
                        end = Offset(pMid[0], pMid[1]),
                        strokeWidth = 2.6f,
                        cap = StrokeCap.Round
                    )
                    drawLine(
                        color = Color(0xFFD97706),
                        start = Offset(pMid[0], pMid[1]),
                        end = Offset(pEnd[0], pEnd[1]),
                        strokeWidth = 2.6f,
                        cap = StrokeCap.Round
                    )
                }
            }
        }

        // 3D Industrial Circular Saw Cutter with 12 Rotating Metallic Teeth
        if (col.rotatingKind == RotatingKind.ROTATING_CUTTER || col.obstacleKind == ObstacleKind.SAW_CUTTER) {
            val centerProj = projectPoint(col.position.x, col.position.y, col.position.z) ?: continue
            val radiusWorld = max(col.halfExtents.y, col.halfExtents.z)
            val screenR = (focal * radiusWorld / centerProj[2]).coerceIn(8f, 130f)
            val cxSaw = centerProj[0]
            val cySaw = centerProj[1]

            // Saw teeth polygon (12 sharp rotating teeth)
            val teethCount = 12
            sawPath.reset()
            for (tIdx in 0 until teethCount * 2) {
                val isTip = tIdx % 2 == 0
                val rNow = if (isTip) screenR * 1.12f else screenR * 0.84f
                val angle = col.currentAngleRad + (tIdx.toFloat() / (teethCount * 2)) * (PI.toFloat() * 2f)
                val tx = cxSaw + cos(angle) * rNow
                val ty = cySaw + sin(angle) * rNow
                if (tIdx == 0) sawPath.moveTo(tx, ty) else sawPath.lineTo(tx, ty)
            }
            sawPath.close()

            drawPath(
                path = sawPath,
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFFF8FAFC), Color(0xFF94A3B8), Color(0xFF475569)),
                    center = Offset(cxSaw, cySaw),
                    radius = screenR * 1.15f
                )
            )
            drawPath(
                path = sawPath,
                color = Color(0xFFEF4444),
                style = Stroke(width = (screenR * 0.06f).coerceAtLeast(1.8f))
            )

            // Red-hot inner warning ring & industrial axle bolt
            drawCircle(
                color = Color(0xFFEF4444),
                radius = screenR * 0.36f,
                center = Offset(cxSaw, cySaw)
            )
            drawCircle(
                color = Color(0xFF1E293B),
                radius = screenR * 0.16f,
                center = Offset(cxSaw, cySaw)
            )
        }
    }

    // 7. Checkpoint Stone/Energy Arches
    for (cp in course.checkpoints) {
        val isDone = activatedCheckpoints.contains(cp.id)
        val ringColor = if (isDone) Color(0xFF10B981) else Color(0xFF00F0FF)
        val centerProj = projectPoint(cp.x, cp.y + 1.3f, cp.z) ?: continue
        val ringRadiusPx = (focal * 1.35f / centerProj[2]).coerceIn(6f, 140f)
        drawCircle(
            color = ringColor,
            radius = ringRadiusPx,
            center = Offset(centerProj[0], centerProj[1]),
            style = Stroke(width = (focal * 0.18f / centerProj[2]).coerceIn(2.5f, 9f))
        )
    }

    // 8. Finish Gate Portal Arch
    val finProj = projectPoint(course.finish.x, course.finish.y + 2.2f, course.finish.z)
    if (finProj != null) {
        val outerR = (focal * 2.2f / finProj[2]).coerceIn(8f, 190f)
        val innerR = outerR * 0.72f
        drawCircle(
            color = Color(0xFF10B981),
            radius = outerR,
            center = Offset(finProj[0], finProj[1]),
            style = Stroke(width = (focal * 0.24f / finProj[2]).coerceIn(3f, 12f))
        )
        drawCircle(
            color = Color(0xFFFACC15),
            radius = innerR,
            center = Offset(finProj[0], finProj[1]),
            style = Stroke(width = (focal * 0.16f / finProj[2]).coerceIn(2f, 9f))
        )
    }

    // 9. Soft Contact Shadow Under Ball
    if (physics.ballGrounded) {
        val shadowProj = projectPoint(
            physics.ballPosition.x,
            physics.ballPosition.y - physics.ballRadius + 0.04f,
            physics.ballPosition.z
        )
        if (shadowProj != null) {
            val sr = (focal * physics.ballRadius * 1.35f / shadowProj[2]).coerceIn(6f, 110f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xAA000000), Color(0x44000000), Color.Transparent),
                    center = Offset(shadowProj[0], shadowProj[1]),
                    radius = sr
                ),
                radius = sr,
                center = Offset(shadowProj[0], shadowProj[1])
            )
        }
    }

    // 10. Render Selected 3D Player Ball with Custom Skin, Specular Highlight & Quaternion Nodes
    val ballProj = projectPoint(
        physics.ballPosition.x,
        physics.ballPosition.y,
        physics.ballPosition.z
    )
    if (ballProj != null) {
        val bx = ballProj[0]
        val by = ballProj[1]
        val bz = ballProj[2]
        val screenR = (focal * physics.ballRadius / bz).coerceIn(10f, 150f)

        // Outer luminous aura
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(skin.primaryColor.copy(alpha = 0.36f), Color.Transparent),
                center = Offset(bx, by),
                radius = screenR * 1.42f
            ),
            radius = screenR * 1.42f,
            center = Offset(bx, by)
        )

        // Metallic 3D Sphere Shell
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color.White,
                    skin.coreGlowColor,
                    skin.primaryColor,
                    skin.secondaryColor,
                    Color(0xFF090D1A)
                ),
                center = Offset(bx - screenR * 0.32f, by - screenR * 0.32f),
                radius = screenR * 1.38f
            ),
            radius = screenR,
            center = Offset(bx, by)
        )

        // Glowing Rim
        drawCircle(
            color = skin.rimColor,
            radius = screenR,
            center = Offset(bx, by),
            style = Stroke(width = (screenR * 0.085f).coerceAtLeast(2f))
        )

        // 6 Cardinal Axis Energy Nodes rotated by physics.ballQuaternion
        val axisDirs = arrayOf(
            Vec3(0f, 1f, 0f) to skin.coreGlowColor,
            Vec3(0f, -1f, 0f) to skin.coreGlowColor,
            Vec3(1f, 0f, 0f) to skin.rimColor,
            Vec3(-1f, 0f, 0f) to skin.rimColor,
            Vec3(0f, 0f, 1f) to Color.White,
            Vec3(0f, 0f, -1f) to Color.White
        )
        val rotNode = Vec3()
        for ((dirVec, nodeColor) in axisDirs) {
            physics.ballQuaternion.transform(dirVec, rotNode)
            val viewDot = rotNode.x * (-fwd.x) + rotNode.y * (-fwd.y) + rotNode.z * (-fwd.z)
            if (viewDot > -0.15f) {
                val nProj = projectPoint(
                    physics.ballPosition.x + rotNode.x * physics.ballRadius * 0.88f,
                    physics.ballPosition.y + rotNode.y * physics.ballRadius * 0.88f,
                    physics.ballPosition.z + rotNode.z * physics.ballRadius * 0.88f
                )
                if (nProj != null) {
                    drawCircle(
                        color = nodeColor,
                        radius = (screenR * 0.21f * ((viewDot + 0.4f).coerceIn(0.4f, 1f))),
                        center = Offset(nProj[0], nProj[1])
                    )
                }
            }
        }
    }

    // 11. Pooled 3D Particles (Sparks & Ocean Water Droplets)
    for (i in particles.indices) {
        val p = particles[i]
        if (p.active) {
            val pp = projectPoint(p.pos.x, p.pos.y, p.pos.z) ?: continue
            val lifeRatio = (1f - p.life / p.maxLife).coerceIn(0f, 1f)
            val pr = (focal * p.size * lifeRatio / pp[2]).coerceIn(2f, 22f)
            drawCircle(
                color = p.color.copy(alpha = lifeRatio),
                radius = pr,
                center = Offset(pp[0], pp[1])
            )
        }
    }

    // 12. Screen Hit/Checkpoint/Splash Flash
    if (flashColor != null && flashAlpha > 0.01f) {
        drawRect(color = flashColor.copy(alpha = flashAlpha.coerceIn(0f, 0.45f)))
    }
}
