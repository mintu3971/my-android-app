package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepSpaceBg = Color(0xFF060B1E)
val CosmicSurface = Color(0xE60B1228)
val CosmicCard = Color(0xFF131D3B)
val NeonCyan = Color(0xFF00F0FF)
val NeonEmerald = Color(0xFF10B981)
val NeonAmber = Color(0xFFF59E0B)
val NeonPurple = Color(0xFFA855F7)
val NeonRose = Color(0xFFF43F5E)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val BorderGlow = Color(0x6600F0FF)
