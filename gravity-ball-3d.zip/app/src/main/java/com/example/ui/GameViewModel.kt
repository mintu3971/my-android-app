package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.GameRepository
import com.example.data.local.LevelProgressEntity
import com.example.engine.LevelDefinitions
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

enum class GameScreenState {
    TITLE,
    PLAYING,
    PAUSED,
    LEVEL_COMPLETE,
    LEVEL_SELECT,
    SETTINGS,
    GUIDE
}

enum class BallControlMode {
    GESTURE,
    STEERING,
    BUTTONS,
    TILT
}

data class GameUiState(
    val screenState: GameScreenState = GameScreenState.TITLE,
    val returnScreenAfterSettings: GameScreenState = GameScreenState.TITLE,
    val selectedLevelId: Int = 1,
    val selectedBallId: Int = 0,
    val controlMode: BallControlMode = BallControlMode.GESTURE,
    val elapsedTimeMs: Long = 0L,
    val progressPercent: Int = 0,
    val checkpointsReached: Int = 0,
    val totalCheckpoints: Int = 1,
    val fallCount: Int = 0,
    val isMuted: Boolean = false,
    val useTiltControls: Boolean = false,
    val cameraPreset: Int = 0,
    val lastEarnedStars: Int = 3,
    val checkpointBanner: String? = null,
    val joystickX: Float = 0f,
    val joystickZ: Float = 0f,
    val isBoosting: Boolean = false,
    val isJumping: Boolean = false,
    val rotateWarningDismissed: Boolean = true,
    val commandNonce: Long = 0L,
    val pendingJsCommand: String? = null
)

class GameViewModel(private val repository: GameRepository) : ViewModel() {

    val levels: StateFlow<List<LevelProgressEntity>> = repository.allLevels.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = GameRepository.defaultLevels()
    )

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    private var bannerJob: Job? = null

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
        }
    }

    fun selectBall(ballId: Int) {
        val validId = ballId.coerceIn(0, LevelDefinitions.BALL_SKINS.lastIndex)
        _uiState.update { it.copy(selectedBallId = validId) }
    }

    fun selectControlMode(mode: BallControlMode) {
        _uiState.update {
            it.copy(
                controlMode = mode,
                useTiltControls = (mode == BallControlMode.TILT),
                joystickX = 0f,
                joystickZ = 0f
            )
        }
    }

    fun selectLevel(levelId: Int) {
        val levelMeta = levels.value.firstOrNull { it.levelId == levelId }
            ?: GameRepository.defaultLevels().firstOrNull { it.levelId == levelId }
            ?: return
        if (!levelMeta.isUnlocked) return

        _uiState.update {
            it.copy(
                selectedLevelId = levelId,
                elapsedTimeMs = 0L,
                progressPercent = 0,
                checkpointsReached = 0,
                totalCheckpoints = levelMeta.totalCheckpoints,
                fallCount = 0,
                checkpointBanner = null,
                commandNonce = it.commandNonce + 1,
                pendingJsCommand = "window.GravityBallGame && window.GravityBallGame.previewLevel($levelId);"
            )
        }
    }

    fun startGame(levelId: Int = _uiState.value.selectedLevelId) {
        val levelMeta = levels.value.firstOrNull { it.levelId == levelId }
            ?: GameRepository.defaultLevels().firstOrNull { it.levelId == levelId }
            ?: return
        if (!levelMeta.isUnlocked) return

        _uiState.update {
            it.copy(
                screenState = GameScreenState.PLAYING,
                selectedLevelId = levelId,
                elapsedTimeMs = 0L,
                progressPercent = 0,
                checkpointsReached = 0,
                totalCheckpoints = levelMeta.totalCheckpoints,
                fallCount = 0,
                checkpointBanner = null,
                joystickX = 0f,
                joystickZ = 0f,
                isBoosting = false,
                commandNonce = it.commandNonce + 1,
                pendingJsCommand = "window.GravityBallGame && window.GravityBallGame.startGame($levelId);"
            )
        }
        startFallbackClock()
    }

    fun pauseGame() {
        if (_uiState.value.screenState == GameScreenState.PLAYING) {
            timerJob?.cancel()
            _uiState.update {
                it.copy(
                    screenState = GameScreenState.PAUSED,
                    joystickX = 0f,
                    joystickZ = 0f,
                    isBoosting = false,
                    commandNonce = it.commandNonce + 1,
                    pendingJsCommand = "window.GravityBallGame && window.GravityBallGame.setPaused(true);"
                )
            }
        }
    }

    fun resumeGame() {
        if (_uiState.value.screenState == GameScreenState.PAUSED || _uiState.value.screenState == GameScreenState.SETTINGS) {
            _uiState.update {
                it.copy(
                    screenState = GameScreenState.PLAYING,
                    commandNonce = it.commandNonce + 1,
                    pendingJsCommand = "window.GravityBallGame && window.GravityBallGame.setPaused(false);"
                )
            }
            startFallbackClock()
        }
    }

    fun restartLevel() {
        val currentId = _uiState.value.selectedLevelId
        startGame(currentId)
    }

    fun returnToTitle() {
        timerJob?.cancel()
        val currentId = _uiState.value.selectedLevelId
        _uiState.update {
            it.copy(
                screenState = GameScreenState.TITLE,
                returnScreenAfterSettings = GameScreenState.TITLE,
                joystickX = 0f,
                joystickZ = 0f,
                isBoosting = false,
                commandNonce = it.commandNonce + 1,
                pendingJsCommand = "window.GravityBallGame && window.GravityBallGame.previewLevel($currentId);"
            )
        }
    }

    fun openLevelSelect() {
        timerJob?.cancel()
        _uiState.update {
            it.copy(
                screenState = GameScreenState.LEVEL_SELECT,
                joystickX = 0f,
                joystickZ = 0f,
                isBoosting = false
            )
        }
    }

    fun openSettings() {
        val prev = if (_uiState.value.screenState == GameScreenState.PLAYING) {
            GameScreenState.PLAYING
        } else {
            GameScreenState.TITLE
        }
        timerJob?.cancel()
        _uiState.update {
            it.copy(
                screenState = GameScreenState.SETTINGS,
                returnScreenAfterSettings = prev,
                joystickX = 0f,
                joystickZ = 0f,
                isBoosting = false
            )
        }
    }

    fun closeSettings() {
        if (_uiState.value.returnScreenAfterSettings == GameScreenState.PLAYING) {
            resumeGame()
        } else {
            returnToTitle()
        }
    }

    fun openGuide() {
        timerJob?.cancel()
        _uiState.update { it.copy(screenState = GameScreenState.GUIDE) }
    }

    fun dismissRotateWarning() {
        _uiState.update { it.copy(rotateWarningDismissed = true) }
    }

    fun respawnAtCheckpoint() {
        if (_uiState.value.screenState == GameScreenState.PLAYING) {
            _uiState.update {
                it.copy(
                    fallCount = it.fallCount + 1,
                    commandNonce = it.commandNonce + 1,
                    pendingJsCommand = "window.GravityBallGame && window.GravityBallGame.respawnAtCheckpoint();"
                )
            }
        }
    }

    fun updateJoystick(x: Float, z: Float) {
        val clampedX = x.coerceIn(-1f, 1f)
        val clampedZ = z.coerceIn(-1f, 1f)
        _uiState.update {
            val mag = hypot(clampedX, clampedZ)
            val forwardDelta = if (it.screenState == GameScreenState.PLAYING && clampedZ < -0.2f) 1 else 0
            val newProg = min(99, it.progressPercent + forwardDelta)
            it.copy(
                joystickX = clampedX,
                joystickZ = clampedZ,
                progressPercent = if (mag > 0.25f && it.progressPercent == 0) 2 else newProg
            )
        }
    }

    fun triggerJump() {
        if (_uiState.value.screenState == GameScreenState.PLAYING) {
            _uiState.update {
                it.copy(
                    isJumping = true,
                    commandNonce = it.commandNonce + 1,
                    pendingJsCommand = "window.GravityBallGame && window.GravityBallGame.jump();"
                )
            }
            viewModelScope.launch {
                delay(220)
                _uiState.update { it.copy(isJumping = false) }
            }
        }
    }

    fun setBoost(active: Boolean) {
        _uiState.update {
            it.copy(
                isBoosting = active,
                commandNonce = it.commandNonce + 1,
                pendingJsCommand = "window.GravityBallGame && window.GravityBallGame.setBoost($active);"
            )
        }
    }

    fun toggleMute() {
        val nextMuted = !_uiState.value.isMuted
        _uiState.update {
            it.copy(
                isMuted = nextMuted,
                commandNonce = it.commandNonce + 1,
                pendingJsCommand = "window.GravityBallGame && window.GravityBallGame.setMuted($nextMuted);"
            )
        }
    }

    fun toggleTiltControls() {
        val nextTilt = !_uiState.value.useTiltControls
        _uiState.update {
            it.copy(
                useTiltControls = nextTilt,
                controlMode = if (nextTilt) BallControlMode.TILT else BallControlMode.GESTURE,
                joystickX = 0f,
                joystickZ = 0f
            )
        }
    }

    fun cycleCameraPreset() {
        val nextPreset = (_uiState.value.cameraPreset + 1) % 3
        _uiState.update {
            it.copy(
                cameraPreset = nextPreset,
                commandNonce = it.commandNonce + 1,
                pendingJsCommand = "window.GravityBallGame && window.GravityBallGame.cycleCameraPreset();"
            )
        }
    }

    fun onBridgeHudUpdate(
        levelId: Int,
        timeMs: Long,
        progress: Int,
        checkpointsDone: Int,
        checkpointsTotal: Int,
        falls: Int
    ) {
        if (_uiState.value.screenState == GameScreenState.PLAYING) {
            _uiState.update {
                it.copy(
                    selectedLevelId = levelId,
                    elapsedTimeMs = timeMs,
                    progressPercent = progress.coerceIn(0, 100),
                    checkpointsReached = checkpointsDone,
                    totalCheckpoints = maxOf(1, checkpointsTotal),
                    fallCount = falls
                )
            }
        }
    }

    fun onBridgeCheckpointReached(checkpointId: Int, total: Int) {
        bannerJob?.cancel()
        _uiState.update {
            it.copy(
                checkpointsReached = maxOf(it.checkpointsReached, checkpointId),
                totalCheckpoints = maxOf(1, total),
                checkpointBanner = "CHECKPOINT $checkpointId/$total ACTIVATED!"
            )
        }
        bannerJob = viewModelScope.launch {
            delay(1800)
            _uiState.update { it.copy(checkpointBanner = null) }
        }
    }

    fun onBridgeBallFell(falls: Int) {
        _uiState.update { it.copy(fallCount = falls) }
    }

    fun onBridgeLevelComplete(levelId: Int, timeMs: Long, falls: Int) {
        timerJob?.cancel()
        val finalTime = if (timeMs > 0L) timeMs else maxOf(1200L, _uiState.value.elapsedTimeMs)
        viewModelScope.launch {
            val stars = repository.recordLevelCompletion(levelId, finalTime, falls)
            _uiState.update {
                it.copy(
                    screenState = GameScreenState.LEVEL_COMPLETE,
                    selectedLevelId = levelId,
                    elapsedTimeMs = finalTime,
                    progressPercent = 100,
                    fallCount = falls,
                    lastEarnedStars = stars,
                    joystickX = 0f,
                    joystickZ = 0f,
                    isBoosting = false
                )
            }
        }
    }

    fun resetProgress() {
        viewModelScope.launch {
            repository.resetAllProgress()
            _uiState.update {
                it.copy(
                    selectedLevelId = 1,
                    elapsedTimeMs = 0L,
                    progressPercent = 0,
                    checkpointsReached = 0,
                    totalCheckpoints = 1,
                    fallCount = 0,
                    commandNonce = it.commandNonce + 1,
                    pendingJsCommand = "window.GravityBallGame && (window.GravityBallGame.resetSavedProgress(), window.GravityBallGame.previewLevel(1));"
                )
            }
        }
    }

    private fun startFallbackClock() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_uiState.value.screenState == GameScreenState.PLAYING) {
                delay(100)
                _uiState.update { state ->
                    val speedFactor = hypot(state.joystickX, state.joystickZ)
                    val boostBonus = if (state.isBoosting) 2 else 1
                    val deltaProg = if (speedFactor > 0.2f) (speedFactor * boostBonus).roundToInt() else 0
                    state.copy(
                        elapsedTimeMs = state.elapsedTimeMs + 100L,
                        progressPercent = min(99, state.progressPercent + deltaProg)
                    )
                }
            }
        }
    }

    class Factory(private val repository: GameRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return GameViewModel(repository) as T
        }
    }
}
