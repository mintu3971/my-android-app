package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val GravityBallColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = DeepSpaceBg,
    secondary = NeonEmerald,
    onSecondary = DeepSpaceBg,
    tertiary = NeonAmber,
    onTertiary = DeepSpaceBg,
    background = DeepSpaceBg,
    onBackground = TextPrimary,
    surface = CosmicSurface,
    onSurface = TextPrimary,
    surfaceVariant = CosmicCard,
    onSurfaceVariant = TextSecondary,
    error = NeonRose
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GravityBallColorScheme,
        typography = Typography,
        content = content
    )
}
