package com.example.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.GameRepository
import com.example.data.local.LevelProgressEntity
import com.example.engine.BallSkinSpec
import com.example.engine.LevelDefinitions
import com.example.ui.components.ThreeJsGameViewport
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CosmicCard
import com.example.ui.theme.CosmicSurface
import com.example.ui.theme.DeepSpaceBg
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRose
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun GravityBallApp(viewModel: GameViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val levels by viewModel.levels.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var showIntroSplash by rememberSaveable { mutableStateOf(true) }

    BackHandler(enabled = uiState.screenState != GameScreenState.TITLE) {
        when (uiState.screenState) {
            GameScreenState.PLAYING -> viewModel.pauseGame()
            GameScreenState.PAUSED -> viewModel.resumeGame()
            GameScreenState.SETTINGS -> viewModel.closeSettings()
            GameScreenState.LEVEL_COMPLETE,
            GameScreenState.LEVEL_SELECT,
            GameScreenState.GUIDE -> viewModel.returnToTitle()
            GameScreenState.TITLE -> {}
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isPortrait = maxHeight > maxWidth * 1.05f

        // 1. Full-Screen 3D Environment Viewport (Ocean, Waves, Stone/Wood Course, Fans, Cutters & Player Ball)
        ThreeJsGameViewport(
            uiState = uiState,
            viewModel = viewModel,
            modifier = Modifier.fillMaxSize()
        )

        // 2. State Overlays (Strictly essential labels only)
        when (uiState.screenState) {
            GameScreenState.TITLE -> {
                ProfessionalHomeScreenOverlay(
                    selectedBallId = uiState.selectedBallId,
                    onSelectBall = { viewModel.selectBall(it) },
                    onPlay = {
                        showIntroSplash = false
                        viewModel.startGame(uiState.selectedLevelId)
                    },
                    onOpenLevels = {
                        showIntroSplash = false
                        viewModel.openLevelSelect()
                    },
                    onOpenSettings = {
                        showIntroSplash = false
                        viewModel.openSettings()
                    }
                )
            }

            GameScreenState.PLAYING -> {
                CleanGameplayOverlay(
                    uiState = uiState,
                    onPause = { viewModel.pauseGame() },
                    onOpenSettings = { viewModel.openSettings() },
                    onJoystickChange = { x, z -> viewModel.updateJoystick(x, z) },
                    onJump = { viewModel.triggerJump() },
                    onBoostChange = { active -> viewModel.setBoost(active) }
                )
            }

            GameScreenState.PAUSED -> {
                PauseModalOverlay(
                    onResume = { viewModel.resumeGame() },
                    onRestart = { viewModel.restartLevel() },
                    onLevels = { viewModel.openLevelSelect() },
                    onSettings = { viewModel.openSettings() },
                    onHome = { viewModel.returnToTitle() }
                )
            }

            GameScreenState.LEVEL_SELECT -> {
                LevelSelectGridScreen(
                    levels = levels,
                    selectedLevelId = uiState.selectedLevelId,
                    onSelectAndPlay = { id ->
                        viewModel.selectLevel(id)
                        viewModel.startGame(id)
                    },
                    onBackToHome = { viewModel.returnToTitle() }
                )
            }

            GameScreenState.SETTINGS,
            GameScreenState.GUIDE -> {
                SettingsControlModal(
                    uiState = uiState,
                    onSelectControlMode = { viewModel.selectControlMode(it) },
                    onToggleMute = { viewModel.toggleMute() },
                    onRestart = { viewModel.restartLevel() },
                    onHome = { viewModel.returnToTitle() },
                    onClose = { viewModel.closeSettings() }
                )
            }

            GameScreenState.LEVEL_COMPLETE -> {
                LevelCompleteModalOverlay(
                    stars = uiState.lastEarnedStars,
                    onNextLevel = {
                        val nextId = if (uiState.selectedLevelId < GameRepository.TOTAL_LEVELS) {
                            uiState.selectedLevelId + 1
                        } else {
                            1
                        }
                        viewModel.startGame(nextId)
                    },
                    onRetry = { viewModel.restartLevel() },
                    onLevels = { viewModel.openLevelSelect() },
                    onHome = { viewModel.returnToTitle() }
                )
            }
        }

        // 3. Opening Animated "GRAVITY BALL 3D" Title Animation
        AnimatedVisibility(
            visible = showIntroSplash && uiState.screenState == GameScreenState.TITLE,
            enter = fadeIn(tween(220)),
            exit = fadeOut(tween(450))
        ) {
            SlicedTitleIntroOverlay(
                onFinished = { showIntroSplash = false }
            )
        }

        // 4. Short Rotate-Your-Phone Instruction when Portrait is Detected
        if (isPortrait && !uiState.rotateWarningDismissed) {
            RotateDeviceBanner(
                onRotate = {
                    (context as? Activity)?.requestedOrientation =
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    viewModel.dismissRotateWarning()
                }
            )
        }
    }
}

@Composable
private fun RotateDeviceBanner(onRotate: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(12.dp)
            .testTag("rotate_device_overlay"),
        contentAlignment = Alignment.TopCenter
    ) {
        Row(
            modifier = Modifier
                .background(Color(0xE60B132B), RoundedCornerShape(50))
                .border(1.5.dp, NeonAmber, RoundedCornerShape(50))
                .clickable(onClick = onRotate)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ScreenRotation,
                contentDescription = "Rotate Phone",
                tint = NeonAmber,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = "ROTATE PHONE",
                style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp),
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun SlicedTitleIntroOverlay(
    onFinished: () -> Unit
) {
    val slideOffset = remember { Animatable(1f) }
    val glowAlpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        slideOffset.animateTo(
            targetValue = 0f,
            animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing)
        )
        glowAlpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 320)
        )
        delay(850)
        onFinished()
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x9904091A))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onFinished() }
            .testTag("intro_title_animation")
    ) {
        val sliceShiftPx = (slideOffset.value * 170f).roundToInt()

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        ) {
            Box(modifier = Modifier.offset { IntOffset(-sliceShiftPx - 4, -2) }) {
                Text(
                    text = "GRAVITY BALL 3D",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 4.sp
                    ),
                    color = NeonCyan,
                    textAlign = TextAlign.Center
                )
            }

            Box(modifier = Modifier.offset { IntOffset(sliceShiftPx + 4, 3) }) {
                Text(
                    text = "GRAVITY BALL 3D",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 4.sp
                    ),
                    color = NeonAmber.copy(alpha = 0.85f),
                    textAlign = TextAlign.Center
                )
            }

            Text(
                text = "GRAVITY BALL 3D",
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 4.sp
                ),
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Canvas(
                modifier = Modifier
                    .width(420.dp)
                    .height(68.dp)
            ) {
                drawLine(
                    color = Color(0xFF04091A),
                    start = Offset(size.width * 0.08f, size.height * 0.62f),
                    end = Offset(size.width * 0.92f, size.height * 0.38f),
                    strokeWidth = 5f,
                    cap = StrokeCap.Round
                )
                drawLine(
                    brush = Brush.horizontalGradient(
                        listOf(Color.Transparent, NeonCyan, Color.White, NeonAmber, Color.Transparent)
                    ),
                    start = Offset(size.width * 0.05f, size.height * 0.63f),
                    end = Offset(size.width * 0.95f, size.height * 0.37f),
                    strokeWidth = 3f * (0.4f + 0.6f * glowAlpha.value),
                    cap = StrokeCap.Round
                )
            }
        }
    }
}

/**
 * Professional Commercial 3D Game Home Screen:
 * - Cinematic 3D background showing the ball on the stone platform above the animated blue ocean
 * - Clean, premium "GRAVITY BALL 3D" title typography
 * - Prominent PLAY, LEVELS, and SETTINGS buttons + top-right standalone ⚙️ icon
 * - Bottom row of 6 selectable 3D balls
 * - Strictly zero marketing slogans, zero fake stats, zero unnecessary paragraphs
 */
@Composable
private fun ProfessionalHomeScreenOverlay(
    selectedBallId: Int,
    onSelectBall: (Int) -> Unit,
    onPlay: () -> Unit,
    onOpenLevels: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "homePulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 24.dp, vertical = 14.dp)
            .testTag("title_screen_overlay")
    ) {
        // 1. Top-Left Clean Premium Title "GRAVITY BALL 3D"
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(top = 4.dp)
        ) {
            // Subtle dark shadow text for crisp contrast over daylight sky/ocean
            Text(
                text = "GRAVITY BALL 3D",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.5.sp
                ),
                color = Color(0xAA04091A),
                modifier = Modifier.offset(x = 2.dp, y = 2.dp)
            )
            Text(
                text = "GRAVITY BALL 3D",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.5.sp
                ),
                color = Color.White,
                modifier = Modifier.testTag("game_title_text")
            )
        }

        // 2. Top-Right Standalone ⚙️ Icon (no box around it)
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .size(48.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onOpenSettings
                )
                .semantics { contentDescription = "SETTINGS" }
                .testTag("top_settings_icon")
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "SETTINGS",
                tint = Color.White,
                modifier = Modifier.size(32.dp)
            )
        }

        // 3. Right-Side Commercial Action Stack: PLAY, LEVELS, SETTINGS
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .width(184.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Prominent PLAY Button
            Button(
                onClick = onPlay,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonEmerald,
                    contentColor = DeepSpaceBg
                ),
                shape = RoundedCornerShape(16.dp),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .scale(pulseScale)
                    .height(54.dp)
                    .border(2.dp, Color.White, RoundedCornerShape(16.dp))
                    .testTag("start_game_button")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "PLAY",
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 16.sp),
                    fontWeight = FontWeight.Black
                )
            }

            // LEVELS Button
            Button(
                onClick = onOpenLevels,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xD90F172A),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(16.dp),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .border(1.5.dp, NeonCyan, RoundedCornerShape(16.dp))
                    .testTag("level_select_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = NeonAmber,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "LEVELS",
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp),
                    fontWeight = FontWeight.Bold
                )
            }

            // SETTINGS Button
            Button(
                onClick = onOpenSettings,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xD90F172A),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(16.dp),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .border(1.5.dp, Color(0xFF64748B), RoundedCornerShape(16.dp))
                    .testTag("settings_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "SETTINGS",
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp),
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 4. Bottom Row of 6 Selectable 3D Balls
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 2.dp)
                .testTag("ball_selector_row"),
            horizontalArrangement = Arrangement.spacedBy(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LevelDefinitions.BALL_SKINS.forEach { skin ->
                val isSelected = skin.id == selectedBallId
                BallSelectorItem(
                    skin = skin,
                    isSelected = isSelected,
                    onClick = { onSelectBall(skin.id) }
                )
            }
        }
    }
}

@Composable
private fun BallSelectorItem(
    skin: BallSkinSpec,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 4.dp, vertical = 2.dp)
            .testTag("ball_item_${skin.id}")
    ) {
        Canvas(
            modifier = Modifier.size(if (isSelected) 52.dp else 42.dp)
        ) {
            val r = size.minDimension * 0.42f
            val center = Offset(size.width / 2f, size.height / 2f)

            val coreColor = skin.primaryColor
            val rimColor = skin.rimColor
            val bandColor = skin.secondaryColor
            val glowColor = skin.coreGlowColor

            if (isSelected) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(glowColor.copy(alpha = 0.68f), Color.Transparent),
                        center = center,
                        radius = r * 1.45f
                    ),
                    radius = r * 1.45f,
                    center = center
                )
            }

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, coreColor, rimColor, Color(0xFF050814)),
                    center = Offset(center.x - r * 0.3f, center.y - r * 0.3f),
                    radius = r * 1.35f
                ),
                radius = r,
                center = center
            )

            when (skin.id % 3) {
                0 -> {
                    drawCircle(
                        color = bandColor.copy(alpha = 0.85f),
                        radius = r * 0.68f,
                        center = center,
                        style = Stroke(width = 3f)
                    )
                }
                1 -> {
                    drawLine(
                        color = bandColor,
                        start = Offset(center.x - r * 0.75f, center.y - r * 0.25f),
                        end = Offset(center.x + r * 0.75f, center.y + r * 0.25f),
                        strokeWidth = 3.5f,
                        cap = StrokeCap.Round
                    )
                    drawLine(
                        color = glowColor,
                        start = Offset(center.x - r * 0.75f, center.y + r * 0.25f),
                        end = Offset(center.x + r * 0.75f, center.y - r * 0.25f),
                        strokeWidth = 3.5f,
                        cap = StrokeCap.Round
                    )
                }
                else -> {
                    drawCircle(
                        color = bandColor,
                        radius = r * 0.35f,
                        center = center,
                        style = Stroke(width = 3.5f)
                    )
                }
            }

            drawCircle(
                color = Color.White.copy(alpha = 0.9f),
                radius = r * 0.20f,
                center = Offset(center.x - r * 0.32f, center.y - r * 0.32f)
            )

            if (isSelected) {
                drawCircle(
                    color = Color.White,
                    radius = r * 1.12f,
                    center = center,
                    style = Stroke(width = 2.5f)
                )
            }
        }

        Spacer(modifier = Modifier.height(3.dp))

        Text(
            text = skin.name,
            style = MaterialTheme.typography.labelLarge.copy(
                fontSize = if (isSelected) 12.sp else 11.sp,
                fontWeight = if (isSelected) FontWeight.Black else FontWeight.SemiBold
            ),
            color = if (isSelected) Color.White else Color(0xFFE2E8F0)
        )
    }
}

/**
 * Clean Gameplay Screen:
 * - Top-right: PAUSE button + standalone ⚙️ Settings icon
 * - Bottom-left: Active Ball Control Widget (Joystick/Gesture, Steering Wheel, Left/Right Buttons, or Tilt)
 * - Bottom-right: Boost & Jump action pads
 * - Strictly no unnecessary text or popups
 */
@Composable
private fun CleanGameplayOverlay(
    uiState: GameUiState,
    onPause: () -> Unit,
    onOpenSettings: () -> Unit,
    onJoystickChange: (Float, Float) -> Unit,
    onJump: () -> Unit,
    onBoostChange: (Boolean) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .testTag("playing_hud_overlay")
    ) {
        // Top-right controls: PAUSE and standalone ⚙️ Settings icon
        Row(
            modifier = Modifier.align(Alignment.TopEnd),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .height(48.dp)
                    .background(Color(0xB30F172A), RoundedCornerShape(50))
                    .border(1.5.dp, NeonCyan.copy(alpha = 0.7f), RoundedCornerShape(50))
                    .clickable(onClick = onPause)
                    .padding(horizontal = 14.dp)
                    .semantics { contentDescription = "PAUSE" }
                    .testTag("pause_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Pause,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "PAUSE",
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp),
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(48.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onOpenSettings
                    )
                    .semantics { contentDescription = "SETTINGS" }
                    .testTag("hud_settings_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "SETTINGS",
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
        }

        // Bottom-Left Control Widget based on selected controlMode
        when (uiState.controlMode) {
            BallControlMode.GESTURE -> {
                GesturePadControl(
                    onVectorChanged = onJoystickChange,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 6.dp, bottom = 6.dp)
                )
            }

            BallControlMode.STEERING -> {
                SteeringWheelControl(
                    onSteerChanged = { steerX, forwardZ ->
                        onJoystickChange(steerX, forwardZ)
                    },
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 6.dp, bottom = 6.dp)
                )
            }

            BallControlMode.BUTTONS -> {
                LeftRightButtonControls(
                    onDirectionChanged = { x, z -> onJoystickChange(x, z) },
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 6.dp, bottom = 10.dp)
                )
            }

            BallControlMode.TILT -> {
                TiltForwardPad(
                    onForwardChange = { forwardZ -> onJoystickChange(0f, forwardZ) },
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 6.dp, bottom = 10.dp)
                )
            }
        }

        // Bottom-Right Action Pads (Boost & Jump)
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 6.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(if (uiState.isBoosting) NeonAmber else Color(0x99111A36))
                    .border(2.dp, NeonAmber, CircleShape)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                onBoostChange(true)
                                tryAwaitRelease()
                                onBoostChange(false)
                            }
                        )
                    }
                    .semantics { contentDescription = "Boost" }
                    .testTag("boost_button")
            ) {
                Canvas(modifier = Modifier.size(28.dp)) {
                    val path = Path().apply {
                        moveTo(size.width * 0.55f, 0f)
                        lineTo(size.width * 0.15f, size.height * 0.55f)
                        lineTo(size.width * 0.50f, size.height * 0.55f)
                        lineTo(size.width * 0.35f, size.height)
                        lineTo(size.width * 0.85f, size.height * 0.42f)
                        lineTo(size.width * 0.50f, size.height * 0.42f)
                        close()
                    }
                    drawPath(
                        path = path,
                        color = if (uiState.isBoosting) DeepSpaceBg else NeonAmber
                    )
                }
            }

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(78.dp)
                    .clip(CircleShape)
                    .background(NeonCyan.copy(alpha = 0.88f))
                    .border(2.5.dp, Color.White, CircleShape)
                    .clickable { onJump() }
                    .semantics { contentDescription = "Jump" }
                    .testTag("jump_button")
            ) {
                Icon(
                    imageVector = Icons.Default.KeyboardArrowUp,
                    contentDescription = "Jump",
                    tint = DeepSpaceBg,
                    modifier = Modifier.size(42.dp)
                )
            }
        }
    }
}

@Composable
private fun GesturePadControl(
    onVectorChanged: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var knobOffset by remember { mutableStateOf(Offset.Zero) }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(144.dp)
            .clip(CircleShape)
            .background(Color(0x880B132B))
            .border(2.dp, NeonCyan.copy(alpha = 0.65f), CircleShape)
            .pointerInput(Unit) {
                val maxRadius = size.width * 0.35f
                detectDragGestures(
                    onDragStart = { startPos ->
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val delta = startPos - center
                        val dist = hypot(delta.x, delta.y)
                        val clamped = if (dist > maxRadius && dist > 0f) {
                            delta * (maxRadius / dist)
                        } else {
                            delta
                        }
                        knobOffset = clamped
                        onVectorChanged(clamped.x / maxRadius, clamped.y / maxRadius)
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val next = knobOffset + dragAmount
                        val dist = hypot(next.x, next.y)
                        val clamped = if (dist > maxRadius && dist > 0f) {
                            next * (maxRadius / dist)
                        } else {
                            next
                        }
                        knobOffset = clamped
                        onVectorChanged(clamped.x / maxRadius, clamped.y / maxRadius)
                    },
                    onDragEnd = {
                        knobOffset = Offset.Zero
                        onVectorChanged(0f, 0f)
                    },
                    onDragCancel = {
                        knobOffset = Offset.Zero
                        onVectorChanged(0f, 0f)
                    }
                )
            }
            .clickable { onVectorChanged(0f, -0.85f) }
            .semantics { contentDescription = "Virtual Joystick" }
            .testTag("virtual_joystick")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            drawCircle(
                color = NeonCyan.copy(alpha = 0.25f),
                radius = size.minDimension * 0.34f,
                center = center,
                style = Stroke(width = 2.5f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, NeonCyan),
                    center = center + knobOffset
                ),
                radius = size.minDimension * 0.17f,
                center = center + knobOffset
            )
        }
    }
}

@Composable
private fun SteeringWheelControl(
    onSteerChanged: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var wheelAngleDeg by remember { mutableFloatStateOf(0f) }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(148.dp)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { pos ->
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val dx = pos.x - center.x
                        val dy = pos.y - center.y
                        val angle = Math.toDegrees(atan2(dx.toDouble(), (-dy).toDouble())).toFloat()
                        wheelAngleDeg = angle.coerceIn(-75f, 75f)
                        val steerX = (wheelAngleDeg / 75f).coerceIn(-1f, 1f)
                        onSteerChanged(steerX, -0.85f)
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val dx = change.position.x - center.x
                        val dy = change.position.y - center.y
                        val angle = Math.toDegrees(atan2(dx.toDouble(), (-dy).toDouble())).toFloat()
                        wheelAngleDeg = angle.coerceIn(-75f, 75f)
                        val steerX = (wheelAngleDeg / 75f).coerceIn(-1f, 1f)
                        onSteerChanged(steerX, -0.85f)
                    },
                    onDragEnd = {
                        wheelAngleDeg = 0f
                        onSteerChanged(0f, 0f)
                    },
                    onDragCancel = {
                        wheelAngleDeg = 0f
                        onSteerChanged(0f, 0f)
                    }
                )
            }
            .semantics { contentDescription = "Steering Wheel" }
            .testTag("steering_wheel_control")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val outerR = size.minDimension * 0.43f
            val innerR = size.minDimension * 0.16f

            rotate(degrees = wheelAngleDeg, pivot = center) {
                drawCircle(
                    color = Color(0xAA0B132B),
                    radius = outerR,
                    center = center
                )
                drawCircle(
                    color = NeonCyan,
                    radius = outerR,
                    center = center,
                    style = Stroke(width = 14f)
                )
                drawArc(
                    color = NeonAmber,
                    startAngle = -108f,
                    sweepAngle = 36f,
                    useCenter = false,
                    topLeft = Offset(center.x - outerR, center.y - outerR),
                    size = androidx.compose.ui.geometry.Size(outerR * 2f, outerR * 2f),
                    style = Stroke(width = 15f, cap = StrokeCap.Round)
                )
                val spokeAngles = listOf(0f, 180f, 90f)
                spokeAngles.forEach { aDeg ->
                    val rad = Math.toRadians(aDeg.toDouble())
                    val endX = center.x + cos(rad).toFloat() * outerR * 0.92f
                    val endY = center.y + sin(rad).toFloat() * outerR * 0.92f
                    drawLine(
                        color = Color.White.copy(alpha = 0.85f),
                        start = center,
                        end = Offset(endX, endY),
                        strokeWidth = 9f,
                        cap = StrokeCap.Round
                    )
                }
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(NeonCyan, DeepSpaceBg),
                        center = center,
                        radius = innerR
                    ),
                    radius = innerR,
                    center = center
                )
            }
        }
    }
}

@Composable
private fun LeftRightButtonControls(
    onDirectionChanged: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var leftPressed by remember { mutableStateOf(false) }
    var rightPressed by remember { mutableStateOf(false) }

    Row(
        modifier = modifier.testTag("left_right_buttons_control"),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(74.dp)
                .clip(CircleShape)
                .background(if (leftPressed) NeonCyan else Color(0x99111A36))
                .border(2.5.dp, NeonCyan, CircleShape)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            leftPressed = true
                            onDirectionChanged(-0.9f, -0.8f)
                            tryAwaitRelease()
                            leftPressed = false
                            onDirectionChanged(0f, 0f)
                        }
                    )
                }
                .semantics { contentDescription = "Left" }
                .testTag("left_move_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                contentDescription = "Left",
                tint = if (leftPressed) DeepSpaceBg else Color.White,
                modifier = Modifier.size(44.dp)
            )
        }

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(74.dp)
                .clip(CircleShape)
                .background(if (rightPressed) NeonCyan else Color(0x99111A36))
                .border(2.5.dp, NeonCyan, CircleShape)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            rightPressed = true
                            onDirectionChanged(0.9f, -0.8f)
                            tryAwaitRelease()
                            rightPressed = false
                            onDirectionChanged(0f, 0f)
                        }
                    )
                }
                .semantics { contentDescription = "Right" }
                .testTag("right_move_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Right",
                tint = if (rightPressed) DeepSpaceBg else Color.White,
                modifier = Modifier.size(44.dp)
            )
        }
    }
}

@Composable
private fun TiltForwardPad(
    onForwardChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(76.dp)
            .clip(CircleShape)
            .background(if (pressed) NeonEmerald else Color(0x88111A36))
            .border(2.dp, NeonEmerald, CircleShape)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        onForwardChange(-0.95f)
                        tryAwaitRelease()
                        pressed = false
                        onForwardChange(0f)
                    }
                )
            }
            .semantics { contentDescription = "Tilt Drive" }
            .testTag("tilt_drive_pad")
    ) {
        Icon(
            imageVector = Icons.Default.ScreenRotation,
            contentDescription = "Tilt Active",
            tint = if (pressed) DeepSpaceBg else NeonEmerald,
            modifier = Modifier.size(34.dp)
        )
    }
}

/**
 * Pause Modal using strictly essential labels:
 * PAUSE, RESUME, RESTART, LEVELS, SETTINGS, HOME
 */
@Composable
private fun PauseModalOverlay(
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onLevels: () -> Unit,
    onSettings: () -> Unit,
    onHome: () -> Unit
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xB3060B1E))
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(16.dp)
            .testTag("pause_modal_overlay")
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .background(CosmicSurface, RoundedCornerShape(22.dp))
                .border(1.5.dp, BorderGlow, RoundedCornerShape(22.dp))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "PAUSE",
                style = MaterialTheme.typography.headlineMedium,
                color = NeonCyan
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onResume,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald, contentColor = DeepSpaceBg),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("resume_button")
                ) {
                    Text(text = "RESUME", fontWeight = FontWeight.Black)
                }

                OutlinedButton(
                    onClick = onRestart,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("restart_button")
                ) {
                    Text(text = "RESTART", color = NeonAmber, fontWeight = FontWeight.Bold)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onLevels,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("pause_level_select_button")
                ) {
                    Text(text = "LEVELS", color = TextPrimary, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onSettings,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("pause_settings_button")
                ) {
                    Text(text = "SETTINGS", color = NeonCyan, fontWeight = FontWeight.Bold)
                }
            }

            OutlinedButton(
                onClick = onHome,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("main_menu_button")
            ) {
                Text(text = "HOME", color = TextPrimary, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * Settings Modal with the 4 Control Modes and strictly essential labels:
 * SETTINGS, RESUME, RESTART, HOME
 */
@Composable
private fun SettingsControlModal(
    uiState: GameUiState,
    onSelectControlMode: (BallControlMode) -> Unit,
    onToggleMute: () -> Unit,
    onRestart: () -> Unit,
    onHome: () -> Unit,
    onClose: () -> Unit
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC050918))
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(16.dp)
            .testTag("settings_modal")
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .background(CosmicSurface, RoundedCornerShape(24.dp))
                .border(1.5.dp, BorderGlow, RoundedCornerShape(24.dp))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(26.dp)
                    )
                    Text(
                        text = "SETTINGS",
                        style = MaterialTheme.typography.titleMedium.copy(fontSize = 20.sp),
                        color = Color.White,
                        fontWeight = FontWeight.Black
                    )
                }

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(CosmicCard)
                        .clickable(onClick = onClose)
                        .testTag("close_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White
                    )
                }
            }

            // 4 Control Mode Cards (Gesture, Steering Wheel, Left/Right Buttons, Tilt Phone)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ControlModeOptionCard(
                    isSelected = uiState.controlMode == BallControlMode.GESTURE,
                    accentColor = NeonCyan,
                    onClick = { onSelectControlMode(BallControlMode.GESTURE) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("control_mode_gesture")
                ) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = "Gesture",
                        tint = if (uiState.controlMode == BallControlMode.GESTURE) NeonCyan else TextSecondary,
                        modifier = Modifier.size(36.dp)
                    )
                }

                ControlModeOptionCard(
                    isSelected = uiState.controlMode == BallControlMode.STEERING,
                    accentColor = NeonAmber,
                    onClick = { onSelectControlMode(BallControlMode.STEERING) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("control_mode_steering")
                ) {
                    Canvas(modifier = Modifier.size(36.dp)) {
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val r = size.minDimension * 0.42f
                        val col = if (uiState.controlMode == BallControlMode.STEERING) NeonAmber else TextSecondary
                        drawCircle(color = col, radius = r, center = c, style = Stroke(width = 4f))
                        drawCircle(color = col, radius = r * 0.28f, center = c)
                        drawLine(col, Offset(c.x - r, c.y), Offset(c.x + r, c.y), strokeWidth = 3f)
                        drawLine(col, c, Offset(c.x, c.y + r), strokeWidth = 3f)
                    }
                }

                ControlModeOptionCard(
                    isSelected = uiState.controlMode == BallControlMode.BUTTONS,
                    accentColor = NeonPurple,
                    onClick = { onSelectControlMode(BallControlMode.BUTTONS) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("control_mode_buttons")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val col = if (uiState.controlMode == BallControlMode.BUTTONS) NeonPurple else TextSecondary
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                            contentDescription = "Left",
                            tint = col,
                            modifier = Modifier.size(30.dp)
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Right",
                            tint = col,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }

                ControlModeOptionCard(
                    isSelected = uiState.controlMode == BallControlMode.TILT,
                    accentColor = NeonEmerald,
                    onClick = { onSelectControlMode(BallControlMode.TILT) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("control_mode_tilt")
                ) {
                    Icon(
                        imageVector = Icons.Default.ScreenRotation,
                        contentDescription = "Tilt",
                        tint = if (uiState.controlMode == BallControlMode.TILT) NeonEmerald else TextSecondary,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            // Bottom Row of Essential Actions: Sound Icon, RESUME, RESTART, HOME
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onToggleMute,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("settings_mute_button")
                ) {
                    Icon(
                        imageVector = if (uiState.isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Audio",
                        tint = if (uiState.isMuted) NeonRose else NeonCyan,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald, contentColor = DeepSpaceBg),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("settings_resume_button")
                ) {
                    Text(
                        text = "RESUME",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                OutlinedButton(
                    onClick = onRestart,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("restart_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = NeonAmber,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "RESTART",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onHome,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("main_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "HOME",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun ControlModeOptionCard(
    isSelected: Boolean,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    iconContent: @Composable () -> Unit
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .height(82.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) accentColor.copy(alpha = 0.22f) else CosmicCard)
            .border(
                width = if (isSelected) 2.5.dp else 1.dp,
                color = if (isSelected) accentColor else Color(0xFF2D3A5E),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .padding(8.dp)
    ) {
        iconContent()
    }
}

/**
 * Level Selection Screen using strictly essential labels:
 * HOME, LEVELS, 1..10, PLAY
 */
@Composable
private fun LevelSelectGridScreen(
    levels: List<LevelProgressEntity>,
    selectedLevelId: Int,
    onSelectAndPlay: (Int) -> Unit,
    onBackToHome: () -> Unit
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xD9060B1E))
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .testTag("level_select_modal")
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 820.dp)
                .fillMaxSize()
                .background(CosmicSurface, RoundedCornerShape(22.dp))
                .border(1.5.dp, BorderGlow, RoundedCornerShape(22.dp))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onBackToHome,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("close_level_select_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "HOME",
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "HOME",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "LEVELS",
                    style = MaterialTheme.typography.headlineMedium.copy(fontSize = 22.sp),
                    color = NeonCyan
                )

                Spacer(modifier = Modifier.width(88.dp))
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 140.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .testTag("level_select_grid"),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(levels, key = { it.levelId }) { lvl ->
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (lvl.levelId == selectedLevelId) Color(0xFF1A2A52) else CosmicCard
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = if (lvl.levelId == selectedLevelId) 2.dp else 1.dp,
                                color = when {
                                    lvl.isCompleted -> NeonEmerald
                                    lvl.isUnlocked -> NeonCyan.copy(alpha = 0.65f)
                                    else -> Color(0xFF334155)
                                },
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable(enabled = lvl.isUnlocked) {
                                onSelectAndPlay(lvl.levelId)
                            }
                            .testTag("level_card_${lvl.levelId}")
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 14.dp, horizontal = 10.dp)
                        ) {
                            Text(
                                text = "${lvl.levelId}",
                                style = MaterialTheme.typography.headlineMedium,
                                color = if (lvl.isUnlocked) Color.White else TextSecondary,
                                fontWeight = FontWeight.Black
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            if (lvl.isUnlocked) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    if (lvl.isCompleted) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = NeonEmerald,
                                            modifier = Modifier
                                                .size(16.dp)
                                                .padding(end = 2.dp)
                                        )
                                    }
                                    for (s in 1..3) {
                                        Icon(
                                            imageVector = if (s <= lvl.stars) Icons.Default.Star else Icons.Outlined.StarOutline,
                                            contentDescription = null,
                                            tint = if (s <= lvl.stars) NeonAmber else TextSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Button(
                                    onClick = { onSelectAndPlay(lvl.levelId) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (lvl.isCompleted) NeonEmerald else NeonCyan,
                                        contentColor = DeepSpaceBg
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 2.dp),
                                    modifier = Modifier
                                        .height(32.dp)
                                        .testTag("play_level_button_${lvl.levelId}")
                                ) {
                                    Text(
                                        text = "PLAY",
                                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = TextSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Level Complete Modal using strictly essential labels:
 * LEVEL COMPLETE, PLAY, RETRY, LEVELS, HOME
 */
@Composable
private fun LevelCompleteModalOverlay(
    stars: Int,
    onNextLevel: () -> Unit,
    onRetry: () -> Unit,
    onLevels: () -> Unit,
    onHome: () -> Unit
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xB3060B1E))
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(16.dp)
            .testTag("level_complete_modal")
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .background(CosmicSurface, RoundedCornerShape(22.dp))
                .border(2.dp, NeonEmerald, RoundedCornerShape(22.dp))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "LEVEL COMPLETE",
                style = MaterialTheme.typography.headlineMedium,
                color = NeonEmerald,
                textAlign = TextAlign.Center
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 1..3) {
                    Icon(
                        imageVector = if (i <= stars) Icons.Default.Star else Icons.Outlined.StarOutline,
                        contentDescription = null,
                        tint = if (i <= stars) NeonAmber else TextSecondary,
                        modifier = Modifier.size(34.dp)
                    )
                }
            }

            Button(
                onClick = onNextLevel,
                colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald, contentColor = DeepSpaceBg),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("next_level_button")
            ) {
                Text(
                    text = "PLAY",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onRetry,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("victory_replay_button")
                ) {
                    Text(text = "RETRY", color = NeonCyan, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onLevels,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("victory_levels_button")
                ) {
                    Text(text = "LEVELS", color = TextPrimary, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onHome,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("victory_menu_button")
                ) {
                    Text(text = "HOME", color = TextPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
