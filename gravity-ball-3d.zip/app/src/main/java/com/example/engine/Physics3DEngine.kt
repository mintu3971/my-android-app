package com.example.engine

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.ui.graphics.Color
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class ObbCollider(
    val id: String,
    val basePosition: Vec3,
    val position: Vec3,
    val prevPosition: Vec3,
    val halfExtents: Vec3,
    val quaternion: Quat,
    val color: Color,
    val trimColor: Color,
    val friction: Float = 0.9f,
    val restitution: Float = 0.18f,
    val isHazardBumper: Boolean = false,
    val knockbackStrength: Float = 11.5f,
    val isRotatingHub: Boolean = false,
    val isTimedGate: Boolean = false,
    val renderMesh: Boolean = true,
    val platformStyle: PlatformStyle = PlatformStyle.STONE_PATH,
    val rotatingKind: RotatingKind? = null,
    val obstacleKind: ObstacleKind? = null,
    val hasPillar: Boolean = false,
    val hasRails: Boolean = false,
    val kinematicUpdate: ((ObbCollider, Float) -> Unit)? = null
) {
    val linearVelocity = Vec3()
    val angularVelocity = Vec3()
    var currentAngleRad: Float = 0f
}

class Physics3DEngine {
    private val baseGravity = -24.0f
    private val substeps = 4

    val ballRadius = 0.65f
    val ballPosition = Vec3(0f, 1.8f, 0f)
    val ballVelocity = Vec3(0f, 0f, 0f)
    val ballQuaternion = Quat()
    val ballAngularVelocity = Vec3(0f, 0f, 0f)
    var ballGrounded = false
    var coyoteTimer = 0f
    var jumpBufferTimer = 0f
    var ballSquash = 0f

    // Active ball power multipliers
    var activeSkin: BallSkinSpec = LevelDefinitions.BALL_SKINS[0]

    val colliders = mutableListOf<ObbCollider>()

    private val localPos = Vec3()
    private val closestLocal = Vec3()
    private val diffLocal = Vec3()
    private val worldNormal = Vec3()
    private val worldContact = Vec3()
    private val relPoint = Vec3()
    private val surfaceVel = Vec3()
    private val relVel = Vec3()
    private val tangentVel = Vec3()
    private val invQuat = Quat()
    private val deltaQuat = Quat()
    private val rotAxis = Vec3()
    private val diffPos = Vec3()

    fun clearColliders() {
        colliders.clear()
    }

    fun loadCourseColliders(level: CourseLevelSpec) {
        clearColliders()

        level.platforms.forEachIndexed { idx, p ->
            val q = Quat().setFromEulerYXZ(p.pitch, p.yaw, 0f)
            val pos = Vec3(p.x, p.y, p.z)
            colliders.add(
                ObbCollider(
                    id = "plat_$idx",
                    basePosition = pos.clone(),
                    position = pos.clone(),
                    prevPosition = pos.clone(),
                    halfExtents = Vec3(p.w * 0.5f, p.h * 0.5f, p.d * 0.5f),
                    quaternion = q.clone(),
                    color = p.color,
                    trimColor = p.trim,
                    friction = 0.9f,
                    platformStyle = p.style,
                    hasPillar = p.hasPillar,
                    hasRails = p.hasRails
                )
            )

            if (p.hasRails) {
                val railH = 0.55f
                val railW = 0.28f
                for (side in intArrayOf(-1, 1)) {
                    val localOff = Vec3(
                        side * (p.w * 0.5f - railW * 0.5f),
                        p.h * 0.5f + railH * 0.5f,
                        0f
                    )
                    val rotatedOff = q.transform(localOff)
                    val railPos = Vec3(p.x + rotatedOff.x, p.y + rotatedOff.y, p.z + rotatedOff.z)
                    colliders.add(
                        ObbCollider(
                            id = "rail_${idx}_$side",
                            basePosition = railPos.clone(),
                            position = railPos.clone(),
                            prevPosition = railPos.clone(),
                            halfExtents = Vec3(railW * 0.5f, railH * 0.5f, p.d * 0.5f),
                            quaternion = q.clone(),
                            color = p.trim,
                            trimColor = p.color,
                            restitution = 0.35f,
                            renderMesh = true,
                            platformStyle = p.style
                        )
                    )
                }
            }
        }

        level.rotatingPlatforms.forEachIndexed { idx, rp ->
            val pos = Vec3(rp.x, rp.y, rp.z)
            when (rp.kind) {
                RotatingKind.ROTATING_FAN -> {
                    // Blade 1 & 2 (0 degrees)
                    colliders.add(
                        ObbCollider(
                            id = "fan_bladeA_$idx",
                            basePosition = pos.clone(),
                            position = pos.clone(),
                            prevPosition = pos.clone(),
                            halfExtents = Vec3(rp.w * 0.5f, rp.h * 0.42f, 0.36f),
                            quaternion = Quat(),
                            color = rp.color,
                            trimColor = rp.trim,
                            friction = 0.8f,
                            isHazardBumper = true,
                            knockbackStrength = 12.0f,
                            isRotatingHub = true,
                            rotatingKind = RotatingKind.ROTATING_FAN,
                            kinematicUpdate = { col, t ->
                                val angle = t * rp.speed
                                col.currentAngleRad = angle
                                col.quaternion.setFromAxisAngle(0f, 1f, 0f, angle)
                                col.angularVelocity.set(0f, rp.speed, 0f)
                            }
                        )
                    )
                    // Blade 3 & 4 (90 degrees perpendicular for a 4-blade fan)
                    colliders.add(
                        ObbCollider(
                            id = "fan_bladeB_$idx",
                            basePosition = pos.clone(),
                            position = pos.clone(),
                            prevPosition = pos.clone(),
                            halfExtents = Vec3(rp.w * 0.5f, rp.h * 0.42f, 0.36f),
                            quaternion = Quat(),
                            color = rp.color,
                            trimColor = rp.trim,
                            friction = 0.8f,
                            isHazardBumper = true,
                            knockbackStrength = 12.0f,
                            isRotatingHub = false,
                            rotatingKind = RotatingKind.ROTATING_FAN,
                            kinematicUpdate = { col, t ->
                                val angle = t * rp.speed + (PI.toFloat() * 0.5f)
                                col.currentAngleRad = angle
                                col.quaternion.setFromAxisAngle(0f, 1f, 0f, angle)
                                col.angularVelocity.set(0f, rp.speed, 0f)
                            }
                        )
                    )
                }

                RotatingKind.ROTATING_CUTTER -> {
                    colliders.add(
                        ObbCollider(
                            id = "cutter_$idx",
                            basePosition = pos.clone(),
                            position = pos.clone(),
                            prevPosition = pos.clone(),
                            halfExtents = Vec3(rp.w * 0.5f, rp.h * 0.46f, rp.d * 0.46f),
                            quaternion = Quat(),
                            color = rp.color,
                            trimColor = rp.trim,
                            friction = 0.8f,
                            isHazardBumper = true,
                            knockbackStrength = 13.0f,
                            isRotatingHub = true,
                            rotatingKind = RotatingKind.ROTATING_CUTTER,
                            kinematicUpdate = { col, t ->
                                val angle = t * rp.speed
                                col.currentAngleRad = angle
                                col.angularVelocity.set(rp.speed, 0f, 0f)
                            }
                        )
                    )
                }

                else -> {
                    colliders.add(
                        ObbCollider(
                            id = "rot_$idx",
                            basePosition = pos.clone(),
                            position = pos.clone(),
                            prevPosition = pos.clone(),
                            halfExtents = Vec3(rp.w * 0.5f, rp.h * 0.5f, rp.d * 0.5f),
                            quaternion = Quat(),
                            color = rp.color,
                            trimColor = rp.trim,
                            friction = 0.95f,
                            isHazardBumper = rp.isHazard,
                            knockbackStrength = if (rp.isHazard) 11.5f else 0f,
                            isRotatingHub = true,
                            platformStyle = PlatformStyle.WOOD_BRIDGE,
                            rotatingKind = rp.kind,
                            kinematicUpdate = { col, t ->
                                val angle = t * rp.speed
                                col.currentAngleRad = angle
                                col.quaternion.setFromAxisAngle(0f, 1f, 0f, angle)
                                col.angularVelocity.set(0f, rp.speed, 0f)
                            }
                        )
                    )
                }
            }
        }

        level.movingObstacles.forEachIndexed { idx, mo ->
            val pos = Vec3(mo.x, mo.y, mo.z)
            colliders.add(
                ObbCollider(
                    id = "mov_$idx",
                    basePosition = pos.clone(),
                    position = pos.clone(),
                    prevPosition = pos.clone(),
                    halfExtents = Vec3(mo.w * 0.5f, mo.h * 0.5f, mo.d * 0.5f),
                    quaternion = Quat(),
                    color = mo.color,
                    trimColor = mo.trim,
                    friction = 0.98f,
                    isHazardBumper = mo.isHazard,
                    knockbackStrength = if (mo.isHazard) 12.5f else 0f,
                    isTimedGate = mo.kind == ObstacleKind.TIMED_GATE,
                    platformStyle = if (mo.kind == ObstacleKind.FERRY) PlatformStyle.WOOD_BRIDGE else PlatformStyle.METALLIC_TECH,
                    obstacleKind = mo.kind,
                    kinematicUpdate = { col, t ->
                        val offset = sin(t * mo.speed + mo.phase) * mo.amplitude
                        col.position.copyFrom(col.basePosition)
                        when (mo.axis) {
                            'x' -> col.position.x += offset
                            'y' -> col.position.y += offset
                            'z' -> col.position.z += offset
                        }
                        if (mo.kind == ObstacleKind.SAW_CUTTER) {
                            col.currentAngleRad = t * 6.5f
                        }
                    }
                )
            )
        }
    }

    fun resetBall(spawn: Vec3) {
        ballPosition.copyFrom(spawn)
        ballVelocity.set(0f, 0f, 0f)
        ballAngularVelocity.set(0f, 0f, 0f)
        ballQuaternion.identity()
        ballGrounded = false
        coyoteTimer = 0f
        jumpBufferTimer = 0f
        ballSquash = 0f
    }

    fun requestJump() {
        jumpBufferTimer = 0.16f
    }

    fun updateKinematicsOnly(elapsedTime: Float) {
        for (i in 0 until colliders.size) {
            val col = colliders[i]
            col.kinematicUpdate?.invoke(col, elapsedTime)
        }
    }

    fun step(
        dt: Float,
        worldMoveX: Float,
        worldMoveZ: Float,
        boost: Boolean,
        elapsedTime: Float,
        onJump: () -> Unit,
        onHeavyLand: (Float) -> Unit,
        onHazardHit: () -> Unit
    ) {
        val clampedDt = dt.coerceIn(0.001f, 0.05f)
        val subDt = clampedDt / substeps
        val skin = activeSkin

        if (coyoteTimer > 0f) coyoteTimer = max(0f, coyoteTimer - clampedDt)
        if (jumpBufferTimer > 0f) jumpBufferTimer = max(0f, jumpBufferTimer - clampedDt)

        var maxImpact = 0f
        var hitHazard = false

        for (s in 0 until substeps) {
            val stepTime = elapsedTime - clampedDt + (s + 1) * subDt

            for (i in 0 until colliders.size) {
                val col = colliders[i]
                val updater = col.kinematicUpdate
                if (updater != null) {
                    col.prevPosition.copyFrom(col.position)
                    updater(col, stepTime)
                    col.linearVelocity.set(
                        (col.position.x - col.prevPosition.x) / subDt,
                        (col.position.y - col.prevPosition.y) / subDt,
                        (col.position.z - col.prevPosition.z) / subDt
                    )
                }
            }

            val moveAccel = (if (ballGrounded) 27.0f else 16.5f) * skin.speedMult
            val boostMult = if (boost) 1.42f else 1.0f
            val maxSpeed = (if (boost) 18.0f else 13.2f) * skin.speedMult

            ballVelocity.x += worldMoveX * moveAccel * boostMult * subDt
            ballVelocity.z += worldMoveZ * moveAccel * boostMult * subDt

            val horizSpeedSq = ballVelocity.x * ballVelocity.x + ballVelocity.z * ballVelocity.z
            if (horizSpeedSq > maxSpeed * maxSpeed) {
                val horizSpeed = sqrt(horizSpeedSq)
                val blended = horizSpeed + (maxSpeed - horizSpeed) * min(1f, subDt * 6.0f)
                val scale = blended / horizSpeed
                ballVelocity.x *= scale
                ballVelocity.z *= scale
            }

            val airDamp = exp(-0.35f * subDt)
            ballVelocity.x *= airDamp
            ballVelocity.z *= airDamp
            ballVelocity.y += (baseGravity * skin.gravityMult) * subDt

            ballPosition.addScaled(ballVelocity, subDt)

            var frameGrounded = false
            for (i in 0 until colliders.size) {
                val col = colliders[i]
                col.quaternion.invertTo(invQuat)
                diffPos.set(
                    ballPosition.x - col.position.x,
                    ballPosition.y - col.position.y,
                    ballPosition.z - col.position.z
                )
                invQuat.transform(diffPos, localPos)

                val hx = col.halfExtents.x
                val hy = col.halfExtents.y
                val hz = col.halfExtents.z
                val r = ballRadius

                if (
                    abs(localPos.x) > hx + r ||
                    abs(localPos.y) > hy + r ||
                    abs(localPos.z) > hz + r
                ) {
                    continue
                }

                closestLocal.set(
                    localPos.x.coerceIn(-hx, hx),
                    localPos.y.coerceIn(-hy, hy),
                    localPos.z.coerceIn(-hz, hz)
                )
                diffLocal.set(
                    localPos.x - closestLocal.x,
                    localPos.y - closestLocal.y,
                    localPos.z - closestLocal.z
                )
                val distSq = diffLocal.lengthSq()

                if (distSq <= r * r) {
                    val dist = sqrt(distSq)
                    val penetration: Float
                    if (dist > 1e-5f) {
                        diffLocal.x /= dist
                        diffLocal.y /= dist
                        diffLocal.z /= dist
                        penetration = r - dist
                    } else {
                        val dx = hx - abs(localPos.x)
                        val dy = hy - abs(localPos.y)
                        val dz = hz - abs(localPos.z)
                        if (dy <= dx && dy <= dz) {
                            diffLocal.set(0f, if (localPos.y >= 0f) 1f else -1f, 0f)
                            penetration = dy + r
                        } else if (dx <= dz) {
                            diffLocal.set(if (localPos.x >= 0f) 1f else -1f, 0f, 0f)
                            penetration = dx + r
                        } else {
                            diffLocal.set(0f, 0f, if (localPos.z >= 0f) 1f else -1f)
                            penetration = dz + r
                        }
                    }

                    col.quaternion.transform(diffLocal, worldNormal).normalize()
                    col.quaternion.transform(closestLocal, worldContact)
                    worldContact.x += col.position.x
                    worldContact.y += col.position.y
                    worldContact.z += col.position.z

                    ballPosition.addScaled(worldNormal, penetration)

                    relPoint.set(
                        worldContact.x - col.position.x,
                        worldContact.y - col.position.y,
                        worldContact.z - col.position.z
                    )
                    Vec3.cross(col.angularVelocity, relPoint, surfaceVel)
                    surfaceVel.addScaled(col.linearVelocity, 1f)

                    relVel.set(
                        ballVelocity.x - surfaceVel.x,
                        ballVelocity.y - surfaceVel.y,
                        ballVelocity.z - surfaceVel.z
                    )
                    val normalVel = relVel.dot(worldNormal)

                    if (normalVel < 0f) {
                        val impactSpeed = -normalVel
                        if (impactSpeed > maxImpact) maxImpact = impactSpeed
                        val bounce = if (impactSpeed > 3.2f) col.restitution else 0f
                        val normalImpulse = -(1f + bounce) * normalVel
                        ballVelocity.addScaled(worldNormal, normalImpulse)

                        relVel.set(
                            ballVelocity.x - surfaceVel.x,
                            ballVelocity.y - surfaceVel.y,
                            ballVelocity.z - surfaceVel.z
                        )
                        val newNormalVel = relVel.dot(worldNormal)
                        tangentVel.copyFrom(relVel).addScaled(worldNormal, -newNormalVel)

                        val idleFactor = if (abs(worldMoveX) < 0.08f && abs(worldMoveZ) < 0.08f) 9.5f else 3.2f
                        val grip = min(1f, col.friction * skin.gripMult * subDt * idleFactor)
                        ballVelocity.addScaled(tangentVel, -grip)
                    }

                    if (col.isHazardBumper) {
                        val pushX = worldNormal.x
                        val pushY = max(0.28f, worldNormal.y + 0.25f)
                        val pushZ = worldNormal.z
                        val pushLen = sqrt(pushX * pushX + pushY * pushY + pushZ * pushZ).coerceAtLeast(1e-4f)
                        val kb = col.knockbackStrength / skin.gripMult.coerceAtLeast(1f)
                        ballVelocity.x += (pushX / pushLen) * kb
                        ballVelocity.y += (pushY / pushLen) * kb
                        ballVelocity.z += (pushZ / pushLen) * kb
                        hitHazard = true
                    }

                    if (worldNormal.y > 0.52f) {
                        frameGrounded = true
                        ballGrounded = true
                        coyoteTimer = 0.16f
                        relVel.set(
                            ballVelocity.x - surfaceVel.x,
                            ballVelocity.y - surfaceVel.y,
                            ballVelocity.z - surfaceVel.z
                        )
                        Vec3.cross(worldNormal, relVel, ballAngularVelocity)
                        ballAngularVelocity.x /= ballRadius
                        ballAngularVelocity.y /= ballRadius
                        ballAngularVelocity.z /= ballRadius
                    }
                }
            }

            if (!frameGrounded) {
                ballGrounded = false
            }

            if (jumpBufferTimer > 0f && coyoteTimer > 0f) {
                ballVelocity.y = max(ballVelocity.y, 10.6f * skin.jumpMult)
                ballPosition.y += 0.05f
                ballGrounded = false
                coyoteTimer = 0f
                jumpBufferTimer = 0f
                ballSquash = 0.28f
                onJump()
            }

            val angSpeed = ballAngularVelocity.length()
            if (angSpeed > 0.001f) {
                rotAxis.set(
                    ballAngularVelocity.x / angSpeed,
                    ballAngularVelocity.y / angSpeed,
                    ballAngularVelocity.z / angSpeed
                )
                deltaQuat.setFromAxisAngle(rotAxis.x, rotAxis.y, rotAxis.z, angSpeed * subDt)
                ballQuaternion.premultiply(deltaQuat)
            }
        }

        if (abs(ballSquash) > 0.002f) {
            ballSquash *= exp(-12.0f * clampedDt)
        } else {
            ballSquash = 0f
        }

        if (hitHazard) {
            onHazardHit()
        } else if (maxImpact > 4.2f) {
            onHeavyLand(((maxImpact - 4.0f) / 14.0f).coerceIn(0.1f, 1.0f))
        }
    }
}

class NativeSoundSynth {
    private var toneGen: ToneGenerator? = null

    private fun ensureGen(): ToneGenerator? {
        if (toneGen == null) {
            try {
                toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 55)
            } catch (_: Exception) {
            }
        }
        return toneGen
    }

    fun playJump(muted: Boolean) {
        if (muted) return
        try {
            ensureGen()?.startTone(ToneGenerator.TONE_PROP_BEEP, 45)
        } catch (_: Exception) {}
    }

    fun playCheckpoint(muted: Boolean) {
        if (muted) return
        try {
            ensureGen()?.startTone(ToneGenerator.TONE_PROP_ACK, 90)
        } catch (_: Exception) {}
    }

    fun playHazard(muted: Boolean) {
        if (muted) return
        try {
            ensureGen()?.startTone(ToneGenerator.TONE_PROP_NACK, 80)
        } catch (_: Exception) {}
    }

    fun playSplash(muted: Boolean) {
        if (muted) return
        try {
            ensureGen()?.startTone(ToneGenerator.TONE_PROP_BEEP2, 110)
        } catch (_: Exception) {}
    }

    fun playVictory(muted: Boolean) {
        if (muted) return
        try {
            ensureGen()?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 160)
        } catch (_: Exception) {}
    }

    fun release() {
        try {
            toneGen?.release()
            toneGen = null
        } catch (_: Exception) {}
    }
}
