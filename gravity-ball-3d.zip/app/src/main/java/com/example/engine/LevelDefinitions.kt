package com.example.engine

import androidx.compose.ui.graphics.Color
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class Vec3(
    var x: Float = 0f,
    var y: Float = 0f,
    var z: Float = 0f
) {
    fun set(nx: Float, ny: Float, nz: Float): Vec3 {
        x = nx; y = ny; z = nz
        return this
    }

    fun copyFrom(o: Vec3): Vec3 {
        x = o.x; y = o.y; z = o.z
        return this
    }

    fun clone(): Vec3 = Vec3(x, y, z)

    fun lengthSq(): Float = x * x + y * y + z * z

    fun length(): Float = sqrt(lengthSq())

    fun normalize(): Vec3 {
        val len = length()
        if (len > 1e-5f) {
            x /= len; y /= len; z /= len
        }
        return this
    }

    fun dot(o: Vec3): Float = x * o.x + y * o.y + z * o.z

    fun addScaled(o: Vec3, s: Float): Vec3 {
        x += o.x * s
        y += o.y * s
        z += o.z * s
        return this
    }

    fun distSqTo(px: Float, py: Float, pz: Float): Float {
        val dx = x - px
        val dy = y - py
        val dz = z - pz
        return dx * dx + dy * dy + dz * dz
    }

    companion object {
        fun cross(a: Vec3, b: Vec3, out: Vec3 = Vec3()): Vec3 {
            val cx = a.y * b.z - a.z * b.y
            val cy = a.z * b.x - a.x * b.z
            val cz = a.x * b.y - a.y * b.x
            return out.set(cx, cy, cz)
        }
    }
}

data class Quat(
    var x: Float = 0f,
    var y: Float = 0f,
    var z: Float = 0f,
    var w: Float = 1f
) {
    fun identity(): Quat {
        x = 0f; y = 0f; z = 0f; w = 1f
        return this
    }

    fun copyFrom(o: Quat): Quat {
        x = o.x; y = o.y; z = o.z; w = o.w
        return this
    }

    fun clone(): Quat = Quat(x, y, z, w)

    fun setFromAxisAngle(ax: Float, ay: Float, az: Float, angleRad: Float): Quat {
        val half = angleRad * 0.5f
        val s = sin(half)
        x = ax * s
        y = ay * s
        z = az * s
        w = cos(half)
        return normalize()
    }

    fun setFromEulerYXZ(pitch: Float, yaw: Float, roll: Float = 0f): Quat {
        val c1 = cos(yaw * 0.5f)
        val s1 = sin(yaw * 0.5f)
        val c2 = cos(pitch * 0.5f)
        val s2 = sin(pitch * 0.5f)
        val c3 = cos(roll * 0.5f)
        val s3 = sin(roll * 0.5f)

        x = c1 * s2 * c3 + s1 * c2 * s3
        y = s1 * c2 * c3 - c1 * s2 * s3
        z = c1 * c2 * s3 - s1 * s2 * c3
        w = c1 * c2 * c3 + s1 * s2 * s3
        return normalize()
    }

    fun normalize(): Quat {
        val len = sqrt(x * x + y * y + z * z + w * w)
        if (len > 1e-6f) {
            x /= len; y /= len; z /= len; w /= len
        } else {
            identity()
        }
        return this
    }

    fun invertTo(out: Quat): Quat {
        out.x = -x; out.y = -y; out.z = -z; out.w = w
        return out
    }

    fun premultiply(q: Quat): Quat {
        val nx = q.w * x + q.x * w + q.y * z - q.z * y
        val ny = q.w * y - q.x * z + q.y * w + q.z * x
        val nz = q.w * z + q.x * y - q.y * x + q.z * w
        val nw = q.w * w - q.x * x - q.y * y - q.z * z
        x = nx; y = ny; z = nz; w = nw
        return normalize()
    }

    fun transform(v: Vec3, out: Vec3 = Vec3()): Vec3 {
        val vx = v.x; val vy = v.y; val vz = v.z
        val ix = w * vx + y * vz - z * vy
        val iy = w * vy + z * vx - x * vz
        val iz = w * vz + x * vy - y * vx
        val iw = -x * vx - y * vy - z * vz

        out.x = ix * w + iw * -x + iy * -z - iz * -y
        out.y = iy * w + iw * -y + iz * -x - ix * -z
        out.z = iz * w + iw * -z + ix * -y - iy * -x
        return out
    }
}

data class BallSkinSpec(
    val id: Int,
    val name: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val coreGlowColor: Color,
    val rimColor: Color,
    val speedMult: Float,
    val jumpMult: Float,
    val gravityMult: Float,
    val gripMult: Float
)

enum class PlatformStyle {
    STONE_PATH,
    WOOD_BRIDGE,
    FLOATING_ROCK,
    METALLIC_TECH,
    CURVED_RAMP
}

enum class RotatingKind {
    ROTATING_BRIDGE,
    ROTATING_FAN,
    ROTATING_CUTTER,
    SPIN_BEAM
}

enum class ObstacleKind {
    FERRY,
    PISTON,
    TIMED_GATE,
    SAW_CUTTER,
    SWINGING_ARM
}

data class PlatformSpec(
    val x: Float,
    val y: Float,
    val z: Float,
    val w: Float,
    val h: Float,
    val d: Float,
    val pitch: Float = 0f,
    val yaw: Float = 0f,
    val color: Color = Color(0xFF8B95A5),
    val trim: Color = Color(0xFFCBD5E1),
    val hasRails: Boolean = false,
    val style: PlatformStyle = PlatformStyle.STONE_PATH,
    val hasPillar: Boolean = false
)

data class RotatingSpec(
    val x: Float,
    val y: Float,
    val z: Float,
    val w: Float,
    val h: Float,
    val d: Float,
    val speed: Float,
    val isHazard: Boolean = false,
    val color: Color = Color(0xFF475569),
    val trim: Color = Color(0xFF94A3B8),
    val kind: RotatingKind = RotatingKind.ROTATING_BRIDGE
)

data class MovingSpec(
    val x: Float,
    val y: Float,
    val z: Float,
    val w: Float,
    val h: Float,
    val d: Float,
    val axis: Char = 'x',
    val amplitude: Float = 2.4f,
    val speed: Float = 1.5f,
    val phase: Float = 0f,
    val isHazard: Boolean = false,
    val kind: ObstacleKind = ObstacleKind.FERRY,
    val color: Color = Color(0xFF8B5A2B),
    val trim: Color = Color(0xFFD97706)
)

data class CheckpointSpec(
    val id: Int,
    val x: Float,
    val y: Float,
    val z: Float,
    val spawnX: Float,
    val spawnY: Float,
    val spawnZ: Float
)

data class DistantIslandSpec(
    val x: Float,
    val y: Float,
    val z: Float,
    val radius: Float,
    val height: Float
)

data class CourseLevelSpec(
    val id: Int,
    val name: String,
    val subtitle: String,
    val parTimeSec: Int,
    val skyTop: Color,
    val skyHorizon: Color,
    val fogColor: Color,
    val accentColor: Color,
    val waterDeepColor: Color = Color(0xFF0369A1),
    val waterShallowColor: Color = Color(0xFF0EA5E9),
    val waterY: Float = -11.5f,
    val spawn: Vec3,
    val voidY: Float = -14.5f,
    val finish: Vec3,
    val platforms: List<PlatformSpec>,
    val rotatingPlatforms: List<RotatingSpec>,
    val movingObstacles: List<MovingSpec>,
    val checkpoints: List<CheckpointSpec>
)

object LevelDefinitions {

    // 6 Distinct Balls with Unique Visuals & Physics Powers
    val BALL_SKINS: List<BallSkinSpec> = listOf(
        BallSkinSpec(
            id = 0,
            name = "Nova",
            primaryColor = Color(0xFF00F0FF),
            secondaryColor = Color(0xFF0284C7),
            coreGlowColor = Color(0xFFBAE6FD),
            rimColor = Color(0xFF38BDF8),
            speedMult = 1.05f,
            jumpMult = 1.0f,
            gravityMult = 1.0f,
            gripMult = 1.08f
        ),
        BallSkinSpec(
            id = 1,
            name = "Blaze",
            primaryColor = Color(0xFFFF5500),
            secondaryColor = Color(0xFFB91C1C),
            coreGlowColor = Color(0xFFFDE047),
            rimColor = Color(0xFFFB923C),
            speedMult = 1.34f,
            jumpMult = 1.02f,
            gravityMult = 1.0f,
            gripMult = 1.05f
        ),
        BallSkinSpec(
            id = 2,
            name = "Volt",
            primaryColor = Color(0xFFFACC15),
            secondaryColor = Color(0xFFCA8A04),
            coreGlowColor = Color(0xFFFEF08A),
            rimColor = Color(0xFF00F0FF),
            speedMult = 1.14f,
            jumpMult = 1.28f,
            gravityMult = 0.90f,
            gripMult = 1.1f
        ),
        BallSkinSpec(
            id = 3,
            name = "Phantom",
            primaryColor = Color(0xFFC084FC),
            secondaryColor = Color(0xFF6B21A8),
            coreGlowColor = Color(0xFFF472B6),
            rimColor = Color(0xFFE879F9),
            speedMult = 1.16f,
            jumpMult = 1.18f,
            gravityMult = 0.76f,
            gripMult = 1.15f
        ),
        BallSkinSpec(
            id = 4,
            name = "Emerald",
            primaryColor = Color(0xFF10B981),
            secondaryColor = Color(0xFF047857),
            coreGlowColor = Color(0xFF6EE7B7),
            rimColor = Color(0xFF34D399),
            speedMult = 1.18f,
            jumpMult = 1.08f,
            gravityMult = 1.0f,
            gripMult = 1.48f
        ),
        BallSkinSpec(
            id = 5,
            name = "Solar",
            primaryColor = Color(0xFFF43F5E),
            secondaryColor = Color(0xFF881337),
            coreGlowColor = Color(0xFFFBBF24),
            rimColor = Color(0xFFFFDA6A),
            speedMult = 1.38f,
            jumpMult = 1.22f,
            gravityMult = 0.86f,
            gripMult = 1.3f
        )
    )

    // Distant 3D islands scattered across the ocean horizon
    val OCEAN_ISLANDS: List<DistantIslandSpec> = listOf(
        DistantIslandSpec(-36f, -11.5f, -35f, 11f, 7.5f),
        DistantIslandSpec(42f, -11.5f, -55f, 14f, 9.2f),
        DistantIslandSpec(-44f, -11.5f, -95f, 15f, 10.5f),
        DistantIslandSpec(38f, -11.5f, -130f, 12f, 8.0f),
        DistantIslandSpec(-34f, -11.5f, -168f, 13f, 9.5f),
        DistantIslandSpec(45f, -11.5f, -205f, 16f, 11.0f)
    )

    // Stone Path with bevelled rock blocks, cracks, and stone support pillars
    private fun stoneDeck(
        x: Float, y: Float, z: Float, w: Float, d: Float,
        rails: Boolean = false, pillar: Boolean = true
    ) = PlatformSpec(
        x = x, y = y, z = z, w = w, h = 1.25f, d = d,
        pitch = 0f, yaw = 0f,
        color = Color(0xFF788696),
        trim = Color(0xFFA8B5C4),
        hasRails = rails,
        style = PlatformStyle.STONE_PATH,
        hasPillar = pillar
    )

    // Suspended Wooden Plank Bridge with individual timber planks & rope side supports
    private fun woodBridge(
        x: Float, y: Float, z: Float, w: Float, d: Float,
        yaw: Float = 0f, rails: Boolean = false
    ) = PlatformSpec(
        x = x, y = y, z = z, w = w, h = 0.85f, d = d,
        pitch = 0f, yaw = yaw,
        color = Color(0xFF8C5828),
        trim = Color(0xFFC88A4B),
        hasRails = rails,
        style = PlatformStyle.WOOD_BRIDGE,
        hasPillar = false
    )

    // Floating Craggy Rock Island Platform
    private fun floatingRock(
        x: Float, y: Float, z: Float, w: Float, d: Float,
        yaw: Float = 0f
    ) = PlatformSpec(
        x = x, y = y, z = z, w = w, h = 1.4f, d = d,
        pitch = 0f, yaw = yaw,
        color = Color(0xFF64748B),
        trim = Color(0xFF94A3B8),
        hasRails = false,
        style = PlatformStyle.FLOATING_ROCK,
        hasPillar = false
    )

    // Industrial Metallic Platform for mechanical hazard zones
    private fun metalDeck(
        x: Float, y: Float, z: Float, w: Float, d: Float,
        rails: Boolean = false
    ) = PlatformSpec(
        x = x, y = y, z = z, w = w, h = 1.1f, d = d,
        pitch = 0f, yaw = 0f,
        color = Color(0xFF334155),
        trim = Color(0xFFF59E0B),
        hasRails = rails,
        style = PlatformStyle.METALLIC_TECH,
        hasPillar = true
    )

    // Stone / Timber Sloped Ramp
    private fun slopeRamp(
        x: Float, y: Float, z: Float, w: Float, d: Float,
        pitch: Float, yaw: Float = 0f
    ) = PlatformSpec(
        x = x, y = y, z = z, w = w, h = 1.0f, d = d,
        pitch = pitch, yaw = yaw,
        color = Color(0xFF7C6E5F),
        trim = Color(0xFFD6C5B3),
        hasRails = false,
        style = PlatformStyle.CURVED_RAMP,
        hasPillar = false
    )

    // Walkable Rotating Wooden/Metal Bridge
    private fun rotBridge(
        x: Float, y: Float, z: Float, w: Float, d: Float,
        speed: Float
    ) = RotatingSpec(
        x = x, y = y, z = z, w = w, h = 0.85f, d = d,
        speed = speed, isHazard = false,
        color = Color(0xFF7C4D25),
        trim = Color(0xFFD97706),
        kind = RotatingKind.ROTATING_BRIDGE
    )

    // 3D Rotating Fan Hazard with central hub and 4 synchronized rotating blades
    private fun rotatingFan(
        x: Float, y: Float, z: Float, span: Float, speed: Float
    ) = RotatingSpec(
        x = x, y = y, z = z, w = span, h = 0.85f, d = 0.85f,
        speed = speed, isHazard = true,
        color = Color(0xFF475569),
        trim = Color(0xFFEF4444),
        kind = RotatingKind.ROTATING_FAN
    )

    // Stationary Rotating Circular Saw Cutter
    private fun rotatingCutter(
        x: Float, y: Float, z: Float, diameter: Float = 3.2f, speed: Float = 4.0f
    ) = RotatingSpec(
        x = x, y = y, z = z, w = 0.45f, h = diameter, d = diameter,
        speed = speed, isHazard = true,
        color = Color(0xFFCBD5E1),
        trim = Color(0xFFEF4444),
        kind = RotatingKind.ROTATING_CUTTER
    )

    // Moving Circular Saw Cutter that slices across a bridge
    private fun movingSawCutter(
        x: Float, y: Float, z: Float, diameter: Float = 2.8f,
        amp: Float = 2.2f, speed: Float = 1.9f, phase: Float = 0f
    ) = MovingSpec(
        x = x, y = y, z = z,
        w = 0.45f, h = diameter, d = diameter,
        axis = 'x', amplitude = amp, speed = speed, phase = phase,
        isHazard = true, kind = ObstacleKind.SAW_CUTTER,
        color = Color(0xFFE2E8F0), trim = Color(0xFFEF4444)
    )

    // Moving Wooden/Stone Ferry Platform
    private fun ferry(
        x: Float, y: Float, z: Float, w: Float, d: Float,
        axis: Char, amp: Float, speed: Float, phase: Float = 0f
    ) = MovingSpec(
        x = x, y = y, z = z, w = w, h = 1.0f, d = d,
        axis = axis, amplitude = amp, speed = speed, phase = phase,
        isHazard = false, kind = ObstacleKind.FERRY,
        color = Color(0xFF8C5828), trim = Color(0xFFD97706)
    )

    // Swinging / Sliding Heavy Arm Obstacle
    private fun swingingArm(
        x: Float, y: Float, z: Float, w: Float = 2.2f, h: Float = 1.4f, d: Float = 1.2f,
        amp: Float = 1.8f, speed: Float = 2.0f, phase: Float = 0f
    ) = MovingSpec(
        x = x, y = y, z = z, w = w, h = h, d = d,
        axis = 'x', amplitude = amp, speed = speed, phase = phase,
        isHazard = true, kind = ObstacleKind.SWINGING_ARM,
        color = Color(0xFFDC2626), trim = Color(0xFFFACC15)
    )

    // Vertical Moving Barrier Gate
    private fun timedGate(
        x: Float, y: Float, z: Float, width: Float = 5.0f, height: Float = 2.2f,
        speed: Float = 1.9f, phase: Float = 0f, axis: Char = 'y'
    ) = MovingSpec(
        x = x, y = y, z = z, w = width, h = height, d = 0.75f,
        axis = axis,
        amplitude = if (axis == 'y') 2.1f else 2.4f,
        speed = speed, phase = phase, isHazard = true,
        kind = ObstacleKind.TIMED_GATE,
        color = Color(0xFF475569), trim = Color(0xFFF59E0B)
    )

    private fun cp(id: Int, x: Float, y: Float, z: Float) =
        CheckpointSpec(id, x, y + 0.6f, z, x, y + 1.8f, z)

    val ALL_LEVELS: List<CourseLevelSpec> = listOf(
        // LEVEL 1: Stone Promenade, Wooden Suspension Bridge & First Rotating Fan
        CourseLevelSpec(
            id = 1,
            name = "Ocean Promenade",
            subtitle = "Stone walkways, wooden bridges, and gentle ocean breeze",
            parTimeSec = 40,
            skyTop = Color(0xFF0284C7),
            skyHorizon = Color(0xFF7DD3FC),
            fogColor = Color(0xFFBAE6FD),
            accentColor = Color(0xFF0EA5E9),
            waterDeepColor = Color(0xFF0369A1),
            waterShallowColor = Color(0xFF0EA5E9),
            spawn = Vec3(0f, 1.8f, 0f),
            finish = Vec3(0f, 0f, -96f),
            platforms = listOf(
                stoneDeck(0f, 0f, -8f, 8.0f, 20f, rails = true),
                woodBridge(3.0f, 0f, -24f, 6.2f, 16f, yaw = -0.28f),
                stoneDeck(5.5f, 0f, -39f, 8.0f, 18f, rails = false),
                woodBridge(2.8f, 0f, -55f, 6.2f, 16f, yaw = 0.28f),
                metalDeck(0f, 0f, -72f, 7.5f, 20f),
                stoneDeck(0f, 0f, -92f, 9.0f, 20f, rails = true)
            ),
            rotatingPlatforms = listOf(
                rotatingFan(0f, 1.15f, -72f, 5.6f, 1.45f)
            ),
            movingObstacles = emptyList(),
            checkpoints = listOf(cp(1, 5.5f, 0f, -39f))
        ),

        // LEVEL 2: Wooden Bridges, Floating Rocks & First Circular Saw Cutter
        CourseLevelSpec(
            id = 2,
            name = "Timber Strait",
            subtitle = "Suspended plank walkways and industrial saw cutters",
            parTimeSec = 48,
            skyTop = Color(0xFF0369A1),
            skyHorizon = Color(0xFF38BDF8),
            fogColor = Color(0xFF93C5FD),
            accentColor = Color(0xFFF59E0B),
            spawn = Vec3(0f, 1.8f, 0f),
            finish = Vec3(0f, 0f, -114f),
            platforms = listOf(
                stoneDeck(0f, 0f, -6f, 7.0f, 15f, rails = true),
                woodBridge(0f, 0f, -21f, 3.6f, 15f),
                floatingRock(0f, 0f, -37f, 5.8f, 12f),
                woodBridge(-2.0f, 0f, -50f, 3.4f, 14f),
                metalDeck(-2.0f, 0f, -64f, 7.0f, 14f),
                woodBridge(-2.0f, 0f, -81f, 3.4f, 14f),
                floatingRock(0f, 0f, -96f, 4.0f, 12f, yaw = -0.18f),
                stoneDeck(0f, 0f, -111f, 8.5f, 16f, rails = true)
            ),
            rotatingPlatforms = listOf(
                rotatingFan(0f, 1.15f, -37f, 4.8f, 1.65f)
            ),
            movingObstacles = listOf(
                movingSawCutter(-2.0f, 1.3f, -64f, diameter = 2.6f, amp = 2.4f, speed = 1.6f)
            ),
            checkpoints = listOf(cp(1, -2.0f, 0f, -64f))
        ),

        // LEVEL 3: Stone Switchbacks, Sloped Ramps, Rotating Fan & Cutter
        CourseLevelSpec(
            id = 3,
            name = "Cliffside Switchbacks",
            subtitle = "Ascending stone ramps, timber turns, and spinning hazards",
            parTimeSec = 55,
            skyTop = Color(0xFF1D4ED8),
            skyHorizon = Color(0xFF60A5FA),
            fogColor = Color(0xFFBFDBFE),
            accentColor = Color(0xFF10B981),
            spawn = Vec3(0f, 1.8f, 0f),
            finish = Vec3(0f, 1.2f, -130f),
            platforms = listOf(
                stoneDeck(0f, 0f, -6f, 7.0f, 14f, rails = true),
                slopeRamp(0f, 1.4f, -20f, 5.0f, 14f, 0.20f, 0f),
                metalDeck(0f, 2.8f, -32f, 6.5f, 10f),
                woodBridge(-5.5f, 2.8f, -42f, 4.2f, 16f, yaw = 0.52f),
                stoneDeck(-10.0f, 2.8f, -55f, 7.0f, 12f),
                slopeRamp(-4.0f, 1.4f, -69f, 4.5f, 18f, -0.16f, -0.52f),
                metalDeck(2.5f, 0f, -83f, 6.5f, 12f),
                floatingRock(2.5f, 0f, -96f, 6.5f, 12f),
                slopeRamp(1.2f, 0.6f, -110f, 4.6f, 15f, 0.10f, 0.14f),
                stoneDeck(0f, 1.2f, -126f, 8.5f, 16f, rails = true)
            ),
            rotatingPlatforms = listOf(
                rotatingFan(0f, 3.95f, -32f, 5.2f, 1.75f),
                rotatingCutter(2.5f, 1.3f, -83f, diameter = 2.8f, speed = 3.8f)
            ),
            movingObstacles = listOf(
                movingSawCutter(2.5f, 1.3f, -96f, diameter = 2.6f, amp = 2.2f, speed = 1.8f)
            ),
            checkpoints = listOf(cp(1, -10.0f, 2.8f, -55f), cp(2, 2.5f, 0f, -96f))
        ),

        // LEVEL 4: Rotating Bridges, Ocean Ferries & Dual Fans
        CourseLevelSpec(
            id = 4,
            name = "Windmill Atoll",
            subtitle = "Rotating timber bridges, ocean ferries, and turbine fans",
            parTimeSec = 65,
            skyTop = Color(0xFF0369A1),
            skyHorizon = Color(0xFF38BDF8),
            fogColor = Color(0xFF7DD3FC),
            accentColor = Color(0xFF00F0FF),
            spawn = Vec3(0f, 1.8f, 0f),
            finish = Vec3(0f, 0f, -142f),
            platforms = listOf(
                stoneDeck(0f, 0f, -6f, 7.0f, 14f, rails = true),
                metalDeck(0f, 0f, -35f, 6.5f, 10f),
                stoneDeck(0f, 0f, -60f, 7.5f, 12f),
                metalDeck(0f, 0f, -88f, 6.5f, 10f),
                stoneDeck(0f, 0f, -121f, 7.0f, 12f),
                stoneDeck(0f, 0f, -138f, 8.5f, 16f, rails = true)
            ),
            rotatingPlatforms = listOf(
                rotBridge(0f, 0f, -21f, 3.4f, 14f, 0.72f),
                rotatingFan(0f, 1.15f, -35f, 5.2f, 1.8f),
                rotBridge(0f, 0f, -74f, 3.4f, 14f, -0.85f),
                rotatingFan(0f, 1.15f, -88f, 5.2f, -1.9f)
            ),
            movingObstacles = listOf(
                ferry(0f, 0f, -47f, 4.8f, 11f, 'x', 2.6f, 1.15f, 0f),
                ferry(0f, 0f, -104f, 5.0f, 8.5f, 'z', 5.8f, 1.1f, 0.4f)
            ),
            checkpoints = listOf(cp(1, 0f, 0f, -60f), cp(2, 0f, 0f, -121f))
        ),

        // LEVEL 5: Sawtooth Foundry (Cutters, Gates & Fans)
        CourseLevelSpec(
            id = 5,
            name = "Sawtooth Foundry",
            subtitle = "Industrial circular cutters, moving gates, and steel walkways",
            parTimeSec = 70,
            skyTop = Color(0xFF1E3A8A),
            skyHorizon = Color(0xFFF59E0B),
            fogColor = Color(0xFFFDE68A),
            accentColor = Color(0xFFF59E0B),
            spawn = Vec3(0f, 1.8f, 0f),
            finish = Vec3(0f, 0f, -148f),
            platforms = listOf(
                stoneDeck(0f, 0f, -6f, 7.0f, 14f, rails = true),
                metalDeck(0f, 0f, -28f, 5.6f, 30f),
                stoneDeck(0f, 0f, -50f, 7.0f, 12f),
                woodBridge(0f, 0f, -68f, 4.4f, 22f),
                stoneDeck(0f, 0f, -86f, 7.0f, 12f),
                metalDeck(0f, 0f, -112f, 5.8f, 36f),
                stoneDeck(0f, 0f, -144f, 8.5f, 18f, rails = true)
            ),
            rotatingPlatforms = listOf(
                rotatingFan(0f, 1.15f, -28f, 4.8f, 1.85f),
                rotatingFan(0f, 1.15f, -112f, 5.0f, -2.0f)
            ),
            movingObstacles = listOf(
                timedGate(0f, 1.8f, -18f, 5.2f, 2.2f, 1.9f, 0.0f, 'y'),
                movingSawCutter(0f, 1.3f, -36f, 2.8f, 2.1f, 2.0f, 0.5f),
                swingingArm(0f, 1.2f, -68f, 1.8f, 1.3f, 1.8f, 1.6f, 1.8f, 0.5f),
                movingSawCutter(0f, 1.3f, -102f, 2.8f, 2.2f, 2.1f, 0.0f),
                timedGate(0f, 1.4f, -122f, 2.6f, 2.2f, 2.0f, 1.6f, 'x')
            ),
            checkpoints = listOf(cp(1, 0f, 0f, -50f), cp(2, 0f, 0f, -86f))
        ),

        // LEVEL 6: Archipelago Ferries & Cutters
        CourseLevelSpec(
            id = 6,
            name = "Archipelago Ferries",
            subtitle = "Floating rock islands, wooden ferries, and spinning fans",
            parTimeSec = 78,
            skyTop = Color(0xFF0F766E),
            skyHorizon = Color(0xFF2DD4BF),
            fogColor = Color(0xFF99F6E4),
            accentColor = Color(0xFF10B981),
            spawn = Vec3(0f, 1.8f, 0f),
            finish = Vec3(0f, 0f, -162f),
            platforms = listOf(
                stoneDeck(0f, 0f, -6f, 7.0f, 14f, rails = true),
                floatingRock(0f, 0f, -45f, 6.2f, 12f),
                stoneDeck(0f, 0f, -73f, 7.0f, 12f),
                metalDeck(0f, 0f, -96f, 5.0f, 8f),
                stoneDeck(0f, 0f, -120f, 7.0f, 12f),
                stoneDeck(0f, 0f, -158f, 8.5f, 16f, rails = true)
            ),
            rotatingPlatforms = listOf(
                rotatingFan(0f, 1.15f, -45f, 5.2f, 1.9f),
                rotatingFan(0f, 1.15f, -96f, 4.4f, -2.1f)
            ),
            movingObstacles = listOf(
                ferry(0f, 0f, -26f, 3.6f, 9.0f, 'z', 7.5f, 1.15f, 0.0f),
                ferry(0f, 0f, -59f, 3.4f, 13.0f, 'x', 2.8f, 1.25f, 1.0f),
                ferry(0f, 0f, -86f, 3.4f, 7.5f, 'z', 4.5f, 1.3f, 0.0f),
                ferry(0f, 0f, -106f, 3.4f, 7.5f, 'z', 4.5f, 1.3f, 3.14f),
                ferry(0f, 0f, -139f, 3.2f, 10.0f, 'z', 8.0f, 1.25f, 0.8f)
            ),
            checkpoints = listOf(cp(1, 0f, 0f, -73f), cp(2, 0f, 0f, -120f))
        ),

        // LEVEL 7: Cyclone Spires (High-Speed Fans & Cutters)
        CourseLevelSpec(
            id = 7,
            name = "Cyclone Spires",
            subtitle = "High-altitude stone spires, turbine fans, and saw blades",
            parTimeSec = 85,
            skyTop = Color(0xFF0284C7),
            skyHorizon = Color(0xFF38BDF8),
            fogColor = Color(0xFFBAE6FD),
            accentColor = Color(0xFF00F0FF),
            spawn = Vec3(0f, 1.8f, 0f),
            finish = Vec3(0f, 0f, -172f),
            platforms = listOf(
                stoneDeck(0f, 0f, -6f, 7.0f, 14f, rails = true),
                floatingRock(0f, 0f, -35f, 6.5f, 10f),
                woodBridge(5.0f, 0f, -45f, 3.4f, 14f, yaw = -0.58f),
                stoneDeck(9.0f, 0f, -58f, 7.5f, 14f),
                metalDeck(9.0f, 0f, -76f, 8.0f, 20f),
                woodBridge(4.5f, 0f, -93f, 3.2f, 15f, yaw = 0.55f),
                stoneDeck(0f, 0f, -106f, 7.0f, 12f),
                floatingRock(0f, 0f, -128f, 4.8f, 6f),
                stoneDeck(0f, 0f, -150f, 6.5f, 10f),
                stoneDeck(0f, 0f, -168f, 8.5f, 16f, rails = true)
            ),
            rotatingPlatforms = listOf(
                rotBridge(0f, 0f, -21f, 3.2f, 14f, 1.25f),
                rotatingFan(9.0f, 1.15f, -76f, 6.6f, 2.15f),
                rotBridge(0f, 0f, -119f, 3.0f, 12f, 1.35f),
                rotBridge(0f, 0f, -137f, 3.0f, 12f, -1.45f)
            ),
            movingObstacles = listOf(
                movingSawCutter(0f, 1.3f, -35f, 2.7f, 2.2f, 2.0f)
            ),
            checkpoints = listOf(
                cp(1, 9.0f, 0f, -58f),
                cp(2, 0f, 0f, -106f),
                cp(3, 0f, 0f, -150f)
            )
        ),

        // LEVEL 8: Cutter Gauntlet
        CourseLevelSpec(
            id = 8,
            name = "Cutter Gauntlet",
            subtitle = "Twin saw cutters, rotating fans, and narrow timber bridges",
            parTimeSec = 95,
            skyTop = Color(0xFF1E40AF),
            skyHorizon = Color(0xFFFB7185),
            fogColor = Color(0xFFFECDD3),
            accentColor = Color(0xFFF43F5E),
            spawn = Vec3(0f, 1.8f, 0f),
            finish = Vec3(0f, 2.0f, -184f),
            platforms = listOf(
                stoneDeck(0f, 0f, -6f, 6.5f, 12f, rails = true),
                woodBridge(0f, 0f, -24f, 3.8f, 22f),
                stoneDeck(0f, 0f, -56f, 5.5f, 9f),
                slopeRamp(0f, 1.0f, -68f, 4.0f, 14f, 0.15f, 0f),
                metalDeck(0f, 2.0f, -85f, 6.5f, 18f),
                stoneDeck(0f, 2.0f, -100f, 5.5f, 9f),
                woodBridge(0f, 2.0f, -133f, 3.6f, 20f),
                stoneDeck(0f, 2.0f, -148f, 5.5f, 9f),
                stoneDeck(0f, 2.0f, -180f, 8.0f, 15f, rails = true)
            ),
            rotatingPlatforms = listOf(
                rotBridge(0f, 0f, -43f, 3.0f, 14f, 1.25f),
                rotatingFan(0f, 3.15f, -85f, 5.8f, -2.25f),
                rotBridge(0f, 2.0f, -161f, 3.0f, 14f, -1.35f)
            ),
            movingObstacles = listOf(
                movingSawCutter(0f, 1.3f, -19f, 2.8f, 1.5f, 2.2f, 0.0f),
                movingSawCutter(0f, 1.3f, -29f, 2.8f, 1.5f, 2.2f, 3.14f),
                ferry(0f, 2.0f, -113f, 3.8f, 12f, 'x', 2.8f, 1.4f, 0.3f),
                timedGate(0f, 3.8f, -133f, 3.4f, 2.2f, 2.2f, 0.0f, 'y')
            ),
            checkpoints = listOf(
                cp(1, 0f, 0f, -56f),
                cp(2, 0f, 2.0f, -100f),
                cp(3, 0f, 2.0f, -148f)
            )
        ),

        // LEVEL 9: Sky Citadel
        CourseLevelSpec(
            id = 9,
            name = "Sky Citadel",
            subtitle = "Ancient stone bastions, saw gates, and turbine fans",
            parTimeSec = 105,
            skyTop = Color(0xFF0369A1),
            skyHorizon = Color(0xFF38BDF8),
            fogColor = Color(0xFFBAE6FD),
            accentColor = Color(0xFF38BDF8),
            spawn = Vec3(0f, 1.8f, 0f),
            finish = Vec3(0f, 4.2f, -194f),
            platforms = listOf(
                stoneDeck(0f, 0f, -6f, 7.0f, 14f, rails = true),
                slopeRamp(0f, 1.0f, -19f, 4.5f, 12f, 0.18f, 0f),
                metalDeck(0f, 2.1f, -39f, 6.0f, 20f),
                stoneDeck(0f, 2.1f, -55f, 6.5f, 10f),
                floatingRock(-3.2f, 2.1f, -69f, 4.4f, 10f),
                floatingRock(3.2f, 2.1f, -83f, 4.4f, 10f),
                stoneDeck(0f, 2.1f, -98f, 6.5f, 12f),
                slopeRamp(0f, 3.1f, -112f, 4.5f, 14f, 0.16f, 0f),
                metalDeck(0f, 4.2f, -135f, 5.5f, 24f),
                stoneDeck(0f, 4.2f, -153f, 6.5f, 10f),
                slopeRamp(0f, 4.2f, -178f, 4.5f, 10f, 0.12f, 0f),
                stoneDeck(0f, 4.2f, -191f, 8.5f, 14f, rails = true)
            ),
            rotatingPlatforms = listOf(
                rotatingFan(0f, 3.25f, -39f, 5.2f, 2.1f),
                rotBridge(0f, 4.2f, -166f, 3.0f, 12f, 1.4f)
            ),
            movingObstacles = listOf(
                timedGate(0f, 3.9f, -31f, 5.6f, 2.2f, 2.2f, 0.0f, 'y'),
                movingSawCutter(0f, 3.4f, -45f, 2.8f, 2.2f, 2.2f, 1.8f),
                timedGate(0f, 6.0f, -128f, 5.2f, 2.2f, 2.4f, 0.0f, 'y'),
                movingSawCutter(0f, 5.5f, -135f, 2.8f, 2.0f, 2.5f, 1.5f),
                timedGate(0f, 6.0f, -142f, 5.2f, 2.2f, 2.4f, 2.4f, 'y')
            ),
            checkpoints = listOf(
                cp(1, 0f, 2.1f, -55f),
                cp(2, 0f, 2.1f, -98f),
                cp(3, 0f, 4.2f, -153f)
            )
        ),

        // LEVEL 10: Horizon Apex (Grand Finale Over the Ocean)
        CourseLevelSpec(
            id = 10,
            name = "Horizon Apex",
            subtitle = "Grand ocean finale with stone arches, plank bridges, fans, and cutters",
            parTimeSec = 125,
            skyTop = Color(0xFF0284C7),
            skyHorizon = Color(0xFF38BDF8),
            fogColor = Color(0xFFBAE6FD),
            accentColor = Color(0xFF00F0FF),
            spawn = Vec3(0f, 1.8f, 0f),
            finish = Vec3(0f, 3.2f, -226f),
            platforms = listOf(
                stoneDeck(0f, 0f, -6f, 7.5f, 14f, rails = true),
                slopeRamp(0f, 1.1f, -19f, 4.6f, 12f, 0.18f, 0f),
                metalDeck(0f, 2.2f, -37f, 6.2f, 18f),
                stoneDeck(0f, 2.2f, -52f, 6.5f, 10f),
                woodBridge(4.5f, 2.2f, -80f, 3.4f, 14f, yaw = -0.52f),
                metalDeck(8.5f, 2.2f, -94f, 7.0f, 14f),
                stoneDeck(8.5f, 2.2f, -108f, 6.5f, 10f),
                woodBridge(4.2f, 2.2f, -120f, 3.4f, 14f, yaw = 0.52f),
                stoneDeck(0f, 2.2f, -132f, 6.0f, 10f),
                floatingRock(0f, 2.2f, -155f, 4.8f, 6f),
                stoneDeck(0f, 2.2f, -179f, 6.5f, 10f),
                stoneDeck(0f, 2.2f, -206f, 6.5f, 8f),
                slopeRamp(0f, 2.7f, -214f, 4.5f, 8f, 0.12f, 0f),
                stoneDeck(0f, 3.2f, -224f, 9.0f, 14f, rails = true)
            ),
            rotatingPlatforms = listOf(
                rotatingFan(8.5f, 3.35f, -94f, 6.2f, 2.35f),
                rotBridge(0f, 2.2f, -144f, 3.0f, 13f, 1.45f),
                rotBridge(0f, 2.2f, -166f, 3.0f, 13f, -1.55f)
            ),
            movingObstacles = listOf(
                timedGate(0f, 4.0f, -32f, 5.6f, 2.2f, 2.2f, 0.0f, 'y'),
                movingSawCutter(0f, 3.5f, -41f, 2.9f, 2.2f, 2.5f, 1.2f),
                ferry(0f, 2.2f, -64f, 4.4f, 11f, 'x', 2.6f, 1.35f, 0.0f),
                ferry(0f, 2.2f, -193f, 4.4f, 8.0f, 'z', 5.2f, 1.35f, 0.5f)
            ),
            checkpoints = listOf(
                cp(1, 0f, 2.2f, -52f),
                cp(2, 8.5f, 2.2f, -108f),
                cp(3, 0f, 2.2f, -179f),
                cp(4, 0f, 2.2f, -206f)
            )
        )
    )
}
