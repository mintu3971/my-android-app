package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "level_progress")
data class LevelProgressEntity(
    @PrimaryKey val levelId: Int,
    val title: String,
    val subtitle: String,
    val parTimeSec: Int,
    val totalCheckpoints: Int,
    val isUnlocked: Boolean,
    val isCompleted: Boolean = false,
    val bestTimeMs: Long = 0L,
    val leastFalls: Int = -1,
    val stars: Int = 0
)
