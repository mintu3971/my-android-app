package com.example.data.local

import kotlinx.coroutines.flow.Flow

class GameRepository(private val dao: LevelProgressDao) {
    val allLevels: Flow<List<LevelProgressEntity>> = dao.getAllLevels()

    suspend fun ensureSeeded() {
        val current = dao.getAllLevelsSnapshot().associateBy { it.levelId }
        val defaults = defaultLevels()
        if (current.size < defaults.size) {
            val merged = defaults.map { def ->
                val existing = current[def.levelId]
                val prevCompleted = current[def.levelId - 1]?.isCompleted == true
                existing?.copy(
                    title = def.title,
                    subtitle = def.subtitle,
                    parTimeSec = def.parTimeSec,
                    totalCheckpoints = def.totalCheckpoints,
                    isUnlocked = existing.isUnlocked || def.levelId == 1 || prevCompleted
                ) ?: def.copy(
                    isUnlocked = def.levelId == 1 || prevCompleted
                )
            }
            dao.upsertLevels(merged)
        }
    }

    suspend fun recordLevelCompletion(levelId: Int, timeMs: Long, falls: Int): Int {
        ensureSeeded()
        val defaults = defaultLevels()
        val existing = dao.getLevelById(levelId) ?: defaults.first { it.levelId == levelId }
        val parMs = existing.parTimeSec * 1000L
        val earnedStars = when {
            timeMs <= parMs && falls == 0 -> 3
            timeMs <= (parMs * 1.35).toLong() || falls <= 2 -> 2
            else -> 1
        }
        val bestTime = if (existing.bestTimeMs == 0L || timeMs < existing.bestTimeMs) {
            timeMs
        } else {
            existing.bestTimeMs
        }
        val minFalls = if (existing.leastFalls < 0 || falls < existing.leastFalls) {
            falls
        } else {
            existing.leastFalls
        }
        val bestStars = maxOf(existing.stars, earnedStars)

        dao.upsertLevel(
            existing.copy(
                isUnlocked = true,
                isCompleted = true,
                bestTimeMs = bestTime,
                leastFalls = minFalls,
                stars = bestStars
            )
        )

        // Unlock next level sequentially (up to Level 10)
        if (levelId < TOTAL_LEVELS) {
            val next = dao.getLevelById(levelId + 1)
                ?: defaults.firstOrNull { it.levelId == levelId + 1 }
            if (next != null && !next.isUnlocked) {
                dao.upsertLevel(next.copy(isUnlocked = true))
            }
        }
        return earnedStars
    }

    suspend fun resetAllProgress() {
        dao.clearAll()
        dao.upsertLevels(defaultLevels())
    }

    companion object {
        const val TOTAL_LEVELS = 10

        fun defaultLevels(): List<LevelProgressEntity> = listOf(
            LevelProgressEntity(
                levelId = 1,
                title = "Tutorial Promenade",
                subtitle = "Wide platforms, gentle turns, and basic rolling control",
                parTimeSec = 40,
                totalCheckpoints = 1,
                isUnlocked = true
            ),
            LevelProgressEntity(
                levelId = 2,
                title = "Canyon Gaps",
                subtitle = "Narrower catwalks and small jumpable gaps",
                parTimeSec = 48,
                totalCheckpoints = 1,
                isUnlocked = false
            ),
            LevelProgressEntity(
                levelId = 3,
                title = "Banked Switchbacks",
                subtitle = "Ascending slopes, speed ramps, and sharper S-curve turns",
                parTimeSec = 55,
                totalCheckpoints = 2,
                isUnlocked = false
            ),
            LevelProgressEntity(
                levelId = 4,
                title = "Rotor Nexus",
                subtitle = "Motorized rotating bridges and oscillating ferry platforms",
                parTimeSec = 65,
                totalCheckpoints = 2,
                isUnlocked = false
            ),
            LevelProgressEntity(
                levelId = 5,
                title = "Chrono Gates",
                subtitle = "Rhythmic timed barrier gates and precision hazard blocks",
                parTimeSec = 70,
                totalCheckpoints = 2,
                isUnlocked = false
            ),
            LevelProgressEntity(
                levelId = 6,
                title = "Abyssal Ferries",
                subtitle = "Narrow moving platforms gliding across deep void chasms",
                parTimeSec = 78,
                totalCheckpoints = 2,
                isUnlocked = false
            ),
            LevelProgressEntity(
                levelId = 7,
                title = "Cyclone Spires",
                subtitle = "High-speed rotors, spinning mills, and sharp dogleg turns",
                parTimeSec = 85,
                totalCheckpoints = 3,
                isUnlocked = false
            ),
            LevelProgressEntity(
                levelId = 8,
                title = "Hazard Crucible",
                subtitle = "Ramps, pistons, rotors, and narrow beams with minimal rest zones",
                parTimeSec = 95,
                totalCheckpoints = 3,
                isUnlocked = false
            ),
            LevelProgressEntity(
                levelId = 9,
                title = "Quantum Vault",
                subtitle = "Synchronized timed gates, ramp leaps, and multi-stage sequences",
                parTimeSec = 105,
                totalCheckpoints = 3,
                isUnlocked = false
            ),
            LevelProgressEntity(
                levelId = 10,
                title = "Singularity Apex",
                subtitle = "Grand finale: Ramps, sharp turns, ferries, rotors, and timed gates",
                parTimeSec = 125,
                totalCheckpoints = 4,
                isUnlocked = false
            )
        )
    }
}
