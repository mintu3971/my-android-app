// 3D Rigid-Body Sphere & Kinematic Obstacle Physics Engine for GRAVITY BALL 3D
// Supports sub-stepped 3D Oriented Bounding Box (OBB) collisions, inclined ramps,
// rotating platforms with tangential friction transfer, moving pistons/ferries,
// true 3D angular velocity rolling quaternion integration, coyote time, and jump buffering.

class GravityPhysicsWorld {
  constructor() {
    this.gravity = -24.0;
    this.substeps = 4;
    this.ball = {
      radius: 0.65,
      mass: 1.0,
      position: new THREE.Vector3(0, 2, 0),
      velocity: new THREE.Vector3(0, 0, 0),
      quaternion: new THREE.Quaternion(),
      angularVelocity: new THREE.Vector3(0, 0, 0),
      grounded: false,
      groundNormal: new THREE.Vector3(0, 1, 0),
      groundBody: null,
      coyoteTimer: 0,
      jumpBufferTimer: 0,
      boostActive: false,
      lastImpactSpeed: 0
    };

    this.colliders = [];
    // Pre-allocated scratch math objects for zero-GC 60fps loop
    this._localPos = new THREE.Vector3();
    this._closestLocal = new THREE.Vector3();
    this._diffLocal = new THREE.Vector3();
    this._worldNormal = new THREE.Vector3();
    this._worldContact = new THREE.Vector3();
    this._relPoint = new THREE.Vector3();
    this._surfaceVel = new THREE.Vector3();
    this._relVel = new THREE.Vector3();
    this._tangentVel = new THREE.Vector3();
    this._invQuat = new THREE.Quaternion();
    this._deltaQuat = new THREE.Quaternion();
    this._rotAxis = new THREE.Vector3();
  }

  clearColliders() {
    this.colliders.length = 0;
  }

  addBoxCollider(config) {
    const collider = {
      id: config.id || ('col_' + this.colliders.length),
      type: 'box',
      mesh: config.mesh || null,
      basePosition: (config.position || new THREE.Vector3()).clone(),
      position: (config.position || new THREE.Vector3()).clone(),
      prevPosition: (config.position || new THREE.Vector3()).clone(),
      halfExtents: (config.halfExtents || new THREE.Vector3(1, 0.5, 1)).clone(),
      quaternion: (config.quaternion || new THREE.Quaternion()).clone(),
      linearVelocity: new THREE.Vector3(),
      angularVelocity: new THREE.Vector3(),
      friction: config.friction !== undefined ? config.friction : 0.85,
      restitution: config.restitution !== undefined ? config.restitution : 0.18,
      isHazardBumper: !!config.isHazardBumper,
      knockbackStrength: config.knockbackStrength || 11.0,
      kinematicUpdate: config.kinematicUpdate || null
    };
    this.colliders.push(collider);
    return collider;
  }

  resetBall(spawnPos) {
    this.ball.position.copy(spawnPos);
    this.ball.velocity.set(0, 0, 0);
    this.ball.angularVelocity.set(0, 0, 0);
    this.ball.quaternion.identity();
    this.ball.grounded = false;
    this.ball.coyoteTimer = 0;
    this.ball.jumpBufferTimer = 0;
    this.ball.lastImpactSpeed = 0;
  }

  requestJump() {
    this.ball.jumpBufferTimer = 0.16;
  }

  step(dt, input, elapsedTime, callbacks) {
    const clampedDt = Math.min(dt, 0.05);
    const subDt = clampedDt / this.substeps;
    const b = this.ball;

    if (b.coyoteTimer > 0) b.coyoteTimer = Math.max(0, b.coyoteTimer - clampedDt);
    if (b.jumpBufferTimer > 0) b.jumpBufferTimer = Math.max(0, b.jumpBufferTimer - clampedDt);

    let maxImpact = 0;
    let hitHazard = false;

    for (let s = 0; s < this.substeps; s++) {
      const stepTime = elapsedTime - clampedDt + (s + 1) * subDt;

      // 1. Update kinematic platforms & obstacles
      for (let i = 0; i < this.colliders.length; i++) {
        const col = this.colliders[i];
        if (col.kinematicUpdate) {
          col.prevPosition.copy(col.position);
          col.kinematicUpdate(col, stepTime, subDt);
          col.linearVelocity.subVectors(col.position, col.prevPosition).divideScalar(subDt);
          if (col.mesh) {
            col.mesh.position.copy(col.position);
            col.mesh.quaternion.copy(col.quaternion);
          }
        }
      }

      // 2. Apply player rolling force & gravity
      const moveAccel = b.grounded ? 26.0 : 15.5;
      const boostMult = input.boost ? 1.42 : 1.0;
      const maxSpeed = input.boost ? 17.5 : 12.8;

      // Input X (left/right), Input Z (forward is -Z, backward is +Z)
      b.velocity.x += input.x * moveAccel * boostMult * subDt;
      b.velocity.z += input.z * moveAccel * boostMult * subDt;

      // Horizontal speed cap (preserving momentum from ramps/launches gradually)
      const horizSpeedSq = b.velocity.x * b.velocity.x + b.velocity.z * b.velocity.z;
      if (horizSpeedSq > maxSpeed * maxSpeed) {
        const horizSpeed = Math.sqrt(horizSpeedSq);
        const blendedSpeed = horizSpeed + (maxSpeed - horizSpeed) * Math.min(1, subDt * 6.0);
        const scale = blendedSpeed / horizSpeed;
        b.velocity.x *= scale;
        b.velocity.z *= scale;
      }

      // Air drag
      const airDamp = Math.exp(-0.35 * subDt);
      b.velocity.x *= airDamp;
      b.velocity.z *= airDamp;

      // Gravity
      b.velocity.y += this.gravity * subDt;

      // Integrate position
      b.position.addScaledVector(b.velocity, subDt);

      // 3. Solve collisions against all OBB colliders
      let frameGrounded = false;
      for (let i = 0; i < this.colliders.length; i++) {
        const col = this.colliders[i];

        // Transform ball center into collider's local coordinate system
        this._invQuat.copy(col.quaternion).invert();
        this._localPos.subVectors(b.position, col.position).applyQuaternion(this._invQuat);

        const hx = col.halfExtents.x;
        const hy = col.halfExtents.y;
        const hz = col.halfExtents.z;

        // Broad-phase check in local space
        const r = b.radius;
        if (
          Math.abs(this._localPos.x) > hx + r ||
          Math.abs(this._localPos.y) > hy + r ||
          Math.abs(this._localPos.z) > hz + r
        ) {
          continue;
        }

        // Closest point on OBB in local space
        this._closestLocal.set(
          Math.max(-hx, Math.min(hx, this._localPos.x)),
          Math.max(-hy, Math.min(hy, this._localPos.y)),
          Math.max(-hz, Math.min(hz, this._localPos.z))
        );

        this._diffLocal.subVectors(this._localPos, this._closestLocal);
        const distSq = this._diffLocal.lengthSq();

        if (distSq <= r * r) {
          let dist = Math.sqrt(distSq);
          let penetration = 0;

          if (dist > 1e-5) {
            this._diffLocal.divideScalar(dist);
            penetration = r - dist;
          } else {
            // Center of sphere is inside the box; push out along minimum penetration axis
            const dx = hx - Math.abs(this._localPos.x);
            const dy = hy - Math.abs(this._localPos.y);
            const dz = hz - Math.abs(this._localPos.z);
            if (dy <= dx && dy <= dz) {
              this._diffLocal.set(0, this._localPos.y >= 0 ? 1 : -1, 0);
              penetration = dy + r;
            } else if (dx <= dz) {
              this._diffLocal.set(this._localPos.x >= 0 ? 1 : -1, 0, 0);
              penetration = dx + r;
            } else {
              this._diffLocal.set(0, 0, this._localPos.z >= 0 ? 1 : -1);
              penetration = dz + r;
            }
          }

          // World contact normal & contact point
          this._worldNormal.copy(this._diffLocal).applyQuaternion(col.quaternion).normalize();
          this._worldContact.copy(this._closestLocal).applyQuaternion(col.quaternion).add(col.position);

          // Push ball out of penetration
          b.position.addScaledVector(this._worldNormal, penetration);

          // Compute surface velocity of collider at contact point: v_surf = v_lin + w x r_rel
          this._relPoint.subVectors(this._worldContact, col.position);
          this._surfaceVel.crossVectors(col.angularVelocity, this._relPoint).add(col.linearVelocity);

          // Relative velocity of ball with respect to surface
          this._relVel.subVectors(b.velocity, this._surfaceVel);
          const normalVel = this._relVel.dot(this._worldNormal);

          if (normalVel < 0) {
            const impactSpeed = -normalVel;
            if (impactSpeed > maxImpact) maxImpact = impactSpeed;

            const bounce = impactSpeed > 3.2 ? col.restitution : 0.0;
            const normalImpulse = -(1.0 + bounce) * normalVel;
            b.velocity.addScaledVector(this._worldNormal, normalImpulse);

            // Recompute relative velocity for tangential friction
            this._relVel.subVectors(b.velocity, this._surfaceVel);
            const newNormalVel = this._relVel.dot(this._worldNormal);
            this._tangentVel.copy(this._relVel).addScaledVector(this._worldNormal, -newNormalVel);

            // Apply surface grip / rolling drag so rotating platforms & ferries carry the ball
            const grip = Math.min(1.0, col.friction * subDt * (Math.abs(input.x) < 0.08 && Math.abs(input.z) < 0.08 ? 9.5 : 3.2));
            b.velocity.addScaledVector(this._tangentVel, -grip);
          }

          // Hazard bumper knockback (spinning blades / pistons hitting sideways)
          if (col.isHazardBumper) {
            const pushDir = this._worldNormal.clone();
            pushDir.y = Math.max(0.25, pushDir.y + 0.25);
            pushDir.normalize();
            b.velocity.addScaledVector(pushDir, col.knockbackStrength);
            hitHazard = true;
          }

          // Grounded check (surface normal points sufficiently upward)
          if (this._worldNormal.y > 0.52) {
            frameGrounded = true;
            b.grounded = true;
            b.coyoteTimer = 0.16;
            b.groundNormal.copy(this._worldNormal);
            b.groundBody = col;

            // Update rolling angular velocity from relative velocity over surface
            this._relVel.subVectors(b.velocity, this._surfaceVel);
            b.angularVelocity.crossVectors(this._worldNormal, this._relVel).divideScalar(b.radius);
          }
        }
      }

      if (!frameGrounded) {
        b.grounded = false;
      }

      // 4. Process Jump (with Coyote Time + Jump Buffer)
      if (b.jumpBufferTimer > 0 && b.coyoteTimer > 0) {
        b.velocity.y = Math.max(b.velocity.y, 10.6);
        b.position.y += 0.05;
        b.grounded = false;
        b.coyoteTimer = 0;
        b.jumpBufferTimer = 0;
        if (callbacks && callbacks.onJump) callbacks.onJump();
      }

      // 5. Integrate ball visual rolling Quaternion from angularVelocity
      const angSpeed = b.angularVelocity.length();
      if (angSpeed > 0.001) {
        this._rotAxis.copy(b.angularVelocity).divideScalar(angSpeed);
        this._deltaQuat.setFromAxisAngle(this._rotAxis, angSpeed * subDt);
        b.quaternion.premultiply(this._deltaQuat).normalize();
      }
    }

    if (hitHazard && callbacks && callbacks.onHazardHit) {
      callbacks.onHazardHit(maxImpact);
    } else if (maxImpact > 4.2 && callbacks && callbacks.onHeavyLand) {
      callbacks.onHeavyLand(Math.min(1.0, (maxImpact - 4.0) / 14.0));
    }
  }
}

window.GravityPhysicsWorld = GravityPhysicsWorld;
