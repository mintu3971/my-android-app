// GRAVITY BALL 3D - Three.js 3D Scene, Composite Procedural Models, Studio PBR Lighting,
// Camera-Relative Joystick Movement, Landscape Resize Handling, and 10-Level Support

(function () {
  const container = document.getElementById('canvas-container');
  const fxOverlay = document.getElementById('fx-overlay');

  // LocalStorage Progress Helper (persists 10 levels across browser & WebView sessions)
  const PROGRESS_STORAGE_KEY = 'gravity_ball_3d_progress_v2';
  function loadLocalProgress() {
    try {
      const raw = localStorage.getItem(PROGRESS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed.unlockedLevel === 'number') {
          return parsed;
        }
      }
    } catch (e) {}
    return { unlockedLevel: 1, completed: {}, bestTimes: {}, stars: {} };
  }

  function saveLocalProgress(data) {
    try {
      localStorage.setItem(PROGRESS_STORAGE_KEY, JSON.stringify(data));
    } catch (e) {}
  }

  let savedProgress = loadLocalProgress();

  // Attempt Screen Orientation API lock to landscape when permitted by browser
  function tryLockLandscapeOrientation() {
    try {
      if (screen.orientation && typeof screen.orientation.lock === 'function') {
        screen.orientation.lock('landscape').catch(() => {});
      }
    } catch (e) {}
  }

  // 1. Renderer with ACESFilmicToneMapping & Shadows
  const renderer = new THREE.WebGLRenderer({
    antialias: true,
    powerPreference: 'high-performance'
  });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.18;
  renderer.outputEncoding = THREE.sRGBEncoding;
  container.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color('#060B1E');
  scene.fog = new THREE.FogExp2('#0D2146', 0.0082);

  const camera = new THREE.PerspectiveCamera(
    56,
    window.innerWidth / Math.max(1, window.innerHeight),
    0.1,
    260
  );

  function updateViewportProjection() {
    const w = Math.max(1, window.innerWidth);
    const h = Math.max(1, window.innerHeight);
    const aspect = w / h;
    camera.aspect = aspect;
    // Optimize FOV for 16:9 landscape while keeping narrower/wider screens comfortable
    camera.fov = aspect >= 1.3 ? 54 : 66;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  }
  updateViewportProjection();

  // 2. Procedural Studio Reflection Environment via PMREMGenerator
  function buildStudioEnvMap() {
    try {
      const pmrem = new THREE.PMREMGenerator(renderer);
      pmrem.compileCubemapShader();
      const envScene = new THREE.Scene();
      envScene.background = new THREE.Color('#0B1528');

      const skyDome = new THREE.Mesh(
        new THREE.SphereGeometry(40, 16, 12),
        new THREE.MeshBasicMaterial({ color: '#1E3A8A', side: THREE.BackSide })
      );
      envScene.add(skyDome);

      const stripGeo = new THREE.PlaneGeometry(18, 6);
      const warmStrip = new THREE.Mesh(stripGeo, new THREE.MeshBasicMaterial({ color: '#FFFBEB', side: THREE.DoubleSide }));
      warmStrip.position.set(12, 18, 10);
      warmStrip.lookAt(0, 0, 0);
      envScene.add(warmStrip);

      const cyanStrip = new THREE.Mesh(stripGeo, new THREE.MeshBasicMaterial({ color: '#00F0FF', side: THREE.DoubleSide }));
      cyanStrip.position.set(-15, 10, -12);
      cyanStrip.lookAt(0, 0, 0);
      envScene.add(cyanStrip);

      const magentaStrip = new THREE.Mesh(stripGeo, new THREE.MeshBasicMaterial({ color: '#A855F7', side: THREE.DoubleSide }));
      magentaStrip.position.set(0, -14, -10);
      magentaStrip.lookAt(0, 0, 0);
      envScene.add(magentaStrip);

      const envRT = pmrem.fromScene(envScene, 0.04);
      pmrem.dispose();
      return envRT.texture;
    } catch (e) {
      return null;
    }
  }
  const envMap = buildStudioEnvMap();
  if (envMap) {
    scene.environment = envMap;
  }

  // 3. Studio PBR Lighting
  const hemiLight = new THREE.HemisphereLight(0x7dd3fc, 0x0f172a, 0.78);
  hemiLight.position.set(0, 50, 0);
  scene.add(hemiLight);

  const dirLight = new THREE.DirectionalLight(0xfff4e0, 1.45);
  dirLight.position.set(18, 34, 22);
  dirLight.castShadow = true;
  dirLight.shadow.mapSize.width = 1024;
  dirLight.shadow.mapSize.height = 1024;
  dirLight.shadow.camera.near = 2;
  dirLight.shadow.camera.far = 110;
  const d = 26;
  dirLight.shadow.camera.left = -d;
  dirLight.shadow.camera.right = d;
  dirLight.shadow.camera.top = d;
  dirLight.shadow.camera.bottom = -d;
  dirLight.shadow.bias = -0.0008;
  scene.add(dirLight);
  scene.add(dirLight.target);

  // 4. Procedural CanvasTextures
  function createDeckGridTexture() {
    const c = document.createElement('canvas');
    c.width = 256;
    c.height = 256;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#808080';
    ctx.fillRect(0, 0, 256, 256);
    ctx.strokeStyle = '#B8B8B8';
    ctx.lineWidth = 3;
    for (let i = 0; i <= 256; i += 32) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, 256);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(256, i);
      ctx.stroke();
    }
    ctx.fillStyle = '#505050';
    for (let x = 16; x < 256; x += 32) {
      for (let y = 16; y < 256; y += 32) {
        ctx.fillRect(x - 4, y - 4, 8, 8);
      }
    }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    return tex;
  }

  function createHazardStripeTexture() {
    const c = document.createElement('canvas');
    c.width = 128;
    c.height = 128;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#EF4444';
    ctx.fillRect(0, 0, 128, 128);
    ctx.fillStyle = '#FACC15';
    for (let i = -128; i < 256; i += 32) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i + 16, 0);
      ctx.lineTo(i + 144, 128);
      ctx.lineTo(i + 128, 128);
      ctx.closePath();
      ctx.fill();
    }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    return tex;
  }

  function createBrushedMetalTexture() {
    const c = document.createElement('canvas');
    c.width = 256;
    c.height = 256;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#909090';
    ctx.fillRect(0, 0, 256, 256);
    for (let y = 0; y < 256; y += 2) {
      const shade = 120 + Math.floor(Math.sin(y * 0.35) * 35);
      ctx.fillStyle = `rgb(${shade},${shade},${shade})`;
      ctx.fillRect(0, y, 256, 2);
    }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    return tex;
  }

  function createContactShadowTexture() {
    const c = document.createElement('canvas');
    c.width = 128;
    c.height = 128;
    const ctx = c.getContext('2d');
    const grad = ctx.createRadialGradient(64, 64, 6, 64, 64, 60);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0.65)');
    grad.addColorStop(0.6, 'rgba(0, 240, 255, 0.22)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0.0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 128, 128);
    return new THREE.CanvasTexture(c);
  }

  const deckBumpTex = createDeckGridTexture();
  const hazardTex = createHazardStripeTexture();
  const metalBumpTex = createBrushedMetalTexture();
  const contactShadowTex = createContactShadowTexture();

  // 5. Composite 9-Part Procedural Hero Model: Shiny 3D Gravity Sphere
  const ballRoot = new THREE.Group();
  const ballVisualGroup = new THREE.Group();
  ballRoot.add(ballVisualGroup);

  const r = 0.65;
  const shellMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    metalness: 0.9,
    roughness: 0.14,
    bumpMap: metalBumpTex,
    bumpScale: 0.015
  });
  const shellMesh = new THREE.Mesh(new THREE.SphereGeometry(r * 0.96, 32, 24), shellMat);
  shellMesh.castShadow = true;
  shellMesh.receiveShadow = true;
  ballVisualGroup.add(shellMesh);

  const coreMat = new THREE.MeshStandardMaterial({
    color: 0x00f0ff,
    emissive: 0x00d8ff,
    emissiveIntensity: 0.85,
    roughness: 0.2,
    metalness: 0.1
  });
  const coreMesh = new THREE.Mesh(new THREE.SphereGeometry(r * 0.72, 20, 16), coreMat);
  ballVisualGroup.add(coreMesh);

  const ringMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    metalness: 0.78,
    roughness: 0.28
  });
  const eqRing = new THREE.Mesh(new THREE.TorusGeometry(r * 0.96, r * 0.065, 12, 36), ringMat);
  eqRing.castShadow = true;
  ballVisualGroup.add(eqRing);

  const merRing = new THREE.Mesh(new THREE.TorusGeometry(r * 0.96, r * 0.065, 12, 36), ringMat);
  merRing.rotation.y = Math.PI / 2;
  merRing.castShadow = true;
  ballVisualGroup.add(merRing);

  const nodeGeo = new THREE.CylinderGeometry(r * 0.22, r * 0.26, r * 0.12, 16);
  const nodeMatCyan = new THREE.MeshStandardMaterial({
    color: 0x00f0ff,
    emissive: 0x00f0ff,
    emissiveIntensity: 0.95,
    roughness: 0.2
  });
  const nodeMatAmber = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    emissive: 0xf59e0b,
    emissiveIntensity: 0.95,
    roughness: 0.2
  });

  const dirs = [
    [0, 1, 0, 0, 0, 0, nodeMatCyan],
    [0, -1, 0, Math.PI, 0, 0, nodeMatCyan],
    [1, 0, 0, 0, 0, -Math.PI / 2, nodeMatAmber],
    [-1, 0, 0, 0, 0, Math.PI / 2, nodeMatAmber],
    [0, 0, 1, Math.PI / 2, 0, 0, nodeMatCyan],
    [0, 0, -1, -Math.PI / 2, 0, 0, nodeMatCyan]
  ];
  dirs.forEach(([dx, dy, dz, rx, ry, rz, mat]) => {
    const node = new THREE.Mesh(nodeGeo, mat);
    node.position.set(dx * r * 0.95, dy * r * 0.95, dz * r * 0.95);
    node.rotation.set(rx, ry, rz);
    ballVisualGroup.add(node);
  });

  const contactShadowMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(r * 2.8, r * 2.8),
    new THREE.MeshBasicMaterial({
      map: contactShadowTex,
      transparent: true,
      depthWrite: false
    })
  );
  contactShadowMesh.rotation.x = -Math.PI / 2;
  scene.add(contactShadowMesh);
  scene.add(ballRoot);

  // 6. InstancedMesh Background Floating Sky Crystals
  const shardCount = 120;
  const shardGeo = new THREE.OctahedronGeometry(1.0, 0);
  const shardMat = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    emissive: 0x0284c7,
    emissiveIntensity: 0.35,
    metalness: 0.7,
    roughness: 0.25
  });
  const shardInstanced = new THREE.InstancedMesh(shardGeo, shardMat, shardCount);
  const shardData = [];
  const dummyMatrix = new THREE.Matrix4();
  const dummyPos = new THREE.Vector3();
  const dummyQuat = new THREE.Quaternion();
  const dummyScale = new THREE.Vector3();
  const dummyEuler = new THREE.Euler();

  for (let i = 0; i < shardCount; i++) {
    const side = i % 2 === 0 ? 1 : -1;
    const x = side * (16 + (i * 7.3) % 45);
    const y = -12 + ((i * 5.1) % 36);
    const z = -((i * 2.1) % 240);
    const s = 0.4 + (i % 5) * 0.35;
    shardData.push({ x, y, z, s, speed: 0.3 + (i % 4) * 0.2, phase: i * 0.7 });
  }
  scene.add(shardInstanced);

  // 7. Pooled 3D Particle System
  const PARTICLE_COUNT = 80;
  const particleGeo = new THREE.SphereGeometry(0.14, 8, 8);
  const particleMat = new THREE.MeshBasicMaterial({ color: 0x00f0ff });
  const particleInstanced = new THREE.InstancedMesh(particleGeo, particleMat, PARTICLE_COUNT);
  particleInstanced.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  scene.add(particleInstanced);

  const particles = [];
  for (let i = 0; i < PARTICLE_COUNT; i++) {
    particles.push({
      active: false,
      pos: new THREE.Vector3(0, -999, 0),
      vel: new THREE.Vector3(),
      life: 0,
      maxLife: 0.5,
      scale: 1
    });
  }

  function spawnParticleBurst(origin, count, speed, spreadY) {
    let spawned = 0;
    for (let i = 0; i < PARTICLE_COUNT && spawned < count; i++) {
      const p = particles[i];
      if (!p.active) {
        p.active = true;
        p.pos.copy(origin);
        const angle = (spawned / count) * Math.PI * 2 + Math.random() * 0.4;
        const mag = speed * (0.5 + Math.random() * 0.6);
        p.vel.set(
          Math.cos(angle) * mag,
          (spreadY || 3.5) * (0.4 + Math.random() * 0.8),
          Math.sin(angle) * mag
        );
        p.life = 0;
        p.maxLife = 0.35 + Math.random() * 0.25;
        p.scale = 0.8 + Math.random() * 0.7;
        spawned++;
      }
    }
  }

  // 8. Level Scene Group & Physics World
  const levelGroup = new THREE.Group();
  scene.add(levelGroup);
  const physics = new window.GravityPhysicsWorld();

  let currentLevelIndex = 0;
  let currentLevelData = window.GRAVITY_LEVELS[0];
  let activeSpawnPoint = new THREE.Vector3(0, 1.8, 0);
  let activatedCheckpoints = new Set();
  let checkpointVisuals = [];
  let finishGateVisual = null;
  let finishTargetPos = new THREE.Vector3(0, 0, -96);

  // Game State
  let gameState = 'TITLE'; // 'TITLE', 'PLAYING', 'PAUSED', 'COMPLETE'
  let levelTimerSec = 0;
  let fallCount = 0;
  let elapsedClock = 0;
  let hitstopTimer = 0;
  let cameraShake = 0;
  let ballSquash = 0;

  // Input state
  const inputState = {
    joyX: 0,
    joyZ: 0,
    keyLeft: false,
    keyRight: false,
    keyUp: false,
    keyDown: false,
    boost: false
  };

  function createCompositePlatform(cfg) {
    const group = new THREE.Group();
    const [w, h, d] = cfg.size;

    const topTex = deckBumpTex.clone();
    topTex.repeat.set(Math.max(1, w / 3), Math.max(1, d / 3));
    topTex.needsUpdate = true;

    const deckMat = new THREE.MeshStandardMaterial({
      color: cfg.color || '#1E293B',
      metalness: 0.55,
      roughness: 0.38,
      bumpMap: topTex,
      bumpScale: 0.025
    });
    const deckMesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), deckMat);
    deckMesh.castShadow = true;
    deckMesh.receiveShadow = true;
    group.add(deckMesh);

    const trimMat = new THREE.MeshStandardMaterial({
      color: cfg.trim || '#00F0FF',
      emissive: cfg.trim || '#00F0FF',
      emissiveIntensity: 0.65,
      roughness: 0.2
    });
    const trimGeo = new THREE.BoxGeometry(0.14, h * 0.45, d + 0.04);
    const leftTrim = new THREE.Mesh(trimGeo, trimMat);
    leftTrim.position.set(-w / 2 - 0.04, h * 0.18, 0);
    group.add(leftTrim);

    const rightTrim = new THREE.Mesh(trimGeo, trimMat);
    rightTrim.position.set(w / 2 + 0.04, h * 0.18, 0);
    group.add(rightTrim);

    const chassisMat = new THREE.MeshStandardMaterial({
      color: '#090D16',
      metalness: 0.8,
      roughness: 0.3
    });
    const chassis = new THREE.Mesh(new THREE.BoxGeometry(w * 0.76, h * 0.4, d * 0.82), chassisMat);
    chassis.position.y = -h * 0.65;
    group.add(chassis);

    const thrusterCone = new THREE.Mesh(
      new THREE.CylinderGeometry(Math.min(w, d) * 0.18, Math.min(w, d) * 0.28, 0.45, 12),
      trimMat
    );
    thrusterCone.position.y = -h * 0.92;
    group.add(thrusterCone);

    group.position.set(cfg.pos[0], cfg.pos[1], cfg.pos[2]);
    if (cfg.rot) {
      group.rotation.set(cfg.rot[0], cfg.rot[1], cfg.rot[2]);
    }
    return group;
  }

  function createCheckpointBeacon(cp) {
    const group = new THREE.Group();
    group.position.set(cp.pos[0], cp.pos[1], cp.pos[2]);

    const padMat = new THREE.MeshStandardMaterial({
      color: '#1E293B',
      metalness: 0.8,
      roughness: 0.25
    });
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.85, 0.22, 16), padMat);
    pad.receiveShadow = true;
    group.add(pad);

    const ringMat = new THREE.MeshStandardMaterial({
      color: '#00F0FF',
      emissive: '#00F0FF',
      emissiveIntensity: 0.85,
      roughness: 0.2
    });
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.35, 0.1, 12, 32), ringMat);
    ring.position.y = 1.45;
    group.add(ring);

    const pylonGeo = new THREE.CylinderGeometry(0.12, 0.18, 2.2, 10);
    const leftPylon = new THREE.Mesh(pylonGeo, padMat);
    leftPylon.position.set(-1.55, 1.1, 0);
    group.add(leftPylon);

    const rightPylon = new THREE.Mesh(pylonGeo, padMat);
    rightPylon.position.set(1.55, 1.1, 0);
    group.add(rightPylon);

    return { group, ring, ringMat, data: cp };
  }

  function createFinishGate(pos) {
    const group = new THREE.Group();
    group.position.set(pos[0], pos[1], pos[2]);

    const pillarMat = new THREE.MeshStandardMaterial({
      color: '#0F172A',
      metalness: 0.85,
      roughness: 0.2
    });
    const pillarGeo = new THREE.BoxGeometry(0.65, 4.6, 0.65);

    const leftPillar = new THREE.Mesh(pillarGeo, pillarMat);
    leftPillar.position.set(-2.6, 2.3, 0);
    leftPillar.castShadow = true;
    group.add(leftPillar);

    const rightPillar = new THREE.Mesh(pillarGeo, pillarMat);
    rightPillar.position.set(2.6, 2.3, 0);
    rightPillar.castShadow = true;
    group.add(rightPillar);

    const archHeader = new THREE.Mesh(new THREE.BoxGeometry(6.2, 0.7, 0.85), pillarMat);
    archHeader.position.set(0, 4.6, 0);
    archHeader.castShadow = true;
    group.add(archHeader);

    const outerPortal = new THREE.Mesh(
      new THREE.TorusGeometry(2.1, 0.14, 14, 40),
      new THREE.MeshStandardMaterial({
        color: '#10B981',
        emissive: '#10B981',
        emissiveIntensity: 0.95
      })
    );
    outerPortal.position.set(0, 2.3, 0);
    group.add(outerPortal);

    const innerPortal = new THREE.Mesh(
      new THREE.TorusGeometry(1.55, 0.09, 12, 32),
      new THREE.MeshStandardMaterial({
        color: '#00F0FF',
        emissive: '#00F0FF',
        emissiveIntensity: 0.9
      })
    );
    innerPortal.position.set(0, 2.3, 0);
    group.add(innerPortal);

    return { group, outerPortal, innerPortal };
  }

  // Load any Level by Index (0..9 for Levels 1..10)
  function loadLevel(levelIndex) {
    currentLevelIndex = Math.max(0, Math.min(window.GRAVITY_LEVELS.length - 1, levelIndex));
    currentLevelData = window.GRAVITY_LEVELS[currentLevelIndex];

    while (levelGroup.children.length > 0) {
      levelGroup.remove(levelGroup.children[0]);
    }
    physics.clearColliders();
    activatedCheckpoints.clear();
    checkpointVisuals = [];

    scene.background.set(currentLevelData.skyTop);
    scene.fog.color.set(currentLevelData.fogColor);

    // 1. Static Platforms, Ramps & Turns
    currentLevelData.platforms.forEach((p, idx) => {
      const meshGroup = createCompositePlatform(p);
      levelGroup.add(meshGroup);

      const quat = new THREE.Quaternion();
      if (p.rot) {
        quat.setFromEuler(new THREE.Euler(p.rot[0], p.rot[1], p.rot[2], 'YXZ'));
        meshGroup.quaternion.copy(quat);
      }
      physics.addBoxCollider({
        id: 'plat_' + idx,
        mesh: meshGroup,
        position: new THREE.Vector3(p.pos[0], p.pos[1], p.pos[2]),
        halfExtents: new THREE.Vector3(p.size[0] / 2, p.size[1] / 2, p.size[2] / 2),
        quaternion: quat,
        friction: 0.9
      });

      if (p.rails === 'both') {
        const railH = 0.55;
        const railW = 0.25;
        [-1, 1].forEach((side) => {
          const localOffset = new THREE.Vector3(
            side * (p.size[0] / 2 - railW / 2),
            p.size[1] / 2 + railH / 2,
            0
          ).applyQuaternion(quat);
          const railPos = new THREE.Vector3(p.pos[0], p.pos[1], p.pos[2]).add(localOffset);

          const railMesh = new THREE.Mesh(
            new THREE.BoxGeometry(railW, railH, p.size[2]),
            new THREE.MeshStandardMaterial({
              color: p.trim || '#00F0FF',
              emissive: p.trim || '#00F0FF',
              emissiveIntensity: 0.35
            })
          );
          railMesh.position.copy(railPos);
          railMesh.quaternion.copy(quat);
          levelGroup.add(railMesh);
          physics.addBoxCollider({
            position: railPos,
            halfExtents: new THREE.Vector3(railW / 2, railH / 2, p.size[2] / 2),
            quaternion: quat,
            restitution: 0.35
          });
        });
      }
    });

    // 2. Kinematic Rotating Platforms & Spinning Mills
    (currentLevelData.rotatingPlatforms || []).forEach((rp, idx) => {
      const group = createCompositePlatform({
        pos: rp.pos,
        size: rp.size,
        color: rp.color || '#312E81',
        trim: rp.trim || '#A855F7'
      });

      const hub = new THREE.Mesh(
        new THREE.CylinderGeometry(0.85, 0.95, rp.size[1] + 0.35, 16),
        new THREE.MeshStandardMaterial({
          color: rp.trim || '#F59E0B',
          emissive: rp.trim || '#F59E0B',
          emissiveIntensity: 0.5,
          metalness: 0.8,
          roughness: 0.2
        })
      );
      group.add(hub);
      levelGroup.add(group);

      const speed = rp.speed || 1.0;
      physics.addBoxCollider({
        id: 'rot_' + idx,
        mesh: group,
        position: new THREE.Vector3(rp.pos[0], rp.pos[1], rp.pos[2]),
        halfExtents: new THREE.Vector3(rp.size[0] / 2, rp.size[1] / 2, rp.size[2] / 2),
        isHazardBumper: !!rp.isHazard,
        knockbackStrength: rp.isHazard ? 11.5 : 0,
        friction: 0.95,
        kinematicUpdate: (col, t) => {
          const angle = t * speed;
          col.quaternion.setFromAxisAngle(new THREE.Vector3(0, 1, 0), angle);
          col.angularVelocity.set(0, speed, 0);
        }
      });
    });

    // 3. Kinematic Moving Obstacles (Timed Gates, Pistons & Ferries)
    (currentLevelData.movingObstacles || []).forEach((mo, idx) => {
      let group;
      if (mo.kind === 'timed_gate') {
        // Static outer gate frame so player sees where the timed gate is located
        const frameGroup = new THREE.Group();
        frameGroup.position.set(mo.pos[0], mo.pos[1] - 0.6, mo.pos[2]);
        const postMat = new THREE.MeshStandardMaterial({ color: '#1E293B', metalness: 0.8, roughness: 0.25 });
        const postGeo = new THREE.BoxGeometry(0.35, 4.2, 0.55);
        const lPost = new THREE.Mesh(postGeo, postMat);
        lPost.position.set(-mo.size[0] / 2 - 0.2, 1.5, 0);
        const rPost = new THREE.Mesh(postGeo, postMat);
        rPost.position.set(mo.size[0] / 2 + 0.2, 1.5, 0);
        frameGroup.add(lPost);
        frameGroup.add(rPost);
        levelGroup.add(frameGroup);

        // Moving timed gate barrier
        group = new THREE.Group();
        const [w, h, d] = mo.size;
        const gatePanel = new THREE.Mesh(
          new THREE.BoxGeometry(w, h, d),
          new THREE.MeshStandardMaterial({
            map: hazardTex,
            emissive: '#F59E0B',
            emissiveIntensity: 0.28,
            metalness: 0.5,
            roughness: 0.3
          })
        );
        gatePanel.castShadow = true;
        group.add(gatePanel);
        group.position.set(mo.pos[0], mo.pos[1], mo.pos[2]);
      } else if (mo.isHazard) {
        group = new THREE.Group();
        const [w, h, d] = mo.size;
        const body = new THREE.Mesh(
          new THREE.BoxGeometry(w, h, d),
          new THREE.MeshStandardMaterial({
            map: hazardTex,
            metalness: 0.4,
            roughness: 0.35
          })
        );
        body.castShadow = true;
        group.add(body);

        const beacon = new THREE.Mesh(
          new THREE.SphereGeometry(Math.min(w, d) * 0.28, 12, 12),
          new THREE.MeshStandardMaterial({
            color: '#EF4444',
            emissive: '#EF4444',
            emissiveIntensity: 0.9
          })
        );
        beacon.position.y = h / 2 + 0.15;
        group.add(beacon);
        group.position.set(mo.pos[0], mo.pos[1], mo.pos[2]);
      } else {
        group = createCompositePlatform({
          pos: mo.pos,
          size: mo.size,
          color: mo.color || '#0284C7',
          trim: mo.trim || '#38BDF8'
        });
      }
      levelGroup.add(group);

      const amp = mo.amplitude || 2.0;
      const spd = mo.speed || 1.5;
      const phs = mo.phase || 0;
      const axis = mo.axis || 'x';

      physics.addBoxCollider({
        id: 'mov_' + idx,
        mesh: group,
        position: new THREE.Vector3(mo.pos[0], mo.pos[1], mo.pos[2]),
        halfExtents: new THREE.Vector3(mo.size[0] / 2, mo.size[1] / 2, mo.size[2] / 2),
        isHazardBumper: !!mo.isHazard,
        knockbackStrength: mo.isHazard ? 11.0 : 0,
        friction: 0.98,
        kinematicUpdate: (col, t) => {
          const offset = Math.sin(t * spd + phs) * amp;
          col.position.copy(col.basePosition);
          if (axis === 'x') col.position.x += offset;
          else if (axis === 'y') col.position.y += offset;
          else if (axis === 'z') col.position.z += offset;
        }
      });
    });

    // 4. Checkpoint Beacons
    (currentLevelData.checkpoints || []).forEach((cp) => {
      const cpVis = createCheckpointBeacon(cp);
      levelGroup.add(cpVis.group);
      checkpointVisuals.push(cpVis);
    });

    // 5. Finish Gate Portal
    finishTargetPos.set(
      currentLevelData.finish[0],
      currentLevelData.finish[1],
      currentLevelData.finish[2]
    );
    finishGateVisual = createFinishGate(currentLevelData.finish);
    levelGroup.add(finishGateVisual.group);

    // Reset spawn, timer, falls, and ball state
    activeSpawnPoint.set(
      currentLevelData.spawn[0],
      currentLevelData.spawn[1],
      currentLevelData.spawn[2]
    );
    levelTimerSec = 0;
    fallCount = 0;
    respawnBall(false);
    // Snap camera immediately near the spawn point so there is no disorienting sweep on level switch
    camCurrentPos.set(activeSpawnPoint.x, activeSpawnPoint.y + 4.8, activeSpawnPoint.z + 7.6);
    camCurrentLook.set(activeSpawnPoint.x, activeSpawnPoint.y + 0.5, activeSpawnPoint.z - 5.0);
    notifyNativeState();
  }

  function triggerScreenFlash(cssColor) {
    if (!fxOverlay) return;
    fxOverlay.style.background = cssColor;
    fxOverlay.style.opacity = '0.38';
    setTimeout(() => {
      fxOverlay.style.opacity = '0';
    }, 180);
  }

  function respawnBall(isFall) {
    physics.resetBall(activeSpawnPoint);
    if (isFall) {
      fallCount++;
      window.GameAudio.playFall();
      triggerScreenFlash('radial-gradient(circle, transparent 40%, rgba(239,68,68,0.65) 100%)');
      if (window.AndroidBridge && window.AndroidBridge.onBallFell) {
        window.AndroidBridge.onBallFell(fallCount);
      }
    }
    spawnParticleBurst(activeSpawnPoint, 16, 4.5, 4.0);
  }

  // 9. Camera Tracking State (Exponentially Damped Landscape Third-Person Follow)
  const camCurrentPos = new THREE.Vector3(0, 6, 9);
  const camCurrentLook = new THREE.Vector3(0, 1, -4);
  const _targetCamPos = new THREE.Vector3();
  const _targetLookPos = new THREE.Vector3();
  const _camForward = new THREE.Vector3(0, 0, -1);
  const _camRight = new THREE.Vector3(1, 0, 0);
  let cameraPreset = 0; // 0 = Standard Follow, 1 = High Overview, 2 = Low Action

  function updateCamera(dt) {
    const b = physics.ball;
    if (gameState === 'TITLE' || gameState === 'COMPLETE') {
      const orbitAngle = elapsedClock * 0.35;
      const focusX = gameState === 'COMPLETE' ? finishTargetPos.x : 0;
      const focusZ = gameState === 'COMPLETE' ? finishTargetPos.z : -18;
      const focusY = gameState === 'COMPLETE' ? finishTargetPos.y + 1.5 : 2.0;
      _targetCamPos.set(
        focusX + Math.sin(orbitAngle) * 14,
        focusY + 7.2,
        focusZ + Math.cos(orbitAngle) * 14
      );
      _targetLookPos.set(focusX, focusY, focusZ - 4);
      const alpha = 1 - Math.exp(-3.5 * dt);
      camCurrentPos.lerp(_targetCamPos, alpha);
      camCurrentLook.lerp(_targetLookPos, alpha);
    } else {
      const presetHeight = cameraPreset === 1 ? 6.6 : cameraPreset === 2 ? 3.2 : 4.5;
      const presetDist = cameraPreset === 1 ? 9.2 : cameraPreset === 2 ? 5.8 : 7.2;
      const speedPullback = Math.min(2.0, b.velocity.length() * 0.09);

      // Directly track ball.x so lateral turns at x=±10 keep the ball centered in 16:9 landscape
      _targetCamPos.set(
        b.position.x - b.velocity.x * 0.08,
        b.position.y + presetHeight,
        b.position.z + presetDist + speedPullback
      );
      _targetLookPos.set(
        b.position.x + b.velocity.x * 0.14,
        b.position.y + 0.5,
        b.position.z - 5.2
      );

      const alpha = 1 - Math.exp(-10.0 * dt);
      camCurrentPos.lerp(_targetCamPos, alpha);
      camCurrentLook.lerp(_targetLookPos, alpha);
    }

    camera.position.copy(camCurrentPos);
    if (cameraShake > 0.001) {
      camera.position.x += (Math.random() - 0.5) * cameraShake;
      camera.position.y += (Math.random() - 0.5) * cameraShake;
      cameraShake = Math.max(0, cameraShake - dt * 2.4);
    }
    camera.lookAt(camCurrentLook);
  }

  function computeProgressPercent() {
    const startZ = currentLevelData.spawn[2];
    const endZ = currentLevelData.finish[2];
    const totalDist = Math.max(1, Math.abs(endZ - startZ));
    const covered = Math.max(0, startZ - physics.ball.position.z);
    return Math.min(100, Math.round((covered / totalDist) * 100));
  }

  let lastHudSyncTime = 0;
  function notifyNativeState() {
    if (window.AndroidBridge && window.AndroidBridge.onHudUpdate) {
      const prog = computeProgressPercent();
      window.AndroidBridge.onHudUpdate(
        currentLevelData.id,
        Math.round(levelTimerSec * 1000),
        prog,
        activatedCheckpoints.size,
        (currentLevelData.checkpoints || []).length,
        fallCount
      );
    }
  }

  // 10. Keyboard Controls
  window.addEventListener('keydown', (e) => {
    const code = e.code;
    if (code === 'KeyA' || code === 'ArrowLeft') inputState.keyLeft = true;
    if (code === 'KeyD' || code === 'ArrowRight') inputState.keyRight = true;
    if (code === 'KeyW' || code === 'ArrowUp') inputState.keyUp = true;
    if (code === 'KeyS' || code === 'ArrowDown') inputState.keyDown = true;
    if (code === 'ShiftLeft' || code === 'ShiftRight') inputState.boost = true;
    if (code === 'Space') {
      if (gameState === 'PLAYING') {
        physics.requestJump();
      } else if (gameState === 'TITLE') {
        window.GravityBallGame.startGame(currentLevelIndex + 1);
      }
    }
    if (code === 'KeyR' && gameState === 'PLAYING') {
      respawnBall(false);
    }
    if (code === 'Escape' || code === 'KeyP') {
      if (gameState === 'PLAYING') {
        window.GravityBallGame.setPaused(true);
      } else if (gameState === 'PAUSED') {
        window.GravityBallGame.setPaused(false);
      }
    }
  });

  window.addEventListener('keyup', (e) => {
    const code = e.code;
    if (code === 'KeyA' || code === 'ArrowLeft') inputState.keyLeft = false;
    if (code === 'KeyD' || code === 'ArrowRight') inputState.keyRight = false;
    if (code === 'KeyW' || code === 'ArrowUp') inputState.keyUp = false;
    if (code === 'KeyS' || code === 'ArrowDown') inputState.keyDown = false;
    if (code === 'ShiftLeft' || code === 'ShiftRight') inputState.boost = false;
  });

  window.addEventListener('blur', () => {
    inputState.keyLeft = false;
    inputState.keyRight = false;
    inputState.keyUp = false;
    inputState.keyDown = false;
    inputState.boost = false;
    inputState.joyX = 0;
    inputState.joyZ = 0;
  });

  window.addEventListener('resize', updateViewportProjection);
  window.addEventListener('orientationchange', () => {
    setTimeout(updateViewportProjection, 60);
    setTimeout(updateViewportProjection, 220);
  });
  if (screen.orientation && screen.orientation.addEventListener) {
    screen.orientation.addEventListener('change', updateViewportProjection);
  }

  // 11. Main 60fps Animation Loop
  let lastFrameTime = performance.now();

  function animate(now) {
    requestAnimationFrame(animate);
    const rawDt = (now - lastFrameTime) / 1000;
    lastFrameTime = now;
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);
    elapsedClock += dt;

    if (hitstopTimer > 0) {
      hitstopTimer = Math.max(0, hitstopTimer - dt);
      renderer.render(scene, camera);
      return;
    }

    if (gameState === 'PLAYING') {
      levelTimerSec += dt;

      // Combine virtual joystick + keyboard inputs
      const kx = (inputState.keyRight ? 1 : 0) - (inputState.keyLeft ? 1 : 0);
      const kz = (inputState.keyDown ? 1 : 0) - (inputState.keyUp ? 1 : 0);
      const rawX = Math.max(-1, Math.min(1, inputState.joyX + kx));
      const rawZ = Math.max(-1, Math.min(1, inputState.joyZ + kz));

      // Compute camera-relative horizontal vectors so joystick always steers relative to camera view
      _camForward.subVectors(camCurrentLook, camCurrentPos);
      _camForward.y = 0;
      if (_camForward.lengthSq() > 0.0001) {
        _camForward.normalize();
      } else {
        _camForward.set(0, 0, -1);
      }
      _camRight.set(-_camForward.z, 0, _camForward.x);

      // rawZ < 0 is pushing joystick UP (forward along _camForward)
      const worldMoveX = _camRight.x * rawX + _camForward.x * (-rawZ);
      const worldMoveZ = _camRight.z * rawX + _camForward.z * (-rawZ);

      physics.step(
        dt,
        { x: worldMoveX, z: worldMoveZ, boost: inputState.boost },
        elapsedClock,
        {
          onJump: () => {
            window.GameAudio.playJump();
            ballSquash = 0.28;
            spawnParticleBurst(physics.ball.position, 12, 3.2, 1.5);
          },
          onHeavyLand: (intensity) => {
            window.GameAudio.playLand(intensity);
            ballSquash = -0.25 * intensity;
            cameraShake = Math.max(cameraShake, intensity * 0.28);
            spawnParticleBurst(physics.ball.position, 10, 3.0, 2.0);
          },
          onHazardHit: () => {
            window.GameAudio.playBump();
            hitstopTimer = 0.045;
            cameraShake = 0.42;
            triggerScreenFlash('radial-gradient(circle, transparent 35%, rgba(245,158,11,0.55) 100%)');
            spawnParticleBurst(physics.ball.position, 22, 6.0, 4.5);
            if (window.AndroidBridge && window.AndroidBridge.onHazardHit) {
              window.AndroidBridge.onHazardHit();
            }
          }
        }
      );

      // Check Void Fall & Respawn
      if (physics.ball.position.y < currentLevelData.voidY) {
        respawnBall(true);
      }

      // Check Checkpoints
      for (let i = 0; i < checkpointVisuals.length; i++) {
        const cp = checkpointVisuals[i];
        cp.ring.rotation.y += dt * 2.2;
        if (!activatedCheckpoints.has(cp.data.id)) {
          const distSq = physics.ball.position.distanceToSquared(cp.group.position);
          if (distSq < 4.8) {
            activatedCheckpoints.add(cp.data.id);
            activeSpawnPoint.set(cp.data.spawn[0], cp.data.spawn[1], cp.data.spawn[2]);
            cp.ringMat.color.set('#10B981');
            cp.ringMat.emissive.set('#10B981');
            window.GameAudio.playCheckpoint();
            triggerScreenFlash('radial-gradient(circle, transparent 45%, rgba(16,185,129,0.45) 100%)');
            spawnParticleBurst(cp.group.position, 24, 5.2, 5.0);
            if (window.AndroidBridge && window.AndroidBridge.onCheckpointReached) {
              window.AndroidBridge.onCheckpointReached(
                cp.data.id,
                checkpointVisuals.length
              );
            }
          }
        }
      }

      // Check Finish Gate
      if (finishGateVisual) {
        finishGateVisual.outerPortal.rotation.z += dt * 1.6;
        finishGateVisual.innerPortal.rotation.y -= dt * 2.4;
        const gateCenter = new THREE.Vector3(
          finishTargetPos.x,
          finishTargetPos.y + 1.5,
          finishTargetPos.z
        );
        if (physics.ball.position.distanceTo(gateCenter) < 2.75) {
          gameState = 'COMPLETE';
          window.GameAudio.playVictory();
          spawnParticleBurst(gateCenter, 40, 7.5, 7.0);
          const timeMs = Math.round(levelTimerSec * 1000);
          const lvlId = currentLevelData.id;

          // Persist in localStorage as well
          savedProgress.completed[lvlId] = true;
          if (!savedProgress.bestTimes[lvlId] || timeMs < savedProgress.bestTimes[lvlId]) {
            savedProgress.bestTimes[lvlId] = timeMs;
          }
          if (lvlId < window.GRAVITY_LEVELS.length && savedProgress.unlockedLevel < lvlId + 1) {
            savedProgress.unlockedLevel = lvlId + 1;
          }
          saveLocalProgress(savedProgress);

          if (window.AndroidBridge && window.AndroidBridge.onLevelComplete) {
            window.AndroidBridge.onLevelComplete(lvlId, timeMs, fallCount);
          }
        }
      }

      if (now - lastHudSyncTime > 90) {
        lastHudSyncTime = now;
        notifyNativeState();
      }
    } else {
      for (let i = 0; i < physics.colliders.length; i++) {
        const col = physics.colliders[i];
        if (col.kinematicUpdate) {
          col.kinematicUpdate(col, elapsedClock, dt);
          if (col.mesh) {
            col.mesh.position.copy(col.position);
            col.mesh.quaternion.copy(col.quaternion);
          }
        }
      }
      if (finishGateVisual) {
        finishGateVisual.outerPortal.rotation.z += dt * 1.6;
        finishGateVisual.innerPortal.rotation.y -= dt * 2.4;
      }
    }

    // Update Hero Ball Transform & Squash-Stretch
    ballRoot.position.copy(physics.ball.position);
    ballVisualGroup.quaternion.copy(physics.ball.quaternion);
    if (Math.abs(ballSquash) > 0.002) {
      const sy = 1.0 + ballSquash;
      const sxz = 1.0 / Math.sqrt(Math.max(0.5, sy));
      ballRoot.scale.set(sxz, sy, sxz);
      ballSquash *= Math.exp(-12.0 * dt);
    } else {
      ballRoot.scale.set(1, 1, 1);
    }

    contactShadowMesh.position.set(
      physics.ball.position.x,
      physics.ball.grounded ? physics.ball.position.y - physics.ball.radius + 0.03 : -999,
      physics.ball.position.z
    );
    dirLight.position.set(
      physics.ball.position.x + 16,
      physics.ball.position.y + 28,
      physics.ball.position.z + 18
    );
    dirLight.target.position.copy(physics.ball.position);

    for (let i = 0; i < shardCount; i++) {
      const sd = shardData[i];
      dummyPos.set(sd.x, sd.y + Math.sin(elapsedClock * sd.speed + sd.phase) * 1.4, sd.z);
      dummyEuler.set(elapsedClock * sd.speed, elapsedClock * 0.4 + sd.phase, 0);
      dummyQuat.setFromEuler(dummyEuler);
      dummyScale.set(sd.s, sd.s * 1.5, sd.s);
      dummyMatrix.compose(dummyPos, dummyQuat, dummyScale);
      shardInstanced.setMatrixAt(i, dummyMatrix);
    }
    shardInstanced.instanceMatrix.needsUpdate = true;

    for (let i = 0; i < PARTICLE_COUNT; i++) {
      const p = particles[i];
      if (p.active) {
        p.life += dt;
        if (p.life >= p.maxLife) {
          p.active = false;
          dummyPos.set(0, -999, 0);
          dummyScale.set(0.001, 0.001, 0.001);
        } else {
          p.vel.y -= 14.0 * dt;
          p.pos.addScaledVector(p.vel, dt);
          const s = p.scale * (1.0 - p.life / p.maxLife);
          dummyPos.copy(p.pos);
          dummyScale.set(s, s, s);
        }
        dummyQuat.identity();
        dummyMatrix.compose(dummyPos, dummyQuat, dummyScale);
        particleInstanced.setMatrixAt(i, dummyMatrix);
      }
    }
    particleInstanced.instanceMatrix.needsUpdate = true;

    updateCamera(dt);
    renderer.render(scene, camera);
  }

  // 12. Public API exposed to Android Compose HUD & Browser Controls
  window.GravityBallGame = {
    startGame: function (levelId) {
      window.GameAudio.resume();
      tryLockLandscapeOrientation();
      loadLevel((levelId || 1) - 1);
      gameState = 'PLAYING';
    },
    previewLevel: function (levelId) {
      loadLevel((levelId || 1) - 1);
      gameState = 'TITLE';
    },
    restartLevel: function () {
      window.GameAudio.resume();
      loadLevel(currentLevelIndex);
      gameState = 'PLAYING';
    },
    respawnAtCheckpoint: function () {
      if (gameState === 'PLAYING') {
        respawnBall(true);
      }
    },
    setPaused: function (paused) {
      if (paused && gameState === 'PLAYING') {
        gameState = 'PAUSED';
      } else if (!paused && gameState === 'PAUSED') {
        gameState = 'PLAYING';
      }
    },
    setJoystick: function (x, z) {
      inputState.joyX = Math.max(-1, Math.min(1, Number(x) || 0));
      inputState.joyZ = Math.max(-1, Math.min(1, Number(z) || 0));
    },
    jump: function () {
      window.GameAudio.resume();
      physics.requestJump();
    },
    setBoost: function (active) {
      inputState.boost = !!active;
    },
    setMuted: function (muted) {
      window.GameAudio.setMuted(!!muted);
    },
    cycleCameraPreset: function () {
      cameraPreset = (cameraPreset + 1) % 3;
      return cameraPreset;
    },
    getSavedProgress: function () {
      return savedProgress;
    },
    resetSavedProgress: function () {
      savedProgress = { unlockedLevel: 1, completed: {}, bestTimes: {}, stars: {} };
      saveLocalProgress(savedProgress);
      return savedProgress;
    }
  };

  loadLevel(0);
  requestAnimationFrame(animate);
})();
