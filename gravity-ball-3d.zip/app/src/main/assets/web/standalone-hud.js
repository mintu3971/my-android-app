// Standalone Browser / PWA Landscape HUD, Rotate-Phone Detector, Home Screen,
// 10-Level Selection Grid, and Settings Screen.
// Automatically activates when opened directly in a mobile or desktop web browser.
(function () {
  if (window.AndroidBridge) return; // Native Android Compose HUD is active

  const STORAGE_KEY = 'gravity_ball_3d_progress_v2';
  function loadProgress() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return { unlockedLevel: 1, completed: {}, bestTimes: {}, stars: {} };
  }
  function saveProgress(data) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {}
  }

  let progress = loadProgress();
  let activeLevel = 1;
  let muted = false;
  let rotateDismissed = false;

  // 1. Portrait Orientation Warning Screen
  const rotateOverlay = document.createElement('div');
  rotateOverlay.id = 'gb-rotate-overlay';
  rotateOverlay.innerHTML = `
    <div style="font-size:48px;color:#00F0FF;margin-bottom:14px;">⟳</div>
    <h2 style="color:#00F0FF;font-size:22px;letter-spacing:1.5px;margin-bottom:8px;">ROTATE YOUR PHONE</h2>
    <p style="color:#E2E8F0;max-width:320px;line-height:1.5;margin-bottom:20px;font-size:14px;">
      GRAVITY BALL 3D is designed for 16:9 horizontal landscape gameplay. Please rotate your device to landscape mode.
    </p>
    <button id="gb-lock-landscape-btn" style="padding:12px 20px;border-radius:12px;background:#00F0FF;color:#060B1E;font-weight:800;border:none;cursor:pointer;">
      CONTINUE IN LANDSCAPE
    </button>
  `;
  document.body.appendChild(rotateOverlay);

  function checkOrientation() {
    const isPortrait = window.innerHeight > window.innerWidth * 1.05;
    rotateOverlay.style.display = (isPortrait && !rotateDismissed) ? 'flex' : 'none';
  }
  rotateOverlay.querySelector('#gb-lock-landscape-btn').onclick = () => {
    rotateDismissed = true;
    if (screen.orientation && screen.orientation.lock) {
      screen.orientation.lock('landscape').catch(() => {});
    }
    checkOrientation();
  };
  window.addEventListener('resize', checkOrientation);
  window.addEventListener('orientationchange', checkOrientation);
  checkOrientation();

  // 2. Main Landscape HUD Root
  const hudRoot = document.createElement('div');
  hudRoot.id = 'pwa-hud-root';
  hudRoot.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:10;display:flex;flex-direction:column;justify-content:space-between;padding:calc(env(safe-area-inset-top, 0px) + 12px) calc(env(safe-area-inset-right, 0px) + 20px) calc(env(safe-area-inset-bottom, 0px) + 16px) calc(env(safe-area-inset-left, 0px) + 20px);';
  document.body.appendChild(hudRoot);

  const topBar = document.createElement('div');
  topBar.style.cssText = 'display:flex;justify-content:space-between;align-items:center;background:rgba(11,16,38,0.88);border:1px solid rgba(0,240,255,0.35);border-radius:14px;padding:8px 16px;pointer-events:auto;font-variant-numeric:tabular-nums;';
  topBar.innerHTML = `
    <div id="pwa-lvl-label" style="font-weight:800;color:#00F0FF;letter-spacing:1px;font-size:14px;">LVL 1: TUTORIAL PROMENADE</div>
    <div id="pwa-prog-label" style="color:#E2E8F0;font-weight:600;font-size:13px;">0% · CP 0/1</div>
    <div id="pwa-time-label" style="font-family:monospace;font-size:15px;font-weight:700;color:#FACC15;">0.0s</div>
    <div style="display:flex;gap:8px;">
      <button id="pwa-home-btn" style="background:#1E293B;color:#F8FAFC;border:1px solid #00F0FF;border-radius:8px;padding:5px 10px;cursor:pointer;font-weight:700;">HOME</button>
      <button id="pwa-restart-btn" style="background:#1E293B;color:#F8FAFC;border:1px solid #F59E0B;border-radius:8px;padding:5px 10px;cursor:pointer;font-weight:700;">RESTART</button>
    </div>
  `;
  hudRoot.appendChild(topBar);

  const modal = document.createElement('div');
  modal.style.cssText = 'margin:auto;background:rgba(11,16,38,0.94);border:2px solid #00F0FF;border-radius:20px;padding:22px;max-width:660px;width:94%;max-height:82vh;overflow-y:auto;text-align:center;pointer-events:auto;';
  hudRoot.appendChild(modal);

  // 3. Bottom-Left Fixed Joystick (132-156px) & Bottom-Right Action Cluster
  const joyZone = document.createElement('div');
  joyZone.className = 'gb-joystick-container';
  joyZone.innerHTML = `<div id="pwa-joy-knob" style="width:52px;height:52px;border-radius:50%;background:radial-gradient(circle at 35% 35%, #FFFFFF, #00F0FF);position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);box-shadow:0 0 12px rgba(0,240,255,0.8);"></div>`;
  document.body.appendChild(joyZone);

  const actionCluster = document.createElement('div');
  actionCluster.className = 'gb-action-cluster';
  actionCluster.innerHTML = `
    <button id="pwa-boost-btn" style="width:74px;height:74px;border-radius:50%;background:rgba(245,158,11,0.9);color:#090D16;font-weight:800;border:2px solid #FEF08A;cursor:pointer;">BOOST</button>
    <button id="pwa-jump-btn" style="width:88px;height:88px;border-radius:50%;background:rgba(0,240,255,0.94);color:#090D16;font-weight:900;border:3px solid #FFFFFF;cursor:pointer;">JUMP</button>
  `;
  document.body.appendChild(actionCluster);

  function setGameplayControlsVisible(vis) {
    joyZone.style.display = vis ? 'block' : 'none';
    actionCluster.style.display = vis ? 'flex' : 'none';
  }

  // HOME SCREEN
  function renderHomeScreen() {
    progress = loadProgress();
    setGameplayControlsVisible(false);
    modal.style.display = 'block';
    const currentLvl = window.GRAVITY_LEVELS[activeLevel - 1] || window.GRAVITY_LEVELS[0];
    modal.innerHTML = `
      <h1 style="color:#00F0FF;font-size:30px;letter-spacing:2px;margin-bottom:4px;">GRAVITY BALL 3D</h1>
      <p style="color:#94A3B8;font-size:13px;margin-bottom:16px;">16:9 Landscape 3D Rolling Obstacle Course · Stage ${activeLevel}: ${currentLvl.name}</p>
      <div style="display:flex;flex-direction:column;gap:10px;max-width:340px;margin:0 auto;">
        <button id="pwa-play-btn" style="padding:14px;border-radius:12px;background:#00F0FF;color:#060B1E;font-weight:900;font-size:16px;border:none;cursor:pointer;">PLAY (LEVEL ${activeLevel})</button>
        <button id="pwa-levels-btn" style="padding:12px;border-radius:12px;background:#1E293B;color:#00F0FF;font-weight:800;font-size:15px;border:1px solid #00F0FF;cursor:pointer;">LEVEL SELECTION (10 LEVELS)</button>
        <button id="pwa-settings-btn" style="padding:12px;border-radius:12px;background:#1E293B;color:#E2E8F0;font-weight:700;font-size:14px;border:1px solid #475569;cursor:pointer;">SETTINGS</button>
      </div>
    `;
    modal.querySelector('#pwa-play-btn').onclick = () => {
      modal.style.display = 'none';
      setGameplayControlsVisible(true);
      window.GravityBallGame.startGame(activeLevel);
    };
    modal.querySelector('#pwa-levels-btn').onclick = () => renderLevelSelectScreen();
    modal.querySelector('#pwa-settings-btn').onclick = () => renderSettingsScreen();
  }

  // SEPARATE LEVEL-SELECTION SCREEN (10 Levels Grid)
  function renderLevelSelectScreen() {
    progress = loadProgress();
    setGameplayControlsVisible(false);
    modal.style.display = 'block';
    const completedCount = Object.keys(progress.completed || {}).length;
    const cardsHtml = window.GRAVITY_LEVELS.map((lvl) => {
      const unlocked = lvl.id <= progress.unlockedLevel;
      const done = !!(progress.completed && progress.completed[lvl.id]);
      const bestMs = progress.bestTimes && progress.bestTimes[lvl.id];
      return `
        <button data-lvl="${lvl.id}" ${unlocked ? '' : 'disabled'} style="padding:10px;border-radius:12px;border:1.5px solid ${unlocked ? (done ? '#10B981' : '#00F0FF') : '#334155'};background:${lvl.id === activeLevel ? '#1A2A52' : '#131D3B'};color:#F8FAFC;text-align:left;cursor:${unlocked ? 'pointer' : 'not-allowed'};opacity:${unlocked ? '1' : '0.45'};">
          <div style="font-weight:800;font-size:13px;color:${unlocked ? '#00F0FF' : '#94A3B8'};">Level ${lvl.id} ${done ? '✓' : (unlocked ? '' : '🔒')}</div>
          <div style="font-weight:700;font-size:12px;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${lvl.name}</div>
          <div style="font-size:11px;color:#94A3B8;margin-top:4px;">${unlocked ? (bestMs ? 'Best: ' + (bestMs / 1000).toFixed(1) + 's' : 'Unlocked') : 'Locked'}</div>
        </button>
      `;
    }).join('');

    modal.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <button id="pwa-back-home" style="padding:8px 14px;border-radius:10px;background:#1E293B;color:#F8FAFC;border:1px solid #00F0FF;cursor:pointer;font-weight:700;">← BACK</button>
        <h2 style="color:#00F0FF;font-size:18px;">SELECT LEVEL (${completedCount}/10 COMPLETED)</h2>
        <div style="width:64px;"></div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(118px, 1fr));gap:8px;margin-bottom:12px;">
        ${cardsHtml}
      </div>
    `;

    modal.querySelector('#pwa-back-home').onclick = () => renderHomeScreen();
    modal.querySelectorAll('[data-lvl]').forEach((btn) => {
      btn.onclick = () => {
        activeLevel = Number(btn.getAttribute('data-lvl'));
        modal.style.display = 'none';
        setGameplayControlsVisible(true);
        window.GravityBallGame.startGame(activeLevel);
      };
    });
  }

  // SETTINGS SCREEN
  function renderSettingsScreen() {
    setGameplayControlsVisible(false);
    modal.style.display = 'block';
    modal.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
        <button id="pwa-settings-back" style="padding:8px 14px;border-radius:10px;background:#1E293B;color:#F8FAFC;border:1px solid #00F0FF;cursor:pointer;font-weight:700;">← BACK</button>
        <h2 style="color:#00F0FF;font-size:18px;">SETTINGS</h2>
        <div style="width:64px;"></div>
      </div>
      <div style="display:flex;flex-direction:column;gap:10px;max-width:360px;margin:0 auto;">
        <button id="pwa-toggle-audio" style="padding:12px;border-radius:10px;background:#1E293B;color:#F8FAFC;border:1px solid #38BDF8;cursor:pointer;font-weight:700;">
          SOUND EFFECTS: ${muted ? 'OFF' : 'ON'}
        </button>
        <button id="pwa-cycle-cam" style="padding:12px;border-radius:10px;background:#1E293B;color:#F8FAFC;border:1px solid #A855F7;cursor:pointer;font-weight:700;">
          CYCLE CAMERA PRESET
        </button>
        <button id="pwa-reset-save" style="padding:12px;border-radius:10px;background:#1E293B;color:#F43F5E;border:1px solid #F43F5E;cursor:pointer;font-weight:700;">
          RESET SAVED PROGRESS
        </button>
      </div>
    `;
    modal.querySelector('#pwa-settings-back').onclick = () => renderHomeScreen();
    modal.querySelector('#pwa-toggle-audio').onclick = () => {
      muted = !muted;
      window.GravityBallGame.setMuted(muted);
      renderSettingsScreen();
    };
    modal.querySelector('#pwa-cycle-cam').onclick = () => {
      window.GravityBallGame.cycleCameraPreset();
    };
    modal.querySelector('#pwa-reset-save').onclick = () => {
      progress = window.GravityBallGame.resetSavedProgress();
      activeLevel = 1;
      window.GravityBallGame.previewLevel(1);
      renderSettingsScreen();
    };
  }

  window.AndroidBridge = {
    onHudUpdate: (lvlId, timeMs, prog, cpDone, cpTotal) => {
      const lvl = window.GRAVITY_LEVELS[lvlId - 1];
      document.getElementById('pwa-lvl-label').textContent = `LVL ${lvlId}: ${lvl ? lvl.name.toUpperCase() : ''}`;
      document.getElementById('pwa-prog-label').textContent = `${prog}% · CP ${cpDone}/${cpTotal}`;
      document.getElementById('pwa-time-label').textContent = `${(timeMs / 1000).toFixed(1)}s`;
    },
    onCheckpointReached: () => {},
    onBallFell: () => {},
    onHazardHit: () => {},
    onLevelComplete: (lvlId, timeMs, falls) => {
      progress = loadProgress();
      progress.completed = progress.completed || {};
      progress.bestTimes = progress.bestTimes || {};
      progress.completed[lvlId] = true;
      if (!progress.bestTimes[lvlId] || timeMs < progress.bestTimes[lvlId]) {
        progress.bestTimes[lvlId] = timeMs;
      }
      if (lvlId < 10 && progress.unlockedLevel < lvlId + 1) {
        progress.unlockedLevel = lvlId + 1;
      }
      saveProgress(progress);
      setGameplayControlsVisible(false);
      modal.style.display = 'block';
      const nextId = Math.min(10, lvlId + 1);
      modal.innerHTML = `
        <h2 style="color:#10B981;font-size:24px;margin-bottom:6px;">LEVEL ${lvlId} COMPLETE!</h2>
        <p style="color:#E2E8F0;margin-bottom:14px;">Time: ${(timeMs / 1000).toFixed(2)}s · Falls: ${falls}</p>
        <div style="display:flex;flex-direction:column;gap:8px;max-width:340px;margin:0 auto;">
          <button id="pwa-next-cta" style="padding:12px;border-radius:12px;background:#10B981;color:#060B1E;font-weight:900;font-size:15px;border:none;cursor:pointer;">${lvlId < 10 ? 'NEXT LEVEL (LEVEL ' + nextId + ')' : 'REPLAY LEVEL 10'}</button>
          <button id="pwa-lvlsel-cta" style="padding:10px;border-radius:10px;background:#1E293B;color:#00F0FF;border:1px solid #00F0FF;cursor:pointer;font-weight:700;">LEVEL SELECTION</button>
          <button id="pwa-menu-cta" style="padding:10px;border-radius:10px;background:#1E293B;color:#F8FAFC;border:1px solid #475569;cursor:pointer;">HOME SCREEN</button>
        </div>
      `;
      modal.querySelector('#pwa-next-cta').onclick = () => {
        activeLevel = nextId;
        modal.style.display = 'none';
        setGameplayControlsVisible(true);
        window.GravityBallGame.startGame(activeLevel);
      };
      modal.querySelector('#pwa-lvlsel-cta').onclick = () => renderLevelSelectScreen();
      modal.querySelector('#pwa-menu-cta').onclick = () => renderHomeScreen();
    }
  };

  // Multi-touch safe pointer handling for bottom-left joystick
  const joyKnob = document.getElementById('pwa-joy-knob');
  let activePointerId = null;
  function updateJoy(clientX, clientY) {
    const rect = joyZone.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxR = rect.width * 0.34;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxR && dist > 0) {
      dx = (dx / dist) * maxR;
      dy = (dy / dist) * maxR;
    }
    joyKnob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
    window.GravityBallGame.setJoystick(dx / maxR, dy / maxR);
  }
  joyZone.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    activePointerId = e.pointerId;
    joyZone.setPointerCapture(e.pointerId);
    updateJoy(e.clientX, e.clientY);
  });
  joyZone.addEventListener('pointermove', (e) => {
    if (e.pointerId === activePointerId) {
      e.preventDefault();
      updateJoy(e.clientX, e.clientY);
    }
  });
  function resetJoy(e) {
    if (activePointerId !== null && (!e || e.pointerId === activePointerId)) {
      activePointerId = null;
      joyKnob.style.transform = 'translate(-50%, -50%)';
      window.GravityBallGame.setJoystick(0, 0);
    }
  }
  joyZone.addEventListener('pointerup', resetJoy);
  joyZone.addEventListener('pointercancel', resetJoy);

  document.getElementById('pwa-jump-btn').addEventListener('pointerdown', (e) => {
    e.preventDefault();
    window.GravityBallGame.jump();
  });
  const boostBtn = document.getElementById('pwa-boost-btn');
  boostBtn.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    window.GravityBallGame.setBoost(true);
  });
  boostBtn.addEventListener('pointerup', () => window.GravityBallGame.setBoost(false));
  boostBtn.addEventListener('pointercancel', () => window.GravityBallGame.setBoost(false));

  document.getElementById('pwa-restart-btn').onclick = () => window.GravityBallGame.restartLevel();
  document.getElementById('pwa-home-btn').onclick = () => {
    window.GravityBallGame.previewLevel(activeLevel);
    renderHomeScreen();
  };

  renderHomeScreen();
})();
