// 10 Progressively Harder Playable Levels for GRAVITY BALL 3D
// Built with modular, reusable level-building helper functions.
// Coordinate system: Start at (0, 1.8, 0), course progresses along -Z with lateral X turns and Y elevation changes.

(function () {
  // Reusable Level-Building Helper Functions
  function deck(x, y, z, w, d, color, trim, rails) {
    return {
      pos: [x, y, z],
      size: [w, 1.2, d],
      color: color || '#1E293B',
      trim: trim || '#00F0FF',
      rails: rails || null
    };
  }

  function narrowPath(x, y, z, w, d, color, trim, yaw) {
    return {
      pos: [x, y, z],
      size: [w, 1.0, d],
      rot: yaw ? [0, yaw, 0] : undefined,
      color: color || '#0F172A',
      trim: trim || '#F59E0B'
    };
  }

  function slopeRamp(x, y, z, w, d, pitch, yaw, color, trim) {
    return {
      pos: [x, y, z],
      size: [w, 1.0, d],
      rot: [pitch || 0, yaw || 0, 0],
      color: color || '#1E293B',
      trim: trim || '#38BDF8'
    };
  }

  function rotatingBridge(x, y, z, w, d, speed, color, trim) {
    return {
      pos: [x, y, z],
      size: [w, 0.9, d],
      speed: speed || 0.8,
      axis: 'y',
      isHazard: false,
      color: color || '#312E81',
      trim: trim || '#A855F7'
    };
  }

  function spinningMill(x, y, z, length, speed, color, trim) {
    return {
      pos: [x, y, z],
      size: [length, 0.95, 0.95],
      speed: speed || 1.6,
      axis: 'y',
      isHazard: true,
      color: color || '#EF4444',
      trim: trim || '#FBBF24'
    };
  }

  function movingFerry(x, y, z, w, d, axis, amplitude, speed, phase, color, trim) {
    return {
      pos: [x, y, z],
      size: [w, 1.1, d],
      axis: axis || 'x',
      amplitude: amplitude || 3.0,
      speed: speed || 1.2,
      phase: phase || 0,
      isHazard: false,
      kind: 'ferry',
      color: color || '#0284C7',
      trim: trim || '#38BDF8'
    };
  }

  function slidingObstacle(x, y, z, w, h, d, axis, amplitude, speed, phase, color) {
    return {
      pos: [x, y, z],
      size: [w, h, d],
      axis: axis || 'x',
      amplitude: amplitude || 2.2,
      speed: speed || 2.0,
      phase: phase || 0,
      isHazard: true,
      kind: 'piston',
      color: color || '#EF4444'
    };
  }

  // Timed gate that vertically rises and lowers (or slides open/shut) on a rhythmic cycle
  function timedGate(x, y, z, width, height, speed, phase, axis) {
    const gateAxis = axis || 'y';
    return {
      pos: [x, y, z],
      size: [width || 4.8, height || 2.4, 0.75],
      axis: gateAxis,
      amplitude: gateAxis === 'y' ? 2.1 : 2.6,
      speed: speed || 1.8,
      phase: phase || 0,
      isHazard: true,
      kind: 'timed_gate',
      color: '#F59E0B',
      trim: '#EF4444'
    };
  }

  function checkpoint(id, x, y, z) {
    return {
      id: id,
      pos: [x, y + 0.6, z],
      spawn: [x, y + 1.8, z]
    };
  }

  window.GRAVITY_LEVELS = [
    // =========================================================================
    // LEVEL 1: Tutorial course with wide platforms, gentle turns, basic movement
    // =========================================================================
    {
      id: 1,
      name: 'Tutorial Promenade',
      subtitle: 'Wide platforms, gentle turns, and basic rolling control',
      parTimeSec: 40,
      skyTop: '#060B1E',
      skyHorizon: '#102A56',
      fogColor: '#0D2146',
      accentColor: '#00F0FF',
      spawn: [0, 1.8, 0],
      voidY: -12,
      finish: [0, 0, -96],
      platforms: [
        deck(0, 0, -8, 8.0, 20, '#1E293B', '#00F0FF', 'both'),
        // Gentle diagonal turn to the right
        narrowPath(3.0, 0, -24, 6.5, 16, '#1E293B', '#38BDF8', -0.28),
        // Wide right promenade deck (Checkpoint 1)
        deck(5.5, 0, -39, 8.0, 18, '#1E293B', '#10B981', 'both'),
        // Gentle diagonal turn back to center
        narrowPath(2.8, 0, -55, 6.5, 16, '#1E293B', '#38BDF8', 0.28),
        // Center straightaway
        deck(0, 0, -72, 7.5, 20, '#1E293B', '#00F0FF'),
        // Wide Finish Plaza
        deck(0, 0, -92, 9.0, 20, '#1E293B', '#10B981', 'both')
      ],
      rotatingPlatforms: [],
      movingObstacles: [],
      checkpoints: [
        checkpoint(1, 5.5, 0, -39)
      ]
    },

    // =========================================================================
    // LEVEL 2: Narrower paths and small gaps
    // =========================================================================
    {
      id: 2,
      name: 'Canyon Gaps',
      subtitle: 'Narrower catwalks and small jumpable gaps',
      parTimeSec: 48,
      skyTop: '#071126',
      skyHorizon: '#163B68',
      fogColor: '#0F294A',
      accentColor: '#38BDF8',
      spawn: [0, 1.8, 0],
      voidY: -12,
      finish: [0, 0, -114],
      platforms: [
        deck(0, 0, -6, 7.0, 15, '#1E293B', '#38BDF8', 'both'),
        // Narrow path 1
        narrowPath(0, 0, -21, 3.2, 15, '#0F172A', '#00F0FF'),
        // Small gap (2.5m) -> Island 1
        deck(0, 0, -37, 5.5, 12, '#1E293B', '#38BDF8'),
        // Narrow path 2 with slight offset
        narrowPath(-2.0, 0, -50, 2.8, 14, '#0F172A', '#F59E0B'),
        // Checkpoint 1 Deck
        deck(-2.0, 0, -64, 7.0, 14, '#1E293B', '#10B981'),
        // Small gap (3.0m) -> Narrow bridge 3
        narrowPath(-2.0, 0, -81, 2.8, 14, '#0F172A', '#F59E0B'),
        // Small gap (2.8m) -> Return turn pad
        narrowPath(0, 0, -96, 3.6, 12, '#1E293B', '#00F0FF', -0.18),
        // Finish Deck
        deck(0, 0, -111, 8.5, 16, '#1E293B', '#10B981', 'both')
      ],
      rotatingPlatforms: [],
      movingObstacles: [],
      checkpoints: [
        checkpoint(1, -2.0, 0, -64)
      ]
    },

    // =========================================================================
    // LEVEL 3: Slopes, ramps, and sharper turns
    // =========================================================================
    {
      id: 3,
      name: 'Banked Switchbacks',
      subtitle: 'Ascending slopes, speed ramps, and sharper S-curve turns',
      parTimeSec: 55,
      skyTop: '#09061E',
      skyHorizon: '#2A1250',
      fogColor: '#1D0E3B',
      accentColor: '#A855F7',
      spawn: [0, 1.8, 0],
      voidY: -14,
      finish: [0, 1.2, -130],
      platforms: [
        deck(0, 0, -6, 7.0, 14, '#1E1B4B', '#A855F7', 'both'),
        // Uphill slope ramp
        slopeRamp(0, 1.4, -20, 5.0, 14, 0.20, 0, '#312E81', '#C084FC'),
        // High corner deck 1
        deck(0, 2.8, -32, 6.5, 10, '#1E1B4B', '#00F0FF'),
        // Sharp 45-degree turn to the left
        narrowPath(-5.5, 2.8, -42, 4.2, 16, '#0F172A', '#F59E0B', 0.52),
        // Left switchback deck (Checkpoint 1)
        deck(-10.0, 2.8, -55, 7.0, 12, '#1E1B4B', '#10B981'),
        // Downhill diagonal ramp toward right
        slopeRamp(-4.0, 1.4, -69, 4.5, 18, -0.16, -0.52, '#312E81', '#38BDF8'),
        // Right switchback deck
        deck(2.5, 0, -83, 6.5, 12, '#1E1B4B', '#A855F7'),
        // Checkpoint 2 Deck
        deck(2.5, 0, -96, 6.5, 12, '#1E1B4B', '#10B981'),
        // Final uphill launch ramp back to X=0
        slopeRamp(1.2, 0.6, -110, 4.6, 15, 0.10, 0.14, '#312E81', '#F59E0B'),
        // Finish Deck
        deck(0, 1.2, -126, 8.5, 16, '#1E1B4B', '#10B981', 'both')
      ],
      rotatingPlatforms: [],
      movingObstacles: [],
      checkpoints: [
        checkpoint(1, -10.0, 2.8, -55),
        checkpoint(2, 2.5, 0, -96)
      ]
    },

    // =========================================================================
    // LEVEL 4: Rotating bridges and moving platforms
    // =========================================================================
    {
      id: 4,
      name: 'Rotor Nexus',
      subtitle: 'Motorized rotating bridges and oscillating ferry platforms',
      parTimeSec: 65,
      skyTop: '#041421',
      skyHorizon: '#064E63',
      fogColor: '#052E3E',
      accentColor: '#00F0FF',
      spawn: [0, 1.8, 0],
      voidY: -14,
      finish: [0, 0, -142],
      platforms: [
        deck(0, 0, -6, 7.0, 14, '#0F172A', '#00F0FF', 'both'),
        // Rotating bridge 1 spans z=-13 to z=-29
        deck(0, 0, -35, 6.5, 10, '#1E293B', '#38BDF8'),
        // Lateral moving ferry spans z=-40 to z=-54
        // Checkpoint 1 Deck
        deck(0, 0, -60, 7.5, 12, '#1E293B', '#10B981'),
        // Rotating bridge 2 spans z=-66 to z=-82
        deck(0, 0, -88, 6.5, 10, '#1E293B', '#A855F7'),
        // Z-axis moving ferry spans z=-93 to z=-115
        // Checkpoint 2 Deck
        deck(0, 0, -121, 7.0, 12, '#1E293B', '#10B981'),
        // Final Finish Deck
        deck(0, 0, -138, 8.5, 16, '#0F172A', '#10B981', 'both')
      ],
      rotatingPlatforms: [
        rotatingBridge(0, 0, -21, 3.2, 14, 0.72, '#312E81', '#A855F7'),
        rotatingBridge(0, 0, -74, 3.2, 14, -0.85, '#312E81', '#00F0FF')
      ],
      movingObstacles: [
        movingFerry(0, 0, -47, 4.8, 11, 'x', 2.6, 1.15, 0, '#0284C7', '#38BDF8'),
        movingFerry(0, 0, -104, 5.0, 8.5, 'z', 5.8, 1.1, 0.4, '#0284C7', '#00F0FF')
      ],
      checkpoints: [
        checkpoint(1, 0, 0, -60),
        checkpoint(2, 0, 0, -121)
      ]
    },

    // =========================================================================
    // LEVEL 5: Timed gates and carefully placed obstacles
    // =========================================================================
    {
      id: 5,
      name: 'Chrono Gates',
      subtitle: 'Rhythmic timed barrier gates and precision hazard blocks',
      parTimeSec: 70,
      skyTop: '#140804',
      skyHorizon: '#451A03',
      fogColor: '#2E1205',
      accentColor: '#F59E0B',
      spawn: [0, 1.8, 0],
      voidY: -14,
      finish: [0, 0, -148],
      platforms: [
        deck(0, 0, -6, 7.0, 14, '#27272A', '#F59E0B', 'both'),
        // Gate Corridor 1
        deck(0, 0, -28, 5.6, 30, '#18181B', '#FB923C'),
        // Checkpoint 1 Deck
        deck(0, 0, -50, 7.0, 12, '#27272A', '#10B981'),
        // Narrow bypass with timed lateral gate
        narrowPath(0, 0, -68, 4.2, 22, '#18181B', '#00F0FF'),
        // Checkpoint 2 Deck
        deck(0, 0, -86, 7.0, 12, '#27272A', '#10B981'),
        // Second Timed Gate Gauntlet
        deck(0, 0, -112, 5.8, 36, '#18181B', '#F59E0B'),
        // Finish Deck
        deck(0, 0, -144, 8.5, 18, '#27272A', '#10B981', 'both')
      ],
      rotatingPlatforms: [],
      movingObstacles: [
        // Timed vertical rising/falling gate 1
        timedGate(0, 1.8, -20, 5.2, 2.2, 1.9, 0.0, 'y'),
        // Timed vertical gate 2 (out of phase)
        timedGate(0, 1.8, -34, 5.2, 2.2, 1.9, 2.2, 'y'),
        // Lateral sweeping obstacle on narrow bridge
        slidingObstacle(0, 1.2, -68, 1.8, 1.3, 1.8, 'x', 1.6, 1.8, 0.5, '#EF4444'),
        // Timed vertical gate 3
        timedGate(0, 1.8, -102, 5.4, 2.2, 2.1, 0.0, 'y'),
        // Timed lateral gate 4
        timedGate(0, 1.4, -118, 2.6, 2.2, 2.0, 1.6, 'x')
      ],
      checkpoints: [
        checkpoint(1, 0, 0, -50),
        checkpoint(2, 0, 0, -86)
      ]
    },

    // =========================================================================
    // LEVEL 6: Narrow moving platforms over larger gaps
    // =========================================================================
    {
      id: 6,
      name: 'Abyssal Ferries',
      subtitle: 'Narrow moving platforms gliding across deep void chasms',
      parTimeSec: 78,
      skyTop: '#02181C',
      skyHorizon: '#064E3B',
      fogColor: '#042F2E',
      accentColor: '#10B981',
      spawn: [0, 1.8, 0],
      voidY: -15,
      finish: [0, 0, -162],
      platforms: [
        deck(0, 0, -6, 7.0, 14, '#0F172A', '#10B981', 'both'),
        // Chasm 1 (-13 to -39) bridged by Z-ferry 1
        deck(0, 0, -45, 6.0, 12, '#064E3B', '#34D399'),
        // Narrow lateral ferry 2 (-51 to -67)
        // Checkpoint 1 Deck
        deck(0, 0, -73, 7.0, 12, '#0F172A', '#10B981'),
        // Long Chasm 3 (-79 to -113) with two sequential ferries & tiny mid-island
        deck(0, 0, -96, 4.5, 6, '#064E3B', '#00F0FF'),
        // Checkpoint 2 Deck
        deck(0, 0, -120, 7.0, 12, '#0F172A', '#10B981'),
        // Narrow high-precision moving bridge to finish
        deck(0, 0, -158, 8.5, 16, '#0F172A', '#10B981', 'both')
      ],
      rotatingPlatforms: [],
      movingObstacles: [
        movingFerry(0, 0, -26, 3.4, 9.0, 'z', 7.5, 1.15, 0.0, '#0284C7', '#38BDF8'),
        movingFerry(0, 0, -59, 3.2, 13.0, 'x', 2.8, 1.25, 1.0, '#0D9488', '#2DD4BF'),
        movingFerry(0, 0, -86, 3.2, 7.5, 'z', 4.5, 1.3, 0.0, '#0284C7', '#00F0FF'),
        movingFerry(0, 0, -106, 3.2, 7.5, 'z', 4.5, 1.3, 3.14, '#0284C7', '#00F0FF'),
        movingFerry(0, 0, -139, 2.9, 10.0, 'z', 8.0, 1.25, 0.8, '#0D9488', '#34D399')
      ],
      checkpoints: [
        checkpoint(1, 0, 0, -73),
        checkpoint(2, 0, 0, -120)
      ]
    },

    // =========================================================================
    // LEVEL 7: Faster rotating obstacles and more difficult turns
    // =========================================================================
    {
      id: 7,
      name: 'Cyclone Spires',
      subtitle: 'High-speed rotors, spinning mills, and sharp dogleg turns',
      parTimeSec: 85,
      skyTop: '#0F0524',
      skyHorizon: '#3B0764',
      fogColor: '#240642',
      accentColor: '#C084FC',
      spawn: [0, 1.8, 0],
      voidY: -15,
      finish: [0, 0, -172],
      platforms: [
        deck(0, 0, -6, 7.0, 14, '#1E1B4B', '#C084FC', 'both'),
        // Fast rotating bridge 1 (-13 to -29)
        // Dogleg turn right
        deck(0, 0, -35, 6.5, 10, '#1E1B4B', '#00F0FF'),
        narrowPath(5.0, 0, -45, 3.2, 14, '#0F172A', '#F59E0B', -0.58),
        // Checkpoint 1 Plaza on right (x=9)
        deck(9.0, 0, -58, 7.5, 14, '#1E1B4B', '#10B981'),
        // Spinning Mill Arena on right
        deck(9.0, 0, -76, 8.0, 20, '#312E81', '#C084FC'),
        // Sharp turn left back toward center
        narrowPath(4.5, 0, -93, 3.0, 15, '#0F172A', '#F59E0B', 0.55),
        // Checkpoint 2 Plaza at center
        deck(0, 0, -106, 7.0, 12, '#1E1B4B', '#10B981'),
        // Counter-rotating dual bridge crossing (-112 to -144)
        deck(0, 0, -128, 4.8, 6, '#1E1B4B', '#38BDF8'),
        // Checkpoint 3 Plaza
        deck(0, 0, -150, 6.5, 10, '#1E1B4B', '#10B981'),
        // Finish Deck
        deck(0, 0, -168, 8.5, 16, '#1E1B4B', '#10B981', 'both')
      ],
      rotatingPlatforms: [
        rotatingBridge(0, 0, -21, 3.0, 14, 1.25, '#3B0764', '#C084FC'),
        spinningMill(9.0, 1.15, -76, 6.8, 2.15, '#EF4444', '#FBBF24'),
        rotatingBridge(0, 0, -119, 2.8, 12, 1.35, '#3B0764', '#00F0FF'),
        rotatingBridge(0, 0, -137, 2.8, 12, -1.45, '#3B0764', '#F43F5E')
      ],
      movingObstacles: [],
      checkpoints: [
        checkpoint(1, 9.0, 0, -58),
        checkpoint(2, 0, 0, -106),
        checkpoint(3, 0, 0, -150)
      ]
    },

    // =========================================================================
    // LEVEL 8: Multiple obstacle types combined with fewer safe areas
    // =========================================================================
    {
      id: 8,
      name: 'Hazard Crucible',
      subtitle: 'Ramps, pistons, rotors, and narrow beams with minimal rest zones',
      parTimeSec: 95,
      skyTop: '#18040B',
      skyHorizon: '#4C0519',
      fogColor: '#310613',
      accentColor: '#F43F5E',
      spawn: [0, 1.8, 0],
      voidY: -15,
      finish: [0, 2.0, -184],
      platforms: [
        deck(0, 0, -6, 6.5, 12, '#18181B', '#F43F5E', 'both'),
        // Narrow piston beam 1
        narrowPath(0, 0, -24, 3.6, 22, '#090D16', '#FB7185'),
        // Rotating bridge (-35 to -51)
        // Checkpoint 1 Small Pad
        deck(0, 0, -56, 5.5, 9, '#18181B', '#10B981'),
        // Ascending ramp into spinning mill deck
        slopeRamp(0, 1.0, -68, 4.0, 14, 0.15, 0, '#27272A', '#F59E0B'),
        deck(0, 2.0, -85, 6.5, 18, '#18181B', '#F43F5E'),
        // Checkpoint 2 Small Pad
        deck(0, 2.0, -100, 5.5, 9, '#18181B', '#10B981'),
        // Moving lateral ferry (-105 to -121)
        // Narrow catwalk with timed gate
        narrowPath(0, 2.0, -133, 3.4, 20, '#090D16', '#00F0FF'),
        // Checkpoint 3 Small Pad
        deck(0, 2.0, -148, 5.5, 9, '#18181B', '#10B981'),
        // Fast rotating bridge (-153 to -169)
        // Finish Deck
        deck(0, 2.0, -180, 8.0, 15, '#18181B', '#10B981', 'both')
      ],
      rotatingPlatforms: [
        rotatingBridge(0, 0, -43, 2.8, 14, 1.25, '#4C0519', '#F43F5E'),
        spinningMill(0, 3.15, -85, 5.8, -2.25, '#EF4444', '#FBBF24'),
        rotatingBridge(0, 2.0, -161, 2.8, 14, -1.35, '#4C0519', '#00F0FF')
      ],
      movingObstacles: [
        slidingObstacle(0, 1.15, -19, 1.8, 1.2, 1.8, 'x', 1.5, 2.4, 0.0, '#EF4444'),
        slidingObstacle(0, 1.15, -29, 1.8, 1.2, 1.8, 'x', 1.5, 2.4, 3.14, '#EF4444'),
        movingFerry(0, 2.0, -113, 3.8, 12, 'x', 2.8, 1.4, 0.3, '#0284C7', '#38BDF8'),
        timedGate(0, 3.8, -133, 3.4, 2.2, 2.2, 0.0, 'y')
      ],
      checkpoints: [
        checkpoint(1, 0, 0, -56),
        checkpoint(2, 0, 2.0, -100),
        checkpoint(3, 0, 2.0, -148)
      ]
    },

    // =========================================================================
    // LEVEL 9: Complex platform sequences, timed gates, and challenging jumps
    // =========================================================================
    {
      id: 9,
      name: 'Quantum Vault',
      subtitle: 'Synchronized timed gates, ramp leaps, and multi-stage sequences',
      parTimeSec: 105,
      skyTop: '#031229',
      skyHorizon: '#1E3A8A',
      fogColor: '#0F2357',
      accentColor: '#38BDF8',
      spawn: [0, 1.8, 0],
      voidY: -16,
      finish: [0, 4.2, -194],
      platforms: [
        deck(0, 0, -6, 7.0, 14, '#0F172A', '#38BDF8', 'both'),
        // Launch Ramp 1 + Jump Gap
        slopeRamp(0, 1.0, -19, 4.5, 12, 0.18, 0, '#1E3A8A', '#00F0FF'),
        // Landing Deck + Timed Gate Pair
        deck(0, 2.1, -39, 6.0, 20, '#0F172A', '#F59E0B'),
        // Checkpoint 1 Deck
        deck(0, 2.1, -55, 6.5, 10, '#0F172A', '#10B981'),
        // Diagonal Jump Pads (Left -> Right)
        deck(-3.2, 2.1, -69, 4.2, 10, '#1E293B', '#00F0FF'),
        deck(3.2, 2.1, -83, 4.2, 10, '#1E293B', '#A855F7'),
        // Checkpoint 2 Deck
        deck(0, 2.1, -98, 6.5, 12, '#0F172A', '#10B981'),
        // Ascending Ramp 2 + Gap
        slopeRamp(0, 3.1, -112, 4.5, 14, 0.16, 0, '#1E3A8A', '#38BDF8'),
        // Upper Timed Vault Corridor
        deck(0, 4.2, -135, 5.5, 24, '#0F172A', '#F43F5E'),
        // Checkpoint 3 Deck
        deck(0, 4.2, -153, 6.5, 10, '#0F172A', '#10B981'),
        // Moving Ferry + Final Jump Ramp
        slopeRamp(0, 4.2, -178, 4.5, 10, 0.12, 0, '#1E3A8A', '#00F0FF'),
        // Finish Vault
        deck(0, 4.2, -191, 8.5, 14, '#0F172A', '#10B981', 'both')
      ],
      rotatingPlatforms: [
        rotatingBridge(0, 4.2, -166, 2.8, 12, 1.4, '#1E3A8A', '#00F0FF')
      ],
      movingObstacles: [
        timedGate(0, 3.9, -33, 5.6, 2.2, 2.2, 0.0, 'y'),
        timedGate(0, 3.9, -44, 5.6, 2.2, 2.2, 1.8, 'y'),
        timedGate(0, 6.0, -128, 5.2, 2.2, 2.4, 0.0, 'y'),
        slidingObstacle(0, 5.35, -135, 1.8, 1.2, 1.8, 'x', 2.0, 2.6, 1.5, '#EF4444'),
        timedGate(0, 6.0, -142, 5.2, 2.2, 2.4, 2.4, 'y')
      ],
      checkpoints: [
        checkpoint(1, 0, 2.1, -55),
        checkpoint(2, 0, 2.1, -98),
        checkpoint(3, 0, 4.2, -153)
      ]
    },

    // =========================================================================
    // LEVEL 10: Final challenge combining the best mechanics from all levels
    // =========================================================================
    {
      id: 10,
      name: 'Singularity Apex',
      subtitle: 'Grand finale: Ramps, sharp turns, ferries, rotors, and timed gates',
      parTimeSec: 125,
      skyTop: '#070210',
      skyHorizon: '#3B0764',
      fogColor: '#1E0538',
      accentColor: '#00F0FF',
      spawn: [0, 1.8, 0],
      voidY: -16,
      finish: [0, 3.2, -226],
      platforms: [
        deck(0, 0, -6, 7.5, 14, '#18181B', '#00F0FF', 'both'),
        // Stage 1: Launch Ramp into Timed Gate Deck
        slopeRamp(0, 1.1, -19, 4.6, 12, 0.18, 0, '#27272A', '#F59E0B'),
        deck(0, 2.2, -37, 6.2, 18, '#18181B', '#A855F7'),
        // Checkpoint 1
        deck(0, 2.2, -52, 6.5, 10, '#18181B', '#10B981'),
        // Stage 2: Lateral Moving Ferry (-57 to -71) + Dogleg Right Turn
        narrowPath(4.5, 2.2, -80, 3.2, 14, '#090D16', '#00F0FF', -0.52),
        deck(8.5, 2.2, -94, 7.0, 14, '#18181B', '#F43F5E'),
        // Checkpoint 2 (at x=8.5)
        deck(8.5, 2.2, -108, 6.5, 10, '#18181B', '#10B981'),
        // Stage 3: Return Diagonal Ramp + Counter-Rotating Bridges
        narrowPath(4.2, 2.2, -120, 3.2, 14, '#090D16', '#F59E0B', 0.52),
        deck(0, 2.2, -132, 6.0, 10, '#18181B', '#00F0FF'),
        // Rotating Bridge 1 (-137 to -151) -> Mid Pad -> Rotating Bridge 2 (-159 to -173)
        deck(0, 2.2, -155, 4.8, 6, '#27272A', '#38BDF8'),
        // Checkpoint 3
        deck(0, 2.2, -179, 6.5, 10, '#18181B', '#10B981'),
        // Stage 4: Z-Axis Abyss Ferry (-184 to -202) -> Checkpoint 4 -> Final Apex Ramp
        deck(0, 2.2, -206, 6.5, 8, '#18181B', '#10B981'),
        slopeRamp(0, 2.7, -214, 4.5, 8, 0.12, 0, '#27272A', '#00F0FF'),
        // Grand Singularity Apex Finish Arena
        deck(0, 3.2, -224, 9.0, 14, '#18181B', '#10B981', 'both')
      ],
      rotatingPlatforms: [
        spinningMill(8.5, 3.35, -94, 6.2, 2.35, '#EF4444', '#FBBF24'),
        rotatingBridge(0, 2.2, -144, 2.8, 13, 1.45, '#3B0764', '#F43F5E'),
        rotatingBridge(0, 2.2, -166, 2.8, 13, -1.55, '#3B0764', '#00F0FF')
      ],
      movingObstacles: [
        timedGate(0, 4.0, -32, 5.6, 2.2, 2.2, 0.0, 'y'),
        slidingObstacle(0, 3.35, -41, 1.9, 1.2, 1.9, 'x', 2.2, 2.6, 1.2, '#EF4444'),
        movingFerry(0, 2.2, -64, 4.4, 11, 'x', 2.6, 1.35, 0.0, '#0284C7', '#00F0FF'),
        movingFerry(0, 2.2, -193, 4.4, 8.0, 'z', 5.2, 1.35, 0.5, '#0284C7', '#38BDF8')
      ],
      checkpoints: [
        checkpoint(1, 0, 2.2, -52),
        checkpoint(2, 8.5, 2.2, -108),
        checkpoint(3, 0, 2.2, -179),
        checkpoint(4, 0, 2.2, -206)
      ]
    }
  ];
})();
