package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.GameDatabase
import com.example.data.local.GameRepository
import com.example.engine.LevelDefinitions
import com.example.engine.ObstacleKind
import com.example.engine.Physics3DEngine
import com.example.engine.PlatformStyle
import com.example.engine.RotatingKind
import com.example.engine.Vec3
import com.example.ui.BallControlMode
import com.example.ui.GameScreenState
import com.example.ui.GameViewModel
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var database: GameDatabase
    private lateinit var repository: GameRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, GameDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = GameRepository(database.levelProgressDao())
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Gravity Ball 3D", appName)
    }

    @Test
    fun `verify 10 levels seeded and sequential unlocking from level 1 to 10`() = runBlocking {
        repository.ensureSeeded()
        val initialLevels = database.levelProgressDao().getAllLevelsSnapshot()
        assertEquals(10, initialLevels.size)
        assertTrue(initialLevels[0].isUnlocked)
        for (i in 1 until 10) {
            assertFalse("Level ${i + 1} should start locked", initialLevels[i].isUnlocked)
        }

        val stars1 = repository.recordLevelCompletion(levelId = 1, timeMs = 30000L, falls = 0)
        assertEquals(3, stars1)
        val afterLvl1 = database.levelProgressDao().getAllLevelsSnapshot()
        assertTrue(afterLvl1[0].isCompleted)
        assertTrue(afterLvl1[1].isUnlocked)
        assertFalse(afterLvl1[2].isUnlocked)

        for (lvl in 2..9) {
            repository.recordLevelCompletion(levelId = lvl, timeMs = 45000L, falls = 1)
        }
        val afterLvl9 = database.levelProgressDao().getAllLevelsSnapshot()
        assertTrue("Level 10 must be unlocked after completing Level 9", afterLvl9[9].isUnlocked)
    }

    @Test
    fun `verify 6 balls selection and 4 control modes in GameViewModel`() = runBlocking {
        repository.ensureSeeded()
        val viewModel = GameViewModel(repository)
        assertEquals(GameScreenState.TITLE, viewModel.uiState.value.screenState)
        assertEquals(6, LevelDefinitions.BALL_SKINS.size)

        for (ballIndex in 0 until 6) {
            viewModel.selectBall(ballIndex)
            assertEquals(ballIndex, viewModel.uiState.value.selectedBallId)
        }

        viewModel.openSettings()
        assertEquals(GameScreenState.SETTINGS, viewModel.uiState.value.screenState)

        viewModel.selectControlMode(BallControlMode.STEERING)
        assertEquals(BallControlMode.STEERING, viewModel.uiState.value.controlMode)
        assertFalse(viewModel.uiState.value.useTiltControls)

        viewModel.selectControlMode(BallControlMode.BUTTONS)
        assertEquals(BallControlMode.BUTTONS, viewModel.uiState.value.controlMode)

        viewModel.selectControlMode(BallControlMode.TILT)
        assertEquals(BallControlMode.TILT, viewModel.uiState.value.controlMode)
        assertTrue(viewModel.uiState.value.useTiltControls)

        viewModel.selectControlMode(BallControlMode.GESTURE)
        assertEquals(BallControlMode.GESTURE, viewModel.uiState.value.controlMode)

        viewModel.closeSettings()
        assertEquals(GameScreenState.TITLE, viewModel.uiState.value.screenState)

        viewModel.startGame(5)
        assertEquals(GameScreenState.TITLE, viewModel.uiState.value.screenState)

        viewModel.startGame(1)
        assertEquals(GameScreenState.PLAYING, viewModel.uiState.value.screenState)
    }

    @Test
    fun `verify stone and wooden platforms, rotating fans, and circular saw cutters have working collisions`() {
        assertEquals(10, LevelDefinitions.ALL_LEVELS.size)

        // Verify all platform styles exist across the courses
        val stylesUsed = LevelDefinitions.ALL_LEVELS.flatMap { it.platforms.map { p -> p.style } }.toSet()
        assertTrue(stylesUsed.contains(PlatformStyle.STONE_PATH))
        assertTrue(stylesUsed.contains(PlatformStyle.WOOD_BRIDGE))
        assertTrue(stylesUsed.contains(PlatformStyle.FLOATING_ROCK))
        assertTrue(stylesUsed.contains(PlatformStyle.METALLIC_TECH))
        assertTrue(stylesUsed.contains(PlatformStyle.CURVED_RAMP))

        val engine = Physics3DEngine()

        // Verify Rotating Fan on Level 1 rotates and triggers real hazard collision when ball touches blade
        val level1 = LevelDefinitions.ALL_LEVELS[0]
        engine.loadCourseColliders(level1)
        val fanColliders = engine.colliders.filter { it.rotatingKind == RotatingKind.ROTATING_FAN }
        assertTrue("Level 1 must include 4-blade rotating fan colliders", fanColliders.size >= 2)

        var hitFanBlade = false
        // Place ball in path of rotating fan at (0, 1.15, -72)
        engine.resetBall(Vec3(1.2f, 1.15f, -72f))
        for (frame in 0 until 45) {
            engine.step(
                dt = 1f / 60f,
                worldMoveX = 0f,
                worldMoveZ = 0f,
                boost = false,
                elapsedTime = frame / 60f,
                onJump = {},
                onHeavyLand = {},
                onHazardHit = { hitFanBlade = true }
            )
        }
        assertTrue("Rotating fan blades must rotate and trigger real collision", hitFanBlade)

        // Verify Circular Saw Cutter on Level 2 slices across bridge and triggers real hazard collision
        val level2 = LevelDefinitions.ALL_LEVELS[1]
        engine.loadCourseColliders(level2)
        val cutterColliders = engine.colliders.filter { it.obstacleKind == ObstacleKind.SAW_CUTTER }
        assertTrue("Level 2 must include circular saw cutter collider", cutterColliders.isNotEmpty())

        var hitCutter = false
        engine.resetBall(Vec3(-2.0f, 1.3f, -64f))
        for (frame in 0 until 30) {
            engine.step(
                dt = 1f / 60f,
                worldMoveX = 0f,
                worldMoveZ = 0f,
                boost = false,
                elapsedTime = frame / 60f,
                onJump = {},
                onHeavyLand = {},
                onHazardHit = { hitCutter = true }
            )
        }
        assertTrue("Rotating circular saw cutter must trigger real collision", hitCutter)

        // Verify all 10 courses have walkable spawn surfaces and functional rolling/jumping
        for (course in LevelDefinitions.ALL_LEVELS) {
            engine.loadCourseColliders(course)
            assertTrue("Course ${course.id} must have colliders", engine.colliders.isNotEmpty())
            engine.resetBall(course.spawn)

            var jumped = false
            for (frame in 0 until 60) {
                if (frame == 25) engine.requestJump()
                engine.step(
                    dt = 1f / 60f,
                    worldMoveX = 0f,
                    worldMoveZ = -1f,
                    boost = false,
                    elapsedTime = frame / 60f,
                    onJump = { jumped = true },
                    onHeavyLand = {},
                    onHazardHit = {}
                )
            }
            assertTrue("Ball must roll forward on Level ${course.id}", engine.ballPosition.z < -2.0f)
            assertTrue("Ball must jump on Level ${course.id}", jumped)
        }
    }
}
